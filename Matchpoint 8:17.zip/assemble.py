"""Assemble MatchPoint.jsx from u0.css + u1..u5.txt."""
css=open('u0.css').read()
parts=[open(f'u{i}.txt').read() for i in range(1,6)]
head=parts[0]
assert '__CSS__' in head, 'the CSS placeholder is missing from u1.txt'
parts[0]=head.replace('__CSS__', css.rstrip('\n'))
open('MatchPoint.jsx','w').write(''.join(parts))
print('jsx assembled')
