import React, { useState, useEffect, useRef } from "react";

/* ================================================================
   MATCH POINT — single-file React prototype
   Light pastel theme · iPhone 17 Pro (402 × 874 pt) · MP Rating

   Every sport owns a permanent colour. Individual sports use
   challenges, uploaded scores and the MP Rating. Group sports use a
   shared weekly calendar and peer reviews instead.

   Layout uses Tailwind core utilities where it helps; the design
   tokens live in the injected stylesheet because the accent colour
   changes with the active sport at run time.
   ================================================================ */

const CSS = `.mp{--bg:#F7F8FB; --surface:#FFFFFF; --surface-2:#F4F6FA; --surface-3:#EBEEF4; --line:#E6E9F0; --line-2:#D9DEE8; --ink:#151821; --ink-2:#565D70; --ink-3:#858C9E; --ink-4:#A9B0BF; --black:#14161C; --accent:#4CA85F; --accent-mid:#8FD3A0; --accent-soft:#EFF8F1; --accent-line:#CFEBD6; --danger:#CE5555; --danger-soft:#FCEEEE; --fs-display:26px; --fs-h1:21px; --fs-h2:17px; --fs-title:15.5px; --fs-body:14.5px; --fs-label:13px; --fs-caption:12px; --fs-micro:10.5px; --pad:20px; --nav-h:104px; --font:-apple-system,BlinkMacSystemFont,'SF Pro Text','Inter','Segoe UI',Roboto,Helvetica,Arial,sans-serif; --shadow-sm:0 1px 2px rgba(20,26,44,.05), 0 2px 8px rgba(20,26,44,.04); --shadow-md:0 4px 12px rgba(20,26,44,.07), 0 12px 26px -12px rgba(20,26,44,.14); --shadow-lg:0 10px 30px -8px rgba(20,26,44,.18), 0 2px 8px rgba(20,26,44,.06);}
.mp *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
.mp button{font-family:inherit;color:inherit;border:0;background:none;cursor:pointer;font-size:inherit}
.mp input, .mp select, .mp textarea{font-family:inherit}
.mp ::-webkit-scrollbar{width:0;height:0}
.mp .sim-bar{width:100%;max-width:940px;display:flex;flex-wrap:wrap;gap:9px;align-items:center; padding:11px 15px;border-radius:20px;background:rgba(255,255,255,.82); border:1px solid var(--line);backdrop-filter:blur(14px);box-shadow:var(--shadow-sm);}
.mp .sim-brand{font-weight:800;font-size:var(--fs-title);letter-spacing:-.3px;margin-right:4px}
.mp .sim-brand span{color:var(--accent)}
.mp .sim-lab{font-size:var(--fs-micro);color:var(--ink-3);text-transform:uppercase;letter-spacing:.1em;margin:0 3px 0 8px;font-weight:700}
.mp .sim-btn{font-size:var(--fs-caption);font-weight:650;padding:7px 12px;border-radius:999px;background:var(--surface);border:1px solid var(--line-2);color:var(--ink-2)}
.mp .sim-btn.on{background:var(--accent-soft);border-color:var(--accent-line);color:var(--accent)}
.mp .sim-note{font-size:var(--fs-caption);color:var(--ink-3);margin-left:auto}
.mp .device{position:relative;flex:0 0 auto;width:426px;height:898px;border-radius:56px;padding:12px; background:linear-gradient(150deg,#9BA3B4,#5D6577 26%,#3E4453 52%,#767E90 78%,#B7BDC9); box-shadow:0 30px 70px -18px rgba(20,26,44,.5), inset 0 0 0 1px rgba(255,255,255,.35);}
.mp .device::before, .mp .device::after{content:'';position:absolute;background:#4A505F;border-radius:2px}
.mp .device::before{left:-2px;top:172px;width:3px;height:62px;box-shadow:0 -78px 0 #4A505F, 0 84px 0 0 #4A505F}
.mp .device::after{right:-2px;top:206px;width:3px;height:96px}
.mp .screen{position:relative;width:402px;height:874px;overflow:hidden;border-radius:44px;background:var(--bg);display:flex;flex-direction:column}
.mp .island{position:absolute;top:11px;left:50%;transform:translateX(-50%);width:124px;height:36px;border-radius:20px;background:#08080A;z-index:95}
.mp .island::after{content:'';position:absolute;right:9px;top:11px;width:13px;height:13px;border-radius:50%;background:#14161C}
.mp .statusbar{height:54px;flex:0 0 auto;display:flex;align-items:flex-end;justify-content:space-between;padding:0 26px 6px;font-size:var(--fs-caption);font-weight:650;z-index:60}
.mp .statusbar .sb-r{display:flex;gap:5px;align-items:center}
.mp .home-ind{position:absolute;bottom:8px;left:50%;transform:translateX(-50%);width:138px;height:5px;border-radius:999px;background:rgba(21,24,33,.26);z-index:99;pointer-events:none}
.mp .bg-art{position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.5;overflow:hidden}
.mp .bg-art i{position:absolute;color:var(--accent);opacity:.085}
.mp .appbar{flex:0 0 auto;display:flex;align-items:center;gap:10px;padding:2px var(--pad) 12px;position:relative;z-index:55}
.mp .bar-btn{height:38px;min-width:64px;display:inline-flex;align-items:center;justify-content:center;gap:5px; padding:0 10px;border-radius:14px;background:var(--surface);border:1px solid var(--line); box-shadow:var(--shadow-sm);white-space:nowrap;flex:0 0 auto;}
.mp .bar-btn .caret{display:flex;color:var(--ink-3)}
.mp .bar-badge{min-width:16px;height:16px;padding:0 4px;border-radius:999px;background:var(--accent); color:#fff;font-size:9px;font-weight:800;display:grid;place-items:center;line-height:1;}
.mp .bar-badge.zero{background:var(--surface-3);color:var(--ink-3)}
.mp .appbar-title{flex:1;text-align:center;font-size:var(--fs-h2);font-weight:750;letter-spacing:-.3px}
.mp .body{flex:1;overflow-y:auto;overflow-x:hidden;padding:0 var(--pad) calc(var(--nav-h) + 70px);position:relative;z-index:1;scroll-behavior:smooth}
.mp .body.flush{padding:0}
.mp .eyebrow{font-size:var(--fs-micro);font-weight:800;letter-spacing:.15em;color:var(--accent);text-transform:uppercase}
.mp .h1{font-size:var(--fs-display);font-weight:800;letter-spacing:-.7px;line-height:1.2;margin:10px 0 8px}
.mp .h2{font-size:var(--fs-h1);font-weight:760;letter-spacing:-.4px;margin:0}
.mp .h3{font-size:var(--fs-title);font-weight:700;letter-spacing:-.2px;margin:0}
.mp .sub{font-size:var(--fs-body);line-height:1.58;color:var(--ink-2);margin:0}
.mp .tiny{font-size:var(--fs-caption);color:var(--ink-3);line-height:1.5}
.mp .sec-head{display:flex;align-items:center;justify-content:space-between;margin:26px 2px 12px}
.mp .sec-head h4{margin:0;font-size:var(--fs-h2);font-weight:750;letter-spacing:-.3px;color:var(--ink)}
.mp .sec-head .more{font-size:var(--fs-caption);font-weight:700;color:var(--accent)}
.mp .card{background:var(--surface);border:1px solid var(--line);border-radius:22px;padding:16px;box-shadow:var(--shadow-sm)}
.mp .card.tight{padding:13px}
.mp .card.accent{border-color:var(--accent-line);background:linear-gradient(160deg,var(--accent-soft),var(--surface) 64%)}
.mp .divider{height:1px;background:var(--line);margin:13px 0}
.mp .btn{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:14px 18px;border-radius:16px;font-size:var(--fs-title);font-weight:700;transition:transform .12s,filter .18s}
.mp .btn:active{transform:scale(.98)}
.mp .btn-primary{background:var(--accent);color:#fff;box-shadow:0 6px 16px -6px var(--accent)}
.mp .btn-dark{background:var(--black);color:#fff;box-shadow:0 8px 18px -8px rgba(20,22,28,.6)}
.mp .btn-dark[disabled], .mp .btn-primary[disabled]{background:var(--surface-3);color:var(--ink-4);box-shadow:none;cursor:not-allowed}
.mp .btn-ghost{background:var(--surface);border:1px solid var(--line-2);color:var(--ink)}
.mp .btn-outline{background:var(--accent-soft);border:1px solid var(--accent-line);color:var(--accent)}
.mp .btn-danger{background:var(--danger-soft);border:1px solid #F3CFCF;color:var(--danger)}
.mp .btn-sm{padding:10px 14px;font-size:var(--fs-label);border-radius:13px;width:auto}
.mp .btn-row{display:flex;gap:10px}
.mp .btn-row>*{flex:1}
.mp .link{font-size:var(--fs-label);font-weight:700;color:var(--accent);cursor:pointer}
.mp .pill{padding:9px 14px;border-radius:999px;font-size:var(--fs-label);font-weight:650;background:var(--surface);border:1px solid var(--line-2);color:var(--ink-2);white-space:nowrap}
.mp .pill.on{background:var(--accent-soft);border-color:var(--accent-line);color:var(--accent)}
.mp .pill-row{display:flex;gap:8px;flex-wrap:wrap}
.mp .chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:999px;font-size:var(--fs-caption);font-weight:700;background:var(--surface-3);color:var(--ink-2);white-space:nowrap}
.mp .chip.accent{background:var(--accent-soft);color:var(--accent)}
.mp .field{margin-bottom:16px}
.mp .field label{display:block;font-size:var(--fs-caption);font-weight:750;letter-spacing:.05em;text-transform:uppercase;color:var(--ink-3);margin-bottom:7px}
.mp .field .req{color:var(--danger);margin-left:3px}
.mp .input{width:100%;padding:13px 15px;border-radius:14px;font-size:var(--fs-title);background:var(--surface);border:1px solid var(--line-2);color:var(--ink);outline:none;transition:.16s}
.mp .input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}
.mp .input::placeholder{color:var(--ink-4)}
.mp select.input{appearance:none;background-image:linear-gradient(45deg,transparent 50%,var(--ink-3) 50%),linear-gradient(135deg,var(--ink-3) 50%,transparent 50%);background-position:calc(100% - 18px) 21px,calc(100% - 13px) 21px;background-size:5px 5px,5px 5px;background-repeat:no-repeat}
.mp .hint{font-size:var(--fs-caption);color:var(--ink-3);margin-top:6px;line-height:1.45}
.mp .checkbox{flex:0 0 auto;width:22px;height:22px;border-radius:7px;border:1.5px solid var(--line-2);display:grid;place-items:center;background:var(--surface)}
.mp .checkbox.on{background:var(--accent);border-color:var(--accent)}
.mp .checkbox svg{opacity:0}
.mp .checkbox.on svg{opacity:1}
.mp .av{border-radius:50%;display:grid;place-items:center;flex:0 0 auto;user-select:none;line-height:1;overflow:hidden;background:var(--surface-2)}
.mp .av svg{display:block}
.mp .av-stack{display:flex}
.mp .av-stack .av{margin-left:-8px;box-shadow:0 0 0 2px var(--surface)}
.mp .av-stack .av:first-child{margin-left:0}
.mp .av-svg .av-body{animation:avBreathe 4.6s ease-in-out infinite;transform-origin:50% 100%}
.mp .av-svg .av-eyes{animation:avBlink 5.2s infinite;transform-origin:50% 48%}

@keyframes avBreathe{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-1.2px) scale(1.012)}}

@keyframes avBlink{0%,93%,100%{transform:scaleY(1)}96%{transform:scaleY(.08)}}
.mp .poster-person{position:absolute;bottom:-14px;left:50%;transform:translateX(-50%);width:150px;height:150px}
.mp .poster-person .av-svg{border-radius:50%}
.mp .hero-wrap{position:relative;margin:2px -4px 4px;text-align:center}
.mp .hero-greet{font-size:var(--fs-display);font-weight:800;letter-spacing:-.7px;margin:2px 0 2px}
.mp .hero-sub{font-size:var(--fs-caption);color:var(--ink-3);margin-bottom:2px}
.mp .hero-stage{width:100%;height:284px;position:relative}
.mp .hero-art{display:block}
.mp .hero-figure{animation:heroFloat 5.2s ease-in-out infinite;transform-origin:50% 100%}

@keyframes heroFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
.mp .hero-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 13px;border-radius:999px;background:var(--accent-soft);color:var(--accent);font-size:var(--fs-caption);font-weight:750;border:1px solid var(--accent-line)}
.mp .navwrap{position:absolute;left:0;right:0;bottom:0;height:var(--nav-h);z-index:70;pointer-events:none}
.mp .navbar{position:absolute;left:14px;right:14px;bottom:26px;height:66px;display:flex;align-items:center; pointer-events:auto;border-radius:28px; background:rgba(255,255,255,.72); backdrop-filter:blur(26px) saturate(180%); -webkit-backdrop-filter:blur(26px) saturate(180%); border:1px solid rgba(255,255,255,.85); box-shadow:0 14px 34px -12px rgba(20,26,44,.26), 0 2px 10px rgba(20,26,44,.06), inset 0 1px 0 rgba(255,255,255,.95);}
.mp .nav-item{flex:1;position:relative;display:flex;flex-direction:column;align-items:center;gap:4px; color:var(--ink-4);padding:8px 0 6px;transition:.18s;}
.mp .nav-item span{font-size:var(--fs-micro);font-weight:700}
.mp .nav-item.on{color:var(--accent)}
.mp .nav-item .dash{position:absolute;top:0;width:16px;height:2.5px;border-radius:999px;background:var(--accent);opacity:0;transition:.2s;}
.mp .nav-item.on .dash{opacity:1}
.mp .nav-center{flex:0 0 auto;width:80px;position:relative;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;padding-bottom:8px}
.mp .nav-center .bubble{position:absolute;top:-30px;width:62px;height:62px;border-radius:50%;display:grid;place-items:center; background:var(--accent-soft);color:var(--accent); border:1px solid var(--accent-line); box-shadow:0 0 0 7px rgba(255,255,255,.92), 0 10px 22px -8px rgba(20,26,44,.28); transition:.2s;}
.mp .nav-center.on .bubble{background:var(--accent-mid);color:#fff;border-color:transparent;transform:translateY(-2px)}
.mp .nav-center span{font-size:var(--fs-micro);font-weight:700;color:var(--ink-4)}
.mp .nav-center.on span{color:var(--accent)}
.mp .fab-wrap{position:absolute;right:var(--pad);bottom:calc(var(--nav-h) + 4px);z-index:75;display:flex;flex-direction:column;align-items:flex-end;gap:9px}
.mp .fab{width:52px;height:52px;border-radius:18px;display:grid;place-items:center;background:var(--black);color:#fff;box-shadow:var(--shadow-lg);transition:transform .24s cubic-bezier(.34,1.56,.64,1),background .16s,color .16s,box-shadow .16s}
.mp .fab.invert{background:#fff;color:var(--black);box-shadow:0 0 0 2.5px var(--black),0 12px 26px -10px rgba(20,26,44,.45)}
.mp .fab.invert svg{stroke:var(--black)}
.mp .fab.open{transform:rotate(135deg)}
.mp .fab-opt{display:flex;align-items:center;gap:9px;padding:11px 15px;border-radius:15px;background:var(--surface);border:1px solid var(--line);box-shadow:var(--shadow-md);font-size:var(--fs-label);font-weight:700;white-space:nowrap;animation:fabIn .22s cubic-bezier(.34,1.56,.64,1) both}
.mp .fab-opt:nth-child(2){animation-delay:.05s}

@keyframes fabIn{from{opacity:0;transform:translateY(8px) scale(.92)}to{opacity:1;transform:none}}
.mp .scrim{position:absolute;inset:0;z-index:80;background:rgba(21,24,33,.34);backdrop-filter:blur(3px);animation:fade .2s both;display:flex;flex-direction:column;justify-content:flex-end}
.mp .scrim.center{justify-content:center;padding:22px}

@keyframes fade{from{opacity:0}to{opacity:1}}
.mp .sheet{background:var(--surface);border-radius:28px 28px 0 0;max-height:88%;display:flex;flex-direction:column;overflow:hidden;animation:up .3s cubic-bezier(.22,1,.36,1) both;box-shadow:0 -16px 40px -14px rgba(20,26,44,.3)}

@keyframes up{from{transform:translateY(100%)}to{transform:none}}
.mp .sheet-head{flex:0 0 auto;padding:10px var(--pad) 13px;background:var(--surface);border-bottom:1px solid var(--line);z-index:2}
.mp .sheet-grab{width:38px;height:4px;border-radius:999px;background:var(--line-2);margin:0 auto 13px}
.mp .sheet-head-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
.mp .sheet-body{flex:1;overflow-y:auto;padding:16px var(--pad) 28px}
.mp .modal{background:var(--surface);border-radius:24px;padding:20px;box-shadow:var(--shadow-lg);animation:pop .24s cubic-bezier(.34,1.56,.64,1) both;max-height:82%;overflow-y:auto}

@keyframes pop{from{opacity:0;transform:scale(.93)}to{opacity:1;transform:none}}
.mp .dropdown{position:absolute;top:104px;left:var(--pad);z-index:85;width:230px;padding:6px;background:var(--surface);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow-lg);animation:pop .18s both}
.mp .dd-item{display:flex;align-items:center;gap:11px;width:100%;padding:11px;border-radius:14px}
.mp .dd-item .dd-nm{font-size:var(--fs-title);font-weight:650;flex:1;text-align:left}
.mp .dd-item .dd-rt{font-size:var(--fs-caption);font-weight:700;color:var(--ink-3)}
.mp .icon-btn{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;background:var(--surface);border:1px solid var(--line);color:var(--ink-2);box-shadow:var(--shadow-sm);flex:0 0 auto}
.mp .empty{display:flex;flex-direction:column;align-items:center;text-align:center;padding:46px 24px;gap:11px}
.mp .empty-ic{width:72px;height:72px;border-radius:26px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent)}
.mp .empty h3{margin:0;font-size:var(--fs-h2);font-weight:750}
.mp .empty p{margin:0;font-size:var(--fs-body);color:var(--ink-3);line-height:1.55;max-width:260px}
.mp .seg{display:flex;gap:3px;padding:3px;background:var(--surface-3);border-radius:14px;margin:2px 0 16px}
.mp .seg button{flex:1;padding:9px;border-radius:11px;font-size:var(--fs-label);font-weight:700;color:var(--ink-3)}
.mp .seg button.on{background:var(--surface);color:var(--ink);box-shadow:var(--shadow-sm)}
.mp .req-card{width:100%;display:flex;align-items:center;gap:12px;padding:13px;margin-bottom:14px;text-align:left;background:var(--surface);border:1px solid var(--line);border-radius:22px;box-shadow:var(--shadow-sm)}
.mp .req-ic{width:40px;height:40px;border-radius:14px;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent);flex:0 0 auto}
.mp .badge-n{min-width:22px;height:22px;padding:0 7px;border-radius:999px;background:var(--accent);color:#fff;font-size:var(--fs-micro);font-weight:800;display:grid;place-items:center}
.mp .rail{display:flex;gap:12px;overflow-x:auto;padding:2px var(--pad) 8px;margin:0 calc(var(--pad) * -1)}
.mp .rail>*{flex:0 0 auto}
.mp .poster{width:172px;border-radius:22px;overflow:hidden;background:var(--surface); border:1px solid var(--line);box-shadow:var(--shadow-sm);display:flex;flex-direction:column;}
.mp .poster-top{height:104px;position:relative;display:grid;place-items:center;overflow:hidden}
.mp .poster-top .glyph{position:absolute;right:-14px;bottom:-14px;opacity:.24}
.mp .poster-body{padding:12px 13px 14px;display:flex;flex-direction:column;gap:5px}
.mp .poster-t{font-size:var(--fs-title);font-weight:700;letter-spacing:-.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mp .poster-s{font-size:var(--fs-caption);color:var(--ink-3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mp .poster-foot{display:flex;align-items:center;justify-content:space-between;margin-top:4px}
.mp .poster-foot.bar{padding:10px 13px 12px;margin-top:0;border-top:1px solid var(--line)}
.mp .poster-top.venue{display:block;padding:0}
.mp .venue-art{display:block;width:100%;height:100%}
.mp .venue-kind{position:absolute;left:12px;top:12px;padding:4px 10px;border-radius:999px; background:rgba(255,255,255,.94);font-size:var(--fs-caption);font-weight:750;box-shadow:var(--shadow-sm);}
.mp .poster.wide{width:236px}
.mp .edit-btn{display:inline-flex;align-items:center;gap:5px;padding:6px 11px;border-radius:999px; background:var(--surface-2);border:1px solid var(--line-2);color:var(--ink-2); font-size:var(--fs-caption);font-weight:700;}
.mp .edit-btn:hover{background:var(--surface-3)}
.mp .open-btn{width:26px;height:26px;border-radius:50%;display:grid;place-items:center; background:var(--accent-soft);border:1px solid var(--accent-line);color:var(--accent);flex:0 0 auto;}
.mp .open-btn:hover{filter:brightness(.97)}
.mp .map-view{position:absolute;inset:0;overflow:hidden;background:#E6EBF4;touch-action:none;cursor:grab}
.mp .map-view.grabbing{cursor:grabbing}
.mp .map-world{position:absolute;left:0;top:0;width:760px;height:960px;transform-origin:0 0;will-change:transform}
.mp .map-world.anim{transition:transform .32s cubic-bezier(.22,.75,.28,1)}
.mp .map-world svg{position:absolute;inset:0;width:100%;height:100%}
.mp .map-locate{position:absolute;right:var(--pad);bottom:calc(var(--nav-h) + 8px);z-index:22;width:38px;height:38px;display:grid;place-items:center;border-radius:14px;background:#fff;border:1px solid var(--line);box-shadow:var(--shadow-md);color:var(--ink-2)}
.mp .map-me{position:absolute;z-index:5;width:16px;height:16px;border-radius:50%;background:var(--accent);border:3px solid #fff;box-shadow:0 0 0 6px var(--accent-soft),var(--shadow-sm);transform:translate(-50%,-50%)}
.mp .pin{position:absolute;z-index:6;width:50px;height:50px;border-radius:50%;cursor:pointer; background:#fff;border:2.5px solid #fff;transform-origin:50% 50%; box-shadow:0 0 0 1px var(--line),0 4px 11px rgba(20,26,44,.22);}
.mp .pin .av{position:absolute;left:50%;top:6px;transform:translateX(-50%)}
.mp .pin-rt{position:absolute;left:0;right:0;bottom:4.5px;text-align:center; font-size:10px;font-weight:800;line-height:1;color:var(--accent);letter-spacing:0;}
.mp .pin.linked{background:var(--black);border-color:var(--black); box-shadow:0 0 0 1px rgba(255,255,255,.55),0 5px 13px rgba(20,26,44,.36);}
.mp .pin.linked .pin-rt{color:#fff}
.mp .map-cluster{position:absolute;z-index:7;cursor:pointer;transform-origin:50% 50%}
.mp .map-cluster i{position:absolute;inset:14% 14%;border-radius:50%;background:#fff; border:2px solid var(--accent-line);box-shadow:0 2px 5px rgba(20,26,44,.14);}
.mp .map-cluster i.s1{transform:translate(-26%,-18%)}
.mp .map-cluster i.s2{transform:translate(26%,-18%);opacity:.72}
.mp .map-cluster .mc-face{position:absolute;inset:0;border-radius:50%;display:grid;place-items:center; background:#fff;border:2.5px solid var(--accent); box-shadow:0 0 0 5px var(--accent-soft),0 5px 14px rgba(20,26,44,.22);}
.mp .map-cluster .mc-n{font-weight:800;color:var(--accent);line-height:1}
.mp .map-filters{position:absolute;left:0;right:0;top:10px;z-index:20;display:flex;gap:8px;padding:0 var(--pad);align-items:center;overflow-x:auto}
.mp .gchip{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;white-space:nowrap; height:36px;padding:0 13px;border-radius:999px;background:#fff;border:1px solid var(--line); box-shadow:0 1px 3px rgba(20,26,44,.14);font-size:var(--fs-label);font-weight:650;color:var(--ink);}
.mp .gchip .gcaret{display:inline-flex;align-items:center;color:var(--ink-3);margin-left:1px}
.mp .gchip.on{background:var(--accent-soft);border-color:var(--accent-line);color:var(--accent)}
.mp .gchip.on .gcaret{color:var(--accent)}
.mp .gchip.clear{color:var(--ink-2)}
.mp .map-count{position:absolute;left:var(--pad);bottom:calc(var(--nav-h) + 8px);z-index:20;padding:8px 14px;border-radius:999px;background:#fff;border:1px solid var(--line);box-shadow:var(--shadow-md);font-size:var(--fs-caption);font-weight:700;color:var(--ink-2)}
.mp .row{display:flex;align-items:center;gap:12px;padding:11px 2px}
.mp .row-main{flex:1;min-width:0}
.mp .row-t{font-size:var(--fs-title);font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mp .row-s{font-size:var(--fs-label);color:var(--ink-3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;min-height:16px}
.mp .name-line{display:flex;align-items:center;gap:8px;min-width:0}
.mp .name-line .row-t{flex:0 1 auto}
.mp .nt{display:flex;align-items:center;gap:12px;padding:12px 2px;margin-bottom:6px}
.mp .nt.new{position:relative;padding-left:14px}
.mp .nt.new::before{content:'';position:absolute;left:0;top:12px;bottom:12px;width:3px;border-radius:999px;background:var(--accent)}
.mp .nt-tx{flex:1;min-width:0;font-size:var(--fs-body);line-height:1.45;color:var(--ink-2)}
.mp .nt-tx b{color:var(--ink);font-weight:700}
.mp .nt-tx i{font-style:normal;color:var(--ink-4);margin-left:5px;font-size:var(--fs-caption)}
.mp .nt-group{font-size:var(--fs-label);font-weight:800;color:var(--ink);margin:16px 2px 2px}
.mp .chat-wrap{flex:1;display:flex;flex-direction:column;overflow:hidden}
.mp .chat-body{flex:1;overflow-y:auto;padding:12px var(--pad) 16px;display:flex;flex-direction:column;gap:8px}
.mp .bub{max-width:76%;padding:10px 13px;border-radius:17px;font-size:var(--fs-body);line-height:1.45}
.mp .bub.them{background:var(--surface);border:1px solid var(--line);align-self:flex-start;border-bottom-left-radius:5px;box-shadow:var(--shadow-sm)}
.mp .bub.me{background:var(--accent);color:#fff;align-self:flex-end;border-bottom-right-radius:5px}
.mp .bub-t{font-size:var(--fs-micro);opacity:.65;margin-top:3px;text-align:right}
.mp .chat-input{flex:0 0 auto;display:flex;gap:9px;align-items:center;padding:10px var(--pad) 34px;background:rgba(255,255,255,.92);backdrop-filter:blur(16px);border-top:1px solid var(--line)}
.mp .chat-input .input{padding:12px 15px;border-radius:999px}
.mp .day-sep{align-self:center;font-size:var(--fs-micro);font-weight:700;color:var(--ink-3);background:var(--surface-3);padding:5px 11px;border-radius:999px;margin:4px 0}
.mp .stat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}
.mp .stat{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:13px 9px;text-align:center;box-shadow:var(--shadow-sm)}
.mp .stat b{display:block;font-size:var(--fs-h1);font-weight:800;letter-spacing:-.4px}
.mp .stat span{font-size:var(--fs-micro);font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--ink-3)}
.mp .bars{display:flex;align-items:flex-end;gap:6px;height:86px;padding-top:6px}
.mp .bars .b{flex:1;border-radius:6px 6px 4px 4px;background:linear-gradient(180deg,var(--accent-mid),var(--accent-soft));min-height:6px}
.mp .bars .b.loss{background:linear-gradient(180deg,#D9DEE8,#F1F3F8)}
.mp .stars{display:inline-flex;gap:2px}
.mp .meter{height:6px;border-radius:999px;background:var(--surface-3);overflow:hidden;margin-top:6px}
.mp .meter i{display:block;height:100%;border-radius:999px;background:var(--accent-mid)}
.mp .rating-card{display:flex;width:100%;background:var(--surface);border:1px solid var(--line);border-radius:20px;overflow:hidden;box-shadow:var(--shadow-sm)}
.mp .rating-card>div{flex:1;padding:14px 8px;text-align:center}
.mp .rating-card>div+div{border-left:1px solid var(--line)}
.mp .rating-card small{display:block;font-size:var(--fs-micro);font-weight:800;letter-spacing:.11em;color:var(--ink-3);margin-bottom:5px}
.mp .rating-card b{font-size:var(--fs-h1);font-weight:800;letter-spacing:-.4px}
.mp .cal-head{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.mp .cal-title{flex:1;font-size:var(--fs-h2);font-weight:750;letter-spacing:-.3px}
.mp .cal-nav{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;background:var(--surface);border:1px solid var(--line);box-shadow:var(--shadow-sm)}
.mp .cal-days{display:grid;grid-template-columns:34px repeat(7,1fr);border-bottom:1px solid var(--line);padding-bottom:8px;margin-bottom:2px}
.mp .cal-day{text-align:center}
.mp .cal-day .dw{font-size:var(--fs-micro);font-weight:700;color:var(--ink-3);text-transform:uppercase}
.mp .cal-day .dn{margin:4px auto 0;width:27px;height:27px;border-radius:50%;display:grid;place-items:center;font-size:var(--fs-caption);font-weight:700}
.mp .cal-day.today .dn{background:var(--accent);color:#fff}
.mp .cal-grid{position:relative;display:grid;grid-template-columns:34px repeat(7,1fr);height:640px}
.mp .cal-hours{position:relative}
.mp .cal-hours .hr{position:absolute;left:0;right:4px;text-align:right;font-size:var(--fs-micro);color:var(--ink-4);transform:translateY(-6px)}
.mp .cal-col{position:relative;border-left:1px solid var(--line)}
.mp .cal-line{position:absolute;left:0;right:0;height:1px;background:var(--line)}
.mp .cal-ev{position:absolute;border-radius:6px;padding:3px 4px;overflow:hidden; font-size:9.5px;font-weight:700;line-height:1.15;color:#fff;box-shadow:0 1px 3px rgba(20,26,44,.18);}
.mp .cal-ev.past{opacity:.55}
.mp .cal-ev.dim{opacity:.26;box-shadow:none}
.mp .cal-ev.tent{background-image:repeating-linear-gradient(45deg,rgba(255,255,255,.85) 0 3px,transparent 3px 7px);box-shadow:none}
.mp .cal-key{display:flex;flex-wrap:wrap;gap:8px 14px;margin:12px 2px 0}
.mp .cal-key .ck{display:inline-flex;align-items:center;gap:6px;font-size:var(--fs-caption);font-weight:650;color:var(--ink-3)}
.mp .cal-key .ck i{width:11px;height:11px;border-radius:3.5px;flex:0 0 auto}
.mp .cal-key .ck i.tent{border:1.5px solid;background-image:repeating-linear-gradient(45deg,rgba(255,255,255,.85) 0 3px,transparent 3px 7px)}
.mp .cal-key .ck i.dim{opacity:.26}
.mp .slot{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:10px 12px;margin-bottom:7px;border-radius:13px;background:var(--surface-2);border:1px solid var(--line);font-size:var(--fs-label);font-weight:650;color:var(--ink-2)}
.mp .slot.pick{background:var(--surface);border-color:var(--accent-line);color:var(--ink)}
.mp .slot.picked{background:var(--accent-soft);border-color:var(--accent-line);color:var(--accent)}
.mp .slot .slot-go, .mp .slot .slot-tick{margin-left:auto;display:inline-flex;color:var(--accent)}
.mp .slot-row{display:flex;align-items:center;gap:7px;margin-bottom:8px}
.mp .slot-row .slot-n{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;flex:0 0 auto;background:var(--accent-soft);color:var(--accent);font-size:var(--fs-micro);font-weight:800}
.mp .slot-row .input{flex:1;min-width:0;padding-left:11px;padding-right:26px}
.mp .slot-x{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;color:var(--ink-4);flex:0 0 auto}
.mp .ch-card{align-self:flex-start;max-width:86%;padding:12px 13px;border-radius:17px;background:var(--surface);border:1px solid var(--accent-line);box-shadow:var(--shadow-sm)}
.mp .ch-card.me{align-self:flex-end}
.mp .ch-top{display:flex;align-items:center;gap:8px;margin-bottom:3px}
.mp .ch-top .ch-t{font-size:var(--fs-label);font-weight:750;color:var(--ink)}
.mp .chat-note{display:flex;gap:10px;align-items:flex-start;margin:2px 0 6px;padding:12px 13px;border-radius:15px;background:var(--accent-soft);border:1px solid var(--accent-line);color:var(--accent);font-size:var(--fs-caption);font-weight:600;line-height:1.45}
.mp .cal-now{position:absolute;left:34px;right:0;height:2px;background:#E0574F;z-index:4}
.mp .cal-now::before{content:'';position:absolute;left:-4px;top:-3px;width:8px;height:8px;border-radius:50%;background:#E0574F}
.mp .victory{position:absolute;inset:0;z-index:95;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:32px 26px;background:radial-gradient(560px 400px at 50% 24%,var(--accent-soft),transparent 66%),var(--bg);animation:fade .3s both}
.mp .victory .vk{font-size:var(--fs-micro);font-weight:800;letter-spacing:.24em;color:var(--accent)}
.mp .victory .vt{font-size:var(--fs-display);font-weight:800;letter-spacing:-.6px;margin:14px 0 6px;line-height:1.2}
.mp .victory .vs{font-size:var(--fs-body);color:var(--ink-2)}
.mp .vring{width:116px;height:116px;border-radius:50%;display:grid;place-items:center;margin:20px 0 2px;background:var(--surface);box-shadow:0 0 0 4px var(--accent-soft),0 0 0 6px var(--accent-line),var(--shadow-md);font-size:52px;animation:pop .5s cubic-bezier(.34,1.56,.64,1) both}
.mp .confetti{position:absolute;inset:0;pointer-events:none;overflow:hidden}
.mp .confetti i{position:absolute;width:7px;height:11px;border-radius:2px;animation:fall linear infinite}

@keyframes fall{0%{transform:translateY(-40px) rotate(0);opacity:1}100%{transform:translateY(900px) rotate(540deg);opacity:0}}
.mp .welcome{position:absolute;inset:0;z-index:95;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(520px 380px at 50% 44%,var(--accent-soft),transparent 66%),var(--bg);text-align:center;padding:30px}
.mp .wm-orb{width:108px;height:108px;border-radius:50%;display:grid;place-items:center;font-size:46px;background:linear-gradient(155deg,var(--accent-mid),var(--accent));color:#fff;box-shadow:0 14px 34px -10px var(--accent);animation:orb 1.4s cubic-bezier(.22,1,.36,1) both}

@keyframes orb{0%{transform:scale(.3);opacity:0}50%{transform:scale(1.1);opacity:1}100%{transform:scale(1)}}
.mp .wm-rings i{position:absolute;left:50%;top:50%;border:1.5px solid var(--accent-line);border-radius:50%;transform:translate(-50%,-50%);animation:ring 2.6s ease-out infinite}
.mp .wm-rings i:nth-child(2){animation-delay:.8s}
.mp .wm-rings i:nth-child(3){animation-delay:1.6s}

@keyframes ring{0%{width:70px;height:70px;opacity:.9}100%{width:340px;height:340px;opacity:0}}
.mp .wm-txt{font-size:var(--fs-display);font-weight:800;letter-spacing:-.5px;margin-top:30px;animation:rise .7s .45s cubic-bezier(.22,1,.36,1) both}
.mp .wm-sub{font-size:var(--fs-body);color:var(--ink-2);margin-top:8px;animation:rise .7s .7s cubic-bezier(.22,1,.36,1) both}

@keyframes rise{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
.mp .ob-wrap{flex:1;display:flex;flex-direction:column;overflow:hidden;position:relative;z-index:1}
.mp .ob-scroll{flex:1;overflow-y:auto;padding:0 var(--pad) 24px}
.mp .ob-foot{flex:0 0 auto;padding:14px var(--pad) 30px;background:linear-gradient(180deg,rgba(247,248,251,0),var(--bg) 26%); position:relative;z-index:3;}
.mp .ob-top{display:flex;align-items:center;padding:2px 0 16px}
.mp .back{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;background:var(--surface);border:1px solid var(--line);box-shadow:var(--shadow-sm)}
.mp .hero{height:186px;border-radius:26px;position:relative;overflow:hidden;margin-bottom:22px;border:1px solid var(--line)}
.mp .hero i{position:absolute;animation:float 5s ease-in-out infinite;filter:drop-shadow(0 4px 10px rgba(20,26,44,.07))}

@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
.mp .progress{height:3px;border-radius:999px;background:var(--surface-3);overflow:hidden;margin-bottom:18px}
.mp .progress i{display:block;height:100%;background:var(--black);border-radius:999px;transition:width .4s cubic-bezier(.22,1,.36,1)}
.mp .sport-row{width:100%;display:flex;align-items:center;gap:14px;padding:15px 16px;margin-bottom:11px; border-radius:20px;background:var(--surface);border:1.5px solid var(--line); box-shadow:var(--shadow-sm);text-align:left;transition:.16s;}
.mp .sport-row .sr-ic{width:52px;height:52px;border-radius:17px;display:grid;place-items:center;flex:0 0 auto}
.mp .sport-row .sr-nm{font-size:var(--fs-title);font-weight:750;letter-spacing:-.2px}
.mp .sport-row .sr-sub{font-size:var(--fs-caption);color:var(--ink-3);margin-top:3px}
.mp .sport-row .sr-ck{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;border:1.5px solid var(--line-2);flex:0 0 auto}
.mp .sport-row.on .sr-ck{border-color:transparent}
.mp .setup-card{position:relative;overflow:hidden;border-radius:22px;padding:17px;margin-bottom:12px;background:var(--surface);border:1px solid var(--line);box-shadow:var(--shadow-sm)}
.mp .setup-card .sc-wash{position:absolute;right:-28px;top:-28px;width:136px;height:136px;border-radius:50%}
.mp .setup-card .sc-ic{position:absolute;right:17px;top:17px}
.mp .setup-card .sc-nm{font-size:var(--fs-label);font-weight:750;position:relative}
.mp .setup-card .sc-val{font-size:36px;font-weight:800;letter-spacing:-1.2px;line-height:1.05;margin-top:3px;position:relative}
.mp .setup-card .sc-val.text{font-size:23px;letter-spacing:-.5px}
.mp .setup-card .sc-sub{font-size:var(--fs-caption);color:var(--ink-3);margin-top:6px;position:relative}
.mp .setup-card .sc-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:16px;position:relative}
.mp .checkrow{display:flex;gap:11px;align-items:center;cursor:pointer}
.mp .tl{position:relative;padding-left:18px}
.mp .tl::before{content:'';position:absolute;left:4px;top:6px;bottom:6px;width:1.5px;background:var(--line)}
.mp .tl-item{position:relative;padding:8px 0}
.mp .tl-item::before{content:'';position:absolute;left:-18px;top:14px;width:9px;height:9px;border-radius:50%;background:var(--accent-mid);box-shadow:0 0 0 3px var(--surface)}
.mp .toast{position:absolute;left:var(--pad);right:var(--pad);bottom:calc(var(--nav-h) + 58px);z-index:88;background:var(--ink);color:#fff;border-radius:15px;padding:12px 15px;display:flex;gap:10px;align-items:center;font-size:var(--fs-label);font-weight:600;animation:rise .26s both;box-shadow:var(--shadow-lg)}
.mp .toast .tk{width:7px;height:7px;border-radius:50%;background:var(--accent-mid);flex:0 0 auto}
.mp .fade-in{animation:rise .3s cubic-bezier(.22,1,.36,1) both}
.mp .hide{display:none !important}
.mp .grid2{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
.mp .kv{display:flex;justify-content:space-between;align-items:center;padding:9px 0;font-size:var(--fs-body)}
.mp .kv span{color:var(--ink-3)}
.mp .kv b{font-weight:700}
.mp .device{position:relative;flex:0 0 auto;width:426px;height:898px;border-radius:56px;padding:12px;
  background:linear-gradient(150deg,#9BA3B4,#5D6577 26%,#3E4453 52%,#767E90 78%,#B7BDC9);
  box-shadow:0 30px 70px -18px rgba(20,26,44,.5), inset 0 0 0 1px rgba(255,255,255,.35)}
.mp .sim-bar{width:100%;max-width:940px}`;

/* ---------------------------------------------------------------
   Sports — permanent colour per sport
   --------------------------------------------------------------- */
const SPORTS = {
  pickleball: { name: "Pickleball", cat: "individual", colour: "Light green",  accent: "#4CA85F", mid: "#8FD3A0", soft: "#EFF8F1", line: "#CFEBD6" },
  badminton:  { name: "Badminton",  cat: "individual", colour: "Light blue",   accent: "#3D82C4", mid: "#9AC4EC", soft: "#ECF3FB", line: "#C9DFF5" },
  pingpong:   { name: "Ping Pong",  cat: "individual", colour: "Light orange", accent: "#D0762F", mid: "#F2BE93", soft: "#FDF3E9", line: "#F7DCC2" },
  cricket:    { name: "Cricket",    cat: "group",      colour: "Light red",    accent: "#CE5555", mid: "#EFA0A0", soft: "#FCEEEE", line: "#F5D0D0" },
  soccer:     { name: "Soccer",     cat: "group",      colour: "Green",        accent: "#2F7A50", mid: "#85C2A0", soft: "#EAF5EF", line: "#C2E0CF" },
  volleyball: { name: "Volleyball", cat: "group",      colour: "Purple",       accent: "#7857BE", mid: "#B7A0E6", soft: "#F3EEFC", line: "#DED0F6" },
};
const INDIVIDUAL = ["pickleball", "badminton", "pingpong"];
const GROUP = ["cricket", "soccer", "volleyball"];
const ALL_SPORTS = [...INDIVIDUAL, ...GROUP];
const isIndividual = (k) => SPORTS[k] && SPORTS[k].cat === "individual";
const paletteOf = (k) => SPORTS[k] || SPORTS.pickleball;

function SportIcon({ sport, size = 22, color = "currentColor" }) {
  const p = { width: size, height: size, viewBox: "0 0 24 24", fill: "none" };
  switch (sport) {
    case "pickleball":
      return (<svg {...p}><circle cx="12" cy="12" r="9.2" stroke={color} strokeWidth="1.6" />
        {[[8.6,9],[12,7.4],[15.4,9],[8.6,14.6],[12,16.2],[15.4,14.6],[12,11.8]].map(([cx,cy],i)=><circle key={i} cx={cx} cy={cy} r="1.15" fill={color}/>)}</svg>);
    case "badminton":
      return (<svg {...p}><path d="M12 22a3.3 3.3 0 003.3-3.3H8.7A3.3 3.3 0 0012 22z" fill={color}/>
        <path d="M8.7 18.7L5.1 6.4 12 2l6.9 4.4-3.6 12.3" stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
        <path d="M12 2v16.7M8.4 5.2l1.5 13.5M15.6 5.2l-1.5 13.5M5.9 9.1h12.2M7 13h10" stroke={color} strokeWidth="1.1" strokeOpacity=".7"/></svg>);
    case "pingpong":
      return (<svg {...p}><path d="M13.6 3.1c3.6 1 5.9 4.3 5.3 8-.5 3-2.6 5.1-5.3 5.9l1.5 3.5a1.5 1.5 0 01-2.7 1.2l-1.6-3.6c-3.6-.5-6.3-3.4-6.3-7.2 0-4.6 4.2-9 9.1-7.8z" stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
        <circle cx="19.4" cy="17.6" r="2.4" fill={color}/></svg>);
    case "cricket":
      return (<svg {...p}><circle cx="12" cy="12" r="9.2" stroke={color} strokeWidth="1.6"/>
        <path d="M7.4 4.3a20 20 0 000 15.4" stroke={color} strokeWidth="1.4"/>
        <path d="M9.4 5.1a18 18 0 000 13.8" stroke={color} strokeWidth="1.1" strokeOpacity=".65"/>
        <path d="M8 6.6h1.6M8 9.4h1.6M8 12h1.6M8 14.6h1.6M8 17.4h1.6" stroke={color} strokeWidth="1.1" strokeLinecap="round"/></svg>);
    case "soccer":
      return (<svg {...p}><circle cx="12" cy="12" r="9.2" stroke={color} strokeWidth="1.6"/>
        <path d="M12 7.1l3.6 2.6-1.4 4.3H9.8L8.4 9.7 12 7.1z" fill={color}/>
        <path d="M12 2.8v4.3M20.9 10.2l-5.3-.5M17.6 20.3l-3.4-6.3M6.4 20.3l3.4-6.3M3.1 10.2l5.3-.5" stroke={color} strokeWidth="1.3"/></svg>);
    default:
      return (<svg {...p}><circle cx="12" cy="12" r="9.2" stroke={color} strokeWidth="1.6"/>
        <path d="M12 2.8c-3.4 4-3.9 12.4 1.4 18.2M21 9.6c-5 .6-11.4 4.8-12.4 11.2M4 6.2c1.8 4.7 8.5 8.6 15.5 7.5" stroke={color} strokeWidth="1.4" strokeLinecap="round"/></svg>);
  }
}
const sk = (size, d, w = 1.8) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const Ico = {
  home:(s=22)=>sk(s,<><path d="M3 10.2L12 3l9 7.2V20a1.4 1.4 0 01-1.4 1.4H4.4A1.4 1.4 0 013 20z"/><path d="M9.2 21.4v-7h5.6v7"/></>),
  map:(s=21)=>sk(s,<><path d="M9 3L3 5.4v15.2L9 18l6 3 6-2.4V3.4L15 6z"/><path d="M9 3v15M15 6v15"/></>,1.7),
  matches:(s=21)=>sk(s,<><rect x="3" y="4.4" width="18" height="16.2" rx="3"/><path d="M8 2.6v3.6M16 2.6v3.6M3 9.8h18M8.4 14.4l2.2 2.2 4.4-4.4"/></>,1.7),
  calendar:(s=21)=>sk(s,<><rect x="3" y="4.4" width="18" height="16.2" rx="3"/><path d="M8 2.6v3.6M16 2.6v3.6M3 9.8h18"/>
    <circle cx="8.4" cy="14" r="1.1" fill="currentColor" stroke="none"/><circle cx="12" cy="14" r="1.1" fill="currentColor" stroke="none"/>
    <circle cx="15.6" cy="14" r="1.1" fill="currentColor" stroke="none"/><circle cx="8.4" cy="17.4" r="1.1" fill="currentColor" stroke="none"/>
    <circle cx="12" cy="17.4" r="1.1" fill="currentColor" stroke="none"/></>,1.7),
  friends:(s=21)=>sk(s,<><path d="M15.6 20.4v-1.8a3.6 3.6 0 00-3.6-3.6H6a3.6 3.6 0 00-3.6 3.6v1.8"/><circle cx="9" cy="7.4" r="3.6"/><path d="M21.6 20.4v-1.8a3.6 3.6 0 00-2.7-3.5M16.2 4a3.6 3.6 0 010 7"/></>,1.7),
  profile:(s=21)=>sk(s,<><circle cx="12" cy="8" r="4.2"/><path d="M4.2 21a7.8 7.8 0 0115.6 0"/></>,1.7),
  back:(s=18)=>sk(s,<path d="M15 19l-7-7 7-7"/>,2.1),
  chev:(s=15)=>sk(s,<path d="M9 5l7 7-7 7"/>,2.1),
  chevL:(s=15)=>sk(s,<path d="M15 5l-7 7 7 7"/>,2.1),
  down:(s=12)=>sk(s,<path d="M6 9.5l6 6 6-6"/>,2.6),
  plus:(s=22)=>sk(s,<path d="M12 5v14M5 12h14"/>,2.3),
  minus:(s=22)=>sk(s,<path d="M5 12h14"/>,2.3),
  locate:(s=16)=>sk(s,<><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.4" fill="currentColor" stroke="none"/><path d="M12 1.6v3.2M12 19.2v3.2M22.4 12h-3.2M4.8 12H1.6"/></>,1.9),
  edit:(s=14)=>sk(s,<path d="M16.5 3.5a2.1 2.1 0 013 3L7.5 18.5l-4 1 1-4z"/>,1.9),
  close:(s=17)=>sk(s,<path d="M18 6L6 18M6 6l12 12"/>,2.1),
  search:(s=16)=>sk(s,<><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/></>,2),
  bell:(s=18)=>sk(s,<><path d="M18 8.6a6 6 0 10-12 0c0 6.4-2.4 8.2-2.4 8.2h16.8S18 15 18 8.6z"/><path d="M13.7 20.6a2 2 0 01-3.4 0"/></>),
  gallery:(s=17)=>sk(s,<><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.6" cy="8.6" r="1.9"/><path d="M21 15.4l-4.6-4.6L4.6 22"/></>),
  camera:(s=17)=>sk(s,<><path d="M22 18.4a2 2 0 01-2 2H4a2 2 0 01-2-2V8.6a2 2 0 012-2h3.2L9 3.6h6l1.8 3H20a2 2 0 012 2z"/><circle cx="12" cy="13" r="3.8"/></>),
  pin:(s=15)=>sk(s,<><path d="M20 10.4c0 6.4-8 12.4-8 12.4s-8-6-8-12.4a8 8 0 1116 0z"/><circle cx="12" cy="10.2" r="2.8"/></>),
  trophy:(s=17)=>sk(s,<><path d="M7 4h10v5.4a5 5 0 01-10 0z"/><path d="M7 5.4H4.4v1.8A3.6 3.6 0 007.4 10.7M17 5.4h2.6v1.8a3.6 3.6 0 01-3 3.5M9.4 14.4h5.2l.6 5.6H8.8z"/><path d="M7.4 20h9.2"/></>,1.7),
  chart:(s=17)=>sk(s,<><path d="M3 20.4h18"/><path d="M6.4 20.4v-6.8M11.4 20.4V6.6M16.4 20.4v-9.6M21 20.4V9"/></>),
  trash:(s=15)=>sk(s,<path d="M3.6 6h16.8M8.4 6V4.2A1.6 1.6 0 0110 2.6h4a1.6 1.6 0 011.6 1.6V6m2.6 0v14a1.6 1.6 0 01-1.6 1.6H7.4A1.6 1.6 0 015.8 20V6"/>),
  settings:(s=17)=>sk(s,<><circle cx="12" cy="12" r="3.2"/><path d="M19.2 15a1.6 1.6 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.6 1.6 0 00-2.7 1.1v.2a2 2 0 11-4 0v-.1a1.6 1.6 0 00-2.8-1.1l-.1.1a2 2 0 11-2.8-2.8l.1-.1A1.6 1.6 0 003.5 15a2 2 0 010-3.9h.2A1.6 1.6 0 004.8 8.4l-.1-.1a2 2 0 112.8-2.8l.1.1a1.6 1.6 0 001.8.3h.1a1.6 1.6 0 001-1.5v-.2a2 2 0 114 0v.2a1.6 1.6 0 002.7 1.1l.1-.1a2 2 0 112.8 2.8l-.1.1a1.6 1.6 0 00-.3 1.8v.1a1.6 1.6 0 001.5 1h.2a2 2 0 010 4h-.2a1.6 1.6 0 00-1.5 1z"/></>,1.7),
  users:(s=16)=>sk(s,<><path d="M16 20v-1.6a4 4 0 00-4-4H6a4 4 0 00-4 4V20"/><circle cx="9" cy="6.6" r="3.4"/><path d="M22 20v-1.6a4 4 0 00-3-3.9"/></>),
  userplus:(s=17)=>sk(s,<><path d="M15 20v-1.6a4 4 0 00-4-4H6a4 4 0 00-4 4V20"/><circle cx="8.5" cy="6.6" r="3.4"/><path d="M19 8v6M22 11h-6"/></>),
  /* Two interlocking links. Connecting is a two-way thing, and this
     reads that way without borrowing the friend or message icons. */
  connect:(s=17,c="currentColor")=>(
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9.4 14.6l5.2-5.2"/>
      <path d="M12.7 6.1l1.6-1.6a3.9 3.9 0 015.5 5.5l-1.6 1.6"/>
      <path d="M11.3 17.9l-1.6 1.6a3.9 3.9 0 01-5.5-5.5l1.6-1.6"/>
    </svg>),
  media:(s=16)=>sk(s,<><rect x="3" y="4" width="18" height="16" rx="2.6"/><path d="M3 15l4.4-4.4 4 4 3-3L21 17"/></>),
  block:(s=16)=>sk(s,<><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></>),
  send:(s=17)=>(<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.5 12L2.5 21l3.4-9-3.4-9z"/><path d="M5.9 12h15.6"/></svg>),
  check:(s=12,c="#fff")=>(<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>),
  warn:(s=24)=>(<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="#D0762F" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M10.3 3.6L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3l-8.5-14.4a2 2 0 00-3.4 0z"/><path d="M12 9.4v4.2M12 17.4h.01"/></svg>),
  star:(s=14,f="var(--accent-mid)")=>(<svg width={s} height={s} viewBox="0 0 24 24" fill={f}><path d="M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3-5.8 3 1.1-6.5L2.6 9.4l6.5-.9z"/></svg>),
  starO:(s=14)=>(<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="#D9DEE8" strokeWidth="1.6" strokeLinejoin="round"><path d="M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3-5.8 3 1.1-6.5L2.6 9.4l6.5-.9z"/></svg>),
};

/* ---------------------------------------------------------------
   Copy
   --------------------------------------------------------------- */
const PEER_SKILLS = {
  cricket: ["Batting", "Bowling", "Fielding"],
  soccer: ["Attacking", "Passing", "Defending"],
  volleyball: ["Serving", "Setting", "Blocking"],
};
const PEER_COPY = {
  cricket: "Cricket does not use a numerical MP Rating. After every match, the players you shared a pitch with rate you out of five stars on Batting, Bowling, and Fielding. Your profile shows the rolling average of those three categories, so an all-rounder and a specialist bowler both get a fair picture. Ratings only count once at least three teammates have submitted them, which keeps a single bad afternoon from defining you.",
  soccer: "Soccer uses peer evaluation instead of a numerical MP Rating. Teammates and opponents rate you out of five stars on Attacking, Passing, and Defending after the final whistle. The rolling average is shown on your profile so a Sunday league captain can see where you actually contribute.",
  volleyball: "Volleyball relies on post-match peer skill evaluations. Everyone on court rates you out of five stars on Serving, Setting, and Blocking. Because rotations move players through every position, the three-category split gives a much fairer read than one combined number.",
};
const RATING_COPY = [
  "The MP Rating is a single number that describes your current level in this sport. Everyone starts at 80. After each verified match the number moves in small, proportional steps, so one result never swings your level dramatically.",
  "Beating an evenly matched opponent earns one or two points. Beating someone rated above you earns three. A win against a significantly stronger opponent earns four or five. Losses move the same amounts in the opposite direction, and the size of every change depends on the gap between the two ratings.",
  "Your rating decides which players are recommended to you on the map and on your home screen, so keeping it accurate is what makes matchmaking feel fair.",
];
const OPTOUT_COPY = [
  "Opting out removes the number from your profile entirely. You appear on the map as an unrated player, and you are matched purely on the sports you play rather than on a level.",
  "You can still send and accept challenges, log scores, and keep a complete match history. Nothing you play will ever adjust a competitive score, and no opponent will see a rating next to your name. You can opt back in at any time from your profile settings, and your rating restarts at 80.",
];

/* ---------------------------------------------------------------
   Avatars, seed data, helpers
   --------------------------------------------------------------- */
const AV_TINTS = ["#EDF3FE", "#FFF3E9", "#EBF8F1", "#F4EFFD", "#FDEEF3", "#FFF8E2", "#EAF6F8", "#F6F0E8"];

/* ================================================================
   ILLUSTRATED PEOPLE
   Fifty drawn characters built from skin, hair, and kit variants.
   Each one breathes and blinks so the app never feels static.
   ================================================================ */
const SKIN  = ['#F5D0AE','#EBBB94','#DCA278','#C4875B','#A06841','#7E4F30','#F9E0C7','#D2976C','#E5AE86','#B57748'];
const SKIN_D= ['#E0B58F','#D29A74','#C0845B','#A66C44','#834F2F','#603A22','#E6C6A6','#B47B52','#CA9068','#955E36'];
const HAIR  = ['#221A13','#48331F','#7A4A24','#C08340','#E0C07A','#101010','#5C3A2E','#8E5A3C','#3A2A20','#A33F2E'];
/* Kit colours plus the shape of what they are wearing. */
const KIT   = ['#3D82C4','#4CA85F','#CE5555','#D0762F','#7857BE','#2F7A50','#E4E8F0','#2F3A4A','#E8A0B4','#22B3A6'];

/* One drawn person, cropped to a circle. Mostly young, always styled. */
function personSVG(idx, size){
  const i=((idx%50)+50)%50;
  const sk=SKIN[i%10], skd=SKIN_D[i%10], hr=HAIR[(i*3)%10], kit=KIT[(i*7)%10], bg=AV_TINTS[i%8];
  const hairStyle=i%12, kitStyle=i%6;
  const beard=(i%11===4), glasses=(i%9===2), freckles=(i%13===5);
  const band=['#F5F7FA','#2F3A4A','#CE5555','#3D82C4','#4CA85F','#D0762F'][(i*5)%6];

  /* Twelve hair and headwear treatments. */
  const HAIRS = [
    /* 0 tousled short */
    `<path d="M25 47c-1-19 12-27 25-27s26 8 25 27c-1-7-4-11-4-11-3 3-8 4-13 2-4 4-13 6-19 2-4 3-9 3-11 1 0 0-2 3-3 6z" fill="${hr}"/>`,
    /* 1 wavy bob */
    `<path d="M24 48c0-19 12-28 26-28s26 9 26 28v16c-2-4-5-6-5-6 3-9-1-16-6-19-6 4-19 6-27 1-5 3-8 10-6 18 0 0-4 2-5 6z" fill="${hr}"/>
     <path d="M24 60c-3 8-1 16 2 20 2-6 2-13 1-18zM76 60c3 8 1 16-2 20-2-6-2-13-1-18z" fill="${hr}"/>`,
    /* 2 afro */
    `<g fill="${hr}"><circle cx="32" cy="36" r="13"/><circle cx="46" cy="26" r="14"/><circle cx="61" cy="28" r="13"/><circle cx="70" cy="40" r="12"/><circle cx="50" cy="36" r="15"/></g>`,
    /* 3 top knot */
    `<path d="M26 46c0-18 12-26 24-26s24 8 24 26c-2-9-8-14-24-14s-22 5-24 14z" fill="${hr}"/>
     <circle cx="50" cy="13" r="9" fill="${hr}"/><rect x="43" y="19" width="14" height="5" rx="2.5" fill="${hr}"/>`,
    /* 4 long straight */
    `<path d="M23 48c0-20 13-29 27-29s27 9 27 29v28h-8V46c0-10-8-15-19-15s-19 5-19 15v30h-8z" fill="${hr}"/>`,
    /* 5 ponytail */
    `<path d="M26 46c0-18 12-27 24-27s24 9 24 27c-2-10-9-15-24-15s-22 5-24 15z" fill="${hr}"/>
     <path d="M74 42c8 2 12 10 11 20-1 9-5 14-9 16 3-6 4-13 2-19-2-7-5-12-8-14z" fill="${hr}"/>`,
    /* 6 headscarf */
    `<path d="M22 50c0-20 13-30 28-30s28 10 28 30c0 9-3 16-6 20l-5-26c-9-7-34-7-42 0l-5 26c-3-4-6-11-6-20z" fill="${band}"/>
     <path d="M22 50c-3 16 4 28 4 28h48s7-12 4-28z" fill="${band}" opacity=".82"/>`,
    /* 7 baseball cap */
    `<path d="M26 44c0-17 11-25 24-25s24 8 24 25v3H26z" fill="${band}"/>
     <path d="M26 44h-14c-3 0-4 3-1 5l16 4z" fill="${band}" opacity=".9"/>
     <path d="M50 19c-6 6-8 16-8 25h5c0-9 2-19 6-24z" fill="#fff" opacity=".22"/>
     <path d="M26 52c2 4 4 6 4 6h40s2-2 4-6z" fill="${hr}"/>`,
    /* 8 curly crop */
    `<g fill="${hr}"><circle cx="34" cy="38" r="9"/><circle cx="44" cy="30" r="10"/><circle cx="56" cy="30" r="10"/><circle cx="66" cy="39" r="9"/><rect x="30" y="34" width="40" height="12" rx="6"/></g>`,
    /* 9 beanie */
    `<path d="M25 46c0-18 11-27 25-27s25 9 25 27z" fill="${band}"/>
     <rect x="23" y="43" width="54" height="9" rx="4.5" fill="${band}"/>
     <path d="M23 43h54v4H23z" fill="#000" opacity=".08"/>`,
    /* 10 braids */
    `<path d="M26 46c0-18 12-27 24-27s24 9 24 27c-2-10-9-15-24-15s-22 5-24 15z" fill="${hr}"/>
     <path d="M27 48c-5 6-6 16-4 26 3-3 5-8 5-13zM73 48c5 6 6 16 4 26-3-3-5-8-5-13z" fill="${hr}"/>
     <circle cx="25" cy="76" r="3.4" fill="${band}"/><circle cx="75" cy="76" r="3.4" fill="${band}"/>`,
    /* 11 fade with a part */
    `<path d="M27 45c0-16 11-24 23-24s23 8 23 24c-2-8-7-12-13-13-2 3-6 5-11 5-8 0-14 2-16 8z" fill="${hr}"/>
     <path d="M60 22c-3 4-4 8-4 11" stroke="${sk}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`
  ];

  /* Six things to wear. */
  const KITS = [
    /* 0 crew tee */
    `<path d="M10 100c0-20 18-30 40-30s40 10 40 30z" fill="${kit}"/>
     <path d="M40 70h20l-10 9z" fill="#000" opacity=".14"/>`,
    /* 1 collared polo */
    `<path d="M10 100c0-20 18-30 40-30s40 10 40 30z" fill="${kit}"/>
     <path d="M41 70l9 10 9-10 6 3-15 14-15-14z" fill="#fff" opacity=".9"/>
     <path d="M48 80h4v14h-4z" fill="#000" opacity=".1"/>`,
    /* 2 hoodie */
    `<path d="M10 100c0-20 18-30 40-30s40 10 40 30z" fill="${kit}"/>
     <path d="M34 72c4 10 10 15 16 15s12-5 16-15l6 3c-5 14-13 20-22 20s-17-6-22-20z" fill="#000" opacity=".16"/>
     <rect x="46" y="86" width="3" height="12" rx="1.5" fill="#fff" opacity=".75"/>
     <rect x="52" y="86" width="3" height="12" rx="1.5" fill="#fff" opacity=".75"/>`,
    /* 3 striped jersey */
    `<path d="M10 100c0-20 18-30 40-30s40 10 40 30z" fill="${kit}"/>
     <g fill="#fff" opacity=".55"><rect x="26" y="72" width="7" height="28"/><rect x="46" y="70" width="7" height="30"/><rect x="66" y="72" width="7" height="28"/></g>
     <path d="M40 70h20l-10 9z" fill="#000" opacity=".14"/>`,
    /* 4 tank top */
    `<path d="M10 100c0-20 18-30 40-30s40 10 40 30z" fill="${kit}"/>
     <path d="M30 74c6-3 10-4 10-4l10 12 10-12s4 1 10 4l-4 26H34z" fill="#fff" opacity=".18"/>
     <path d="M22 100c0-11 5-19 12-24l4 3c-6 5-10 12-10 21zM78 100c0-11-5-19-12-24l-4 3c6 5 10 12 10 21z" fill="${skd}"/>`,
    /* 5 zip jacket */
    `<path d="M10 100c0-20 18-30 40-30s40 10 40 30z" fill="${kit}"/>
     <rect x="48" y="70" width="4" height="30" fill="#000" opacity=".18"/>
     <path d="M36 71l12 9-12 6zM64 71l-12 9 12 6z" fill="#000" opacity=".1"/>`
  ];

  return `<svg class="av-svg" viewBox="0 0 100 100" width="${size}" height="${size}" style="animation-delay:${(i%7)*-0.9}s">
    <circle cx="50" cy="50" r="50" fill="${bg}"/>
    <g class="av-body">
      ${KITS[kitStyle]}
      <path d="M41 64h18v11a9 9 0 01-18 0z" fill="${skd}"/>
      <ellipse cx="28.5" cy="47" rx="4.4" ry="6" fill="${skd}"/>
      <ellipse cx="71.5" cy="47" rx="4.4" ry="6" fill="${skd}"/>
      <path d="M50 21c13 0 21 10 21 24s-9 24-21 24-21-10-21-24 8-24 21-24z" fill="${sk}"/>
      ${HAIRS[hairStyle]}
      ${freckles?`<g fill="${skd}" opacity=".7"><circle cx="37" cy="53" r="1"/><circle cx="41" cy="55" r="1"/><circle cx="59" cy="55" r="1"/><circle cx="63" cy="53" r="1"/></g>`:''}
      <g class="av-eyes">
        <ellipse cx="42" cy="48" rx="2.5" ry="3" fill="#1D2129"/>
        <ellipse cx="58" cy="48" rx="2.5" ry="3" fill="#1D2129"/>
        <circle cx="43" cy="47" r=".9" fill="#fff" opacity=".9"/>
        <circle cx="59" cy="47" r=".9" fill="#fff" opacity=".9"/>
      </g>
      <path d="M36.5 41q5.5-3.5 11 0M52.5 41q5.5-3.5 11 0" stroke="${hr}" stroke-width="2.2" fill="none" stroke-linecap="round"/>
      <path d="M44 58q6 5.5 12 0" stroke="${skd}" stroke-width="2.4" fill="none" stroke-linecap="round"/>
      ${beard?`<path d="M31 50c0 15 8 23 19 23s19-8 19-23c0 9-8 13-19 13s-19-4-19-13z" fill="${hr}" opacity=".92"/>`:''}
      ${glasses?`<g fill="none" stroke="#2A303C" stroke-width="2.1"><rect x="33.5" y="42" width="17" height="12" rx="5"/><rect x="49.5" y="42" width="17" height="12" rx="5"/><path d="M50.5 47h-1M33.5 46h-5M66.5 46h5"/></g>`:''}
    </g>
  </svg>`;
}
function Avatar({ idx = 0, size = 44, ring = false, onClick, style }) {
  return (
    <div className="av" onClick={onClick}
      style={{ width: size, height: size, cursor: onClick ? "pointer" : "inherit",
        boxShadow: ring ? "0 0 0 3px var(--surface), 0 0 0 5px var(--accent-line)" : undefined, ...style }}
      dangerouslySetInnerHTML={{ __html: personSVG(idx, size) }} />
  );
}
/* Half-tile portrait used across the home rails. */
function AvatarPanel({ idx, sport, height = 124 }) {
  const p = paletteOf(sport);
  return (
    <div className="poster-top" style={{ height, background: `linear-gradient(165deg, ${p.soft}, #fff)` }}>
      <span className="glyph"><SportIcon sport={sport} size={96} color={p.mid} /></span>
      <div className="poster-person" dangerouslySetInnerHTML={{ __html: personSVG(idx, 150) }} />
    </div>
  );
}

/* ================================================================
   HOME HERO — the player, wearing their rating, holding their kit.
   ================================================================ */
function tinyPlayer(x, y, s, skin, kit){
  return `<g transform="translate(${x} ${y}) scale(${s})">
    <path d="M-7 26c0-9 3-16 7-16s7 7 7 16z" fill="${kit}"/>
    <circle cx="0" cy="4" r="6" fill="${skin}"/>
    <path d="M0 -2c4 0 6 3 6 6H-6c0-3 2-6 6-6z" fill="#3A2A20"/>
    <path d="M-6 12l-6 8M6 12l7-9" stroke="${skin}" stroke-width="3.4" stroke-linecap="round" fill="none"/>
    <path d="M-4 26l-2 8M4 26l2 8" stroke="${skin}" stroke-width="3.6" stroke-linecap="round" fill="none"/>
  </g>`;
}
function venueArt(c){
  const p=paletteOf(c.sport), id='vg'+c.n.replace(/[^a-z]/gi,'');
  const sky=`<defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${p.soft}"/><stop offset="1" stop-color="#FFFFFF"/></linearGradient></defs>
    <rect width="236" height="100" fill="url(#${id})"/>`;
  const ground=`<path d="M0 76h236v24H0z" fill="${p.mid}" opacity=".35"/>
    <path d="M0 76h236v3H0z" fill="${p.accent}" opacity=".35"/>`;
  if(c.kind==='League'||c.kind==='Cup'){
    return `<svg class="venue-art" viewBox="0 0 236 100" preserveAspectRatio="xMidYMid slice">${sky}
      <circle cx="196" cy="26" r="20" fill="${p.mid}" opacity=".5"/>
      <path d="M0 62h236v6H0z" fill="${p.accent}" opacity=".18"/>
      ${ground}
      <g transform="translate(118 34)">
        <path d="M-14 -18h28v14a14 14 0 01-28 0z" fill="${p.accent}"/>
        <path d="M-14 -14h-8a8 8 0 008 10zM14 -14h8a8 8 0 01-8 10z" fill="none" stroke="${p.accent}" stroke-width="3"/>
        <rect x="-4" y="-4" width="8" height="14" fill="${p.accent}"/>
        <rect x="-12" y="10" width="24" height="6" rx="2" fill="${p.accent}"/>
        <path d="M-6 -12l3 6 6 1-4 4 1 6-6-3-6 3 1-6-4-4 6-1z" fill="#fff" opacity=".85"/>
      </g>
      <rect x="72" y="76" width="30" height="16" rx="3" fill="${p.accent}" opacity=".65"/>
      <rect x="104" y="68" width="30" height="24" rx="3" fill="${p.accent}"/>
      <rect x="136" y="80" width="30" height="12" rx="3" fill="${p.accent}" opacity=".5"/>
      ${tinyPlayer(87,52,0.62,'#EBBB94','#FFFFFF')}
      ${tinyPlayer(151,58,0.62,'#C4875B','#FFFFFF')}
    </svg>`;
  }
  if(c.kind==='Facility'){
    return `<svg class="venue-art" viewBox="0 0 236 100" preserveAspectRatio="xMidYMid slice">${sky}
      <circle cx="40" cy="24" r="16" fill="${p.mid}" opacity=".45"/>
      <g stroke="${p.accent}" stroke-width="2.4" fill="none" opacity=".5">
        <path d="M30 96l38-42h100l38 42z"/><path d="M68 54h100M49 75h138M118 54v42"/>
      </g>
      <path d="M30 96l38-42h100l38 42z" fill="${p.mid}" opacity=".3"/>
      <g stroke="${p.accent}" stroke-width="2.6">
        <path d="M60 96V58M176 96V58"/>
        <path d="M60 60h116" stroke-dasharray="3 4"/>
      </g>
      <g fill="${p.accent}">
        <rect x="16" y="30" width="4" height="66" rx="2"/><rect x="6" y="22" width="24" height="12" rx="4"/>
        <rect x="216" y="30" width="4" height="66" rx="2"/><rect x="206" y="22" width="24" height="12" rx="4"/>
      </g>
      <g fill="#FFF6D8"><circle cx="18" cy="28" r="7" opacity=".8"/><circle cx="218" cy="28" r="7" opacity=".8"/></g>
    </svg>`;
  }
  if(c.kind==='Ladder'){
    return `<svg class="venue-art" viewBox="0 0 236 100" preserveAspectRatio="xMidYMid slice">${sky}
      ${ground}
      <g fill="${p.accent}">
        <rect x="34" y="66" width="30" height="12" rx="3" opacity=".38"/>
        <rect x="72" y="54" width="30" height="24" rx="3" opacity=".55"/>
        <rect x="110" y="42" width="30" height="36" rx="3" opacity=".72"/>
        <rect x="148" y="28" width="30" height="50" rx="3"/>
      </g>
      <path d="M163 28V12h22l-5 6 5 6h-22z" fill="${p.mid}"/>
      <g opacity=".7">${tinyPlayer(49,52,0.5,'#DCA278','#FFFFFF')}</g>
      ${tinyPlayer(196,54,0.6,'#F5D0AE','#FFFFFF')}
    </svg>`;
  }
  /* Club */
  return `<svg class="venue-art" viewBox="0 0 236 100" preserveAspectRatio="xMidYMid slice">${sky}
    <circle cx="200" cy="24" r="18" fill="${p.mid}" opacity=".5"/>
    <path d="M0 84h236v16H0z" fill="${p.mid}" opacity=".4"/>
    <path d="M0 84h236v3H0z" fill="${p.accent}" opacity=".4"/>
    <g stroke="${p.accent}" stroke-width="2.4" fill="none" opacity=".45">
      <path d="M24 96l30-24h128l30 24z"/><path d="M54 72h128"/>
    </g>
    <g>
      <rect x="116" y="44" width="4" height="42" rx="2" fill="${p.accent}"/>
      <rect x="60" y="44" width="4" height="42" rx="2" fill="${p.accent}" opacity=".6"/>
      <rect x="172" y="44" width="4" height="42" rx="2" fill="${p.accent}" opacity=".6"/>
      <path d="M62 46h112v18H62z" fill="#fff" opacity=".75"/>
      <path d="M62 46h112v18H62z" fill="none" stroke="${p.accent}" stroke-width="1.6" stroke-dasharray="4 4" opacity=".8"/>
    </g>
    ${tinyPlayer(46,50,0.72,'#EBBB94','#FFFFFF')}
    ${tinyPlayer(190,52,0.72,'#A06841','#FFFFFF')}
    <circle cx="118" cy="34" r="7" fill="#fff" stroke="${p.accent}" stroke-width="2.4"/>
  </svg>`;
}

const DOTS=[[104,74,9],[152,52,7],[196,78,10],[86,120,7],[128,108,11],[176,124,8],[212,112,6],
  [98,166,10],[144,158,7],[190,170,9],[116,206,8],[168,204,10],[206,186,6],[72,150,6]];
function heroTexture(sport, p){
  const d=p.accent;
  if(sport==='badminton')
    return DOTS.map(([x,y,r])=>`<path d="M${x} ${y-r} L${x-r*0.6} ${y+r} L${x+r*0.6} ${y+r} Z" fill="${d}" opacity=".26"/>`).join('');
  if(sport==='cricket')
    return DOTS.map(([x,y,r])=>`<path d="M${x-r} ${y}q${r} ${-r*0.9} ${r*2} 0" stroke="${d}" stroke-width="2.4" fill="none" opacity=".3" stroke-linecap="round"/>`).join('');
  if(sport==='volleyball')
    return DOTS.map(([x,y,r])=>`<path d="M${x-r} ${y}q${r/2} ${-r} ${r} 0t${r} 0" stroke="${d}" stroke-width="2.2" fill="none" opacity=".28" stroke-linecap="round"/>`).join('');
  if(sport==='soccer')
    return DOTS.map(([x,y,r])=>`<path d="M${x} ${y-r} l${r*0.95} ${r*0.7} l${-r*0.36} ${r*1.1} h${-r*1.18} l${-r*0.36} ${-r*1.1} Z" fill="${d}" opacity=".26"/>`).join('');
  return DOTS.map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r*0.62}" fill="${d}" opacity=".26"/>`).join('');
}
/* Kit hangs from the hand at the character's side, drawn in the same
   bold-outline style as the rest of the figure. */
const OUT='#23262F', OW=3.4;
function heroEquipment(sport, p){
  const O=`stroke="${OUT}" stroke-width="${OW}" stroke-linejoin="round"`;
  const grip=`<rect x="-7" y="-20" width="14" height="34" rx="7" fill="#4A5462" ${O}/>
              <path d="M-7 -12h14M-7 -5h14M-7 2h14" stroke="${OUT}" stroke-width="1.6" opacity=".5"/>`;
  if(sport==='badminton') return `
    <g transform="translate(108 206) rotate(-14)">
      ${grip}
      <path d="M-4 14v10M4 14v10" stroke="${OUT}" stroke-width="4" stroke-linecap="round"/>
      <ellipse cx="0" cy="56" rx="22" ry="30" fill="#FFFFFF" ${O}/>
      <g stroke="${p.accent}" stroke-width="1.6" opacity=".7">
        <path d="M-16 42h32M-18 56h36M-16 70h32M-9 32v48M7 32v48"/>
      </g>
    </g>`;
  if(sport==='cricket') return `
    <g transform="translate(108 206) rotate(-14)">
      ${grip}
      <rect x="-16" y="18" width="32" height="72" rx="7" fill="#F1E3C9" ${O}/>
      <path d="M-16 42h32" stroke="${OUT}" stroke-width="2" opacity=".35"/>
      <path d="M-9 26h18v58h-18z" fill="${p.soft}" opacity=".7"/>
    </g>`;
  if(sport==='soccer'||sport==='volleyball') return `
    <g transform="translate(114 228)">
      <circle cx="0" cy="0" r="26" fill="#FFFFFF" ${O}/>
      ${sport==='soccer'
        ? `<path d="M0 -13l12.4 9-4.7 14.6H-7.7l-4.7-14.6z" fill="${OUT}"/>
           <path d="M0 -26v13M23.6 -4.7l-11.2.7M13.7 22.9l-5.9-11.8M-13.7 22.9l5.9-11.8M-23.6 -4.7l11.2.7" stroke="${OUT}" stroke-width="2.6"/>`
        : `<path d="M-22 -9c12 5 22 17 23 31M1 -26c-7 11-9 26-3 38M22 -10c-13-1-27 5-34 15" stroke="${p.accent}" stroke-width="3" fill="none" stroke-linecap="round"/>`}
    </g>`;
  /* Paddle sports */
  const holes = sport==='pickleball'
    ? `<g fill="#FFFFFF" opacity=".92">
         <circle cx="-13" cy="44" r="2.8"/><circle cx="0" cy="40" r="2.8"/><circle cx="13" cy="44" r="2.8"/>
         <circle cx="-13" cy="60" r="2.8"/><circle cx="0" cy="56" r="2.8"/><circle cx="13" cy="60" r="2.8"/>
         <circle cx="-6" cy="72" r="2.8"/><circle cx="7" cy="72" r="2.8"/>
       </g>` : '';
  return `
    <g transform="translate(108 206) rotate(-14)">
      ${grip}
      <path d="M-9 14h18v10h-18z" fill="#4A5462" ${O}/>
      <rect x="-27" y="22" width="54" height="68" rx="23" fill="${p.mid}" ${O}/>
      <path d="M-27 56q27-10 54 0v14q-27-10-54 0z" fill="${p.accent}" opacity=".45"/>
      ${holes}
    </g>`;
}

function heroArtMarkup(sport, rating, avIdx){
  const p=paletteOf(sport);
  const i=((avIdx%50)+50)%50;
  const sk=SKIN[i%10], skd=SKIN_D[i%10], hr=HAIR[(i*3)%10];
  const O=`stroke="${OUT}" stroke-width="${OW}" stroke-linejoin="round"`;
  const tee='#1E222A', shorts='#9AA1AC', shortsDark='#868D9A', shoe='#2B2F38', cap=p.accent;
  const label='MP';
  const big = rating==null ? 'PEER' : String(rating);
  return `<svg class="hero-art" viewBox="0 0 300 300" width="100%" height="100%">
    <circle cx="150" cy="140" r="104" fill="${p.mid}" opacity=".55"/>
    ${heroTexture(sport,p)}
    <circle cx="68" cy="74" r="34" fill="${p.accent}" opacity=".85"/>
    <circle cx="252" cy="52" r="21" fill="${p.mid}"/>
    <circle cx="44" cy="204" r="14" fill="${p.mid}" opacity=".7"/>
    <g class="hero-figure">
      <ellipse cx="150" cy="284" rx="56" ry="8" fill="${p.accent}" opacity=".16"/>

      <!-- Legs, set slightly apart -->
      <path d="M131 218h17v42h-17zM152 218h17v42h-17z" fill="${sk}" ${O}/>
      <path d="M129 250h21v11h-21zM150 250h21v11h-21z" fill="#F2F5F9" ${O}/>

      <!-- Sneakers -->
      <path d="M118 258h27l4 11c1.4 4-.6 7-4.6 7h-30c-4 0-6-2-6-5.6 0-5.6 3.6-10.4 9.6-12.4z" fill="${shoe}" ${O}/>
      <path d="M182 258h-27l-4 11c-1.4 4 .6 7 4.6 7h30c4 0 6-2 6-5.6 0-5.6-3.6-10.4-9.6-12.4z" fill="${shoe}" ${O}/>
      <path d="M107 274h42a4 4 0 014 4v1.6a4 4 0 01-4 4h-42a4 4 0 01-4-4V278a4 4 0 014-4z" fill="#FFFFFF" ${O}/>
      <path d="M151 274h42a4 4 0 014 4v1.6a4 4 0 01-4 4h-42a4 4 0 01-4-4V278a4 4 0 014-4z" fill="#FFFFFF" ${O}/>
      <g stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" opacity=".9">
        <path d="M122 264l10 3.6M124 270l10 3M178 264l-10 3.6M176 270l-10 3"/>
      </g>

      <!-- Grey shorts -->
      <path d="M120 192h60l-3 32h-24l-3-13-3 13h-24z" fill="${shorts}" ${O}/>
      <path d="M120 192h60v8h-60z" fill="${shortsDark}" ${O}/>
      <path d="M150 205v19" stroke="${OUT}" stroke-width="2" opacity=".28"/>

      <!-- Black tee -->
      <path d="M122 136q28-10 56 0l4 58q-32 9-64 0z" fill="${tee}" ${O}/>
      <path d="M138 127q12-4 24 0l-12 13z" fill="#FFFFFF" opacity=".16" ${O}/>
      <path d="M132 160q18 5 36 0" stroke="${OUT}" stroke-width="1.6" fill="none" opacity=".18"/>

      <!-- Arms held clear of the torso, elbows bent outward -->
      <path d="M124 140q-16 10-20 30t2 32l17-4q-4-14-1-25t12-19z" fill="${sk}" ${O}/>
      <path d="M176 140q16 10 20 30t-2 32l-17-4q4-14 1-25t-12-19z" fill="${sk}" ${O}/>
      <path d="M122 138q-12 7-17 18l19 8q3-9 12-15z" fill="${tee}" ${O}/>
      <path d="M178 138q12 7 17 18l-19 8q-3-9-12-15z" fill="${tee}" ${O}/>

      ${heroEquipment(sport,p)}
      <!-- Hands -->
      <path d="M100 198q13-6 21 3t-3 20-21-3-3-19z" fill="${sk}" ${O}/>
      <g stroke="${OUT}" stroke-width="2" stroke-linecap="round" opacity=".5">
        <path d="M103 205l14-4M105 212l14-4M108 218l12-4"/>
      </g>
      <path d="M200 198q-13-6-21 3t3 20 21-3 3-19z" fill="${sk}" ${O}/>
      <g stroke="${OUT}" stroke-width="2" stroke-linecap="round" opacity=".5">
        <path d="M183 206h12M184 213h11"/>
      </g>

      <!-- Head -->
      <path d="M119 92q-8-2-9 5.6t9 11.4z" fill="${sk}" ${O}/>
      <path d="M181 92q8-2 9 5.6t-9 11.4z" fill="${sk}" ${O}/>
      <path d="M150 56c21 0 32 14 32 34 0 23-14 38-32 38s-32-15-32-38c0-20 11-34 32-34z" fill="${sk}" ${O}/>
      <path d="M122 90q-4-13 2-21M178 90q4-13-2-21" stroke="${hr}" stroke-width="7" stroke-linecap="round" fill="none"/>

      <!-- Cap -->
      <path d="M118 82c0-23 14-36 32-36s32 13 32 36q-32-9-64 0z" fill="${cap}" ${O}/>
      <path d="M150 46c-9 6-12.5 19-12.5 32.5l8.5-1c0-12.5 2-24 8-31z" fill="#FFFFFF" opacity=".22"/>
      <path d="M182 82q15 1 22.5 5.6t-5.6 8.4l-35.6-6.6z" fill="${cap}" ${O}/>
      <circle cx="150" cy="45" r="4.4" fill="${cap}" ${O}/>
      <path d="M118 82q32-9 64 0v4.6q-32-9-64 0z" fill="${OUT}" opacity=".14"/>

      <!-- Face -->
      <g class="av-eyes">
        <ellipse cx="137" cy="97" rx="9" ry="10.4" fill="#FFFFFF" ${O}/>
        <ellipse cx="163" cy="97" rx="9" ry="10.4" fill="#FFFFFF" ${O}/>
        <circle cx="138.4" cy="98" r="5.3" fill="#23262F"/>
        <circle cx="164.4" cy="98" r="5.3" fill="#23262F"/>
        <circle cx="136.4" cy="95.4" r="1.9" fill="#FFFFFF"/>
        <circle cx="162.4" cy="95.4" r="1.9" fill="#FFFFFF"/>
      </g>
      <path d="M128 85q9.5-5 19 0-9.5-1-19 4z" fill="${hr}" ${O}/>
      <path d="M172 85q-9.5-5-19 0 9.5-1 19 4z" fill="${hr}" ${O}/>
      <path d="M150 103q4.6 5.6 2.8 8.6t-5.8 1.8" fill="none" stroke="${OUT}" stroke-width="2.6" stroke-linecap="round"/>
      <path d="M140 116q10 7.6 20 0" fill="none" stroke="${OUT}" stroke-width="3" stroke-linecap="round"/>
      <ellipse cx="128" cy="108" rx="4.8" ry="3" fill="${p.accent}" opacity=".22"/>
      <ellipse cx="172" cy="108" rx="4.8" ry="3" fill="${p.accent}" opacity=".22"/>

      <text x="150" y="${big.length>3?170:172}" text-anchor="middle" fill="#FFFFFF" font-size="${big.length>3?16:21}" font-weight="800"
        font-family="-apple-system,'SF Pro Text',Inter,sans-serif" letter-spacing="${big.length>3?'0':'-.7'}">${big}</text>
      <text x="150" y="185" text-anchor="middle" fill="${p.mid}" font-size="9.5" font-weight="800"
        font-family="-apple-system,'SF Pro Text',Inter,sans-serif" letter-spacing="1">${label}</text>
    </g>
  </svg>`;
}

/* The hero's own head, cropped to a circle. Used wherever the app
   shows the signed-in player, so their face never changes. */
function myFaceMarkup(size, sport, avIdx){
  const p=paletteOf(sport);
  const i=((avIdx%50)+50)%50;
  const sk=SKIN[i%10], skd=SKIN_D[i%10], hr=HAIR[(i*3)%10];
  const O=`stroke="${OUT}" stroke-width="4.4" stroke-linejoin="round"`;
  return `<svg class="av-svg" viewBox="0 0 120 120" width="${size}" height="${size}">
    <circle cx="60" cy="60" r="60" fill="${p.soft}"/>
    <g transform="translate(-90 -30)"><g class="av-body">
      <path d="M150 132q-24 6-30 24h60q-6-18-30-24z" fill="#1E222A" ${O}/>
      <path d="M119 92q-8-2-9 5.6t9 11.4z" fill="${sk}" ${O}/>
      <path d="M181 92q8-2 9 5.6t-9 11.4z" fill="${sk}" ${O}/>
      <path d="M150 56c21 0 32 14 32 34 0 23-14 38-32 38s-32-15-32-38c0-20 11-34 32-34z" fill="${sk}" ${O}/>
      <path d="M122 90q-4-13 2-21M178 90q4-13-2-21" stroke="${hr}" stroke-width="7" stroke-linecap="round" fill="none"/>
      <path d="M118 82c0-23 14-36 32-36s32 13 32 36q-32-9-64 0z" fill="${p.accent}" ${O}/>
      <path d="M150 46c-9 6-12.5 19-12.5 32.5l8.5-1c0-12.5 2-24 8-31z" fill="#FFFFFF" opacity=".22"/>
      <path d="M182 82q15 1 22.5 5.6t-5.6 8.4l-35.6-6.6z" fill="${p.accent}" ${O}/>
      <circle cx="150" cy="45" r="4.4" fill="${p.accent}" ${O}/>
      <path d="M118 82q32-9 64 0v4.6q-32-9-64 0z" fill="${OUT}" opacity=".14"/>
      <g class="av-eyes">
        <ellipse cx="137" cy="97" rx="9" ry="10.4" fill="#FFFFFF" ${O}/>
        <ellipse cx="163" cy="97" rx="9" ry="10.4" fill="#FFFFFF" ${O}/>
        <circle cx="138.4" cy="98" r="5.3" fill="#23262F"/>
        <circle cx="164.4" cy="98" r="5.3" fill="#23262F"/>
        <circle cx="136.4" cy="95.4" r="1.9" fill="#FFFFFF"/>
        <circle cx="162.4" cy="95.4" r="1.9" fill="#FFFFFF"/>
      </g>
      <path d="M128 85q9.5-5 19 0-9.5-1-19 4z" fill="${hr}" ${O}/>
      <path d="M172 85q-9.5-5-19 0 9.5-1 19 4z" fill="${hr}" ${O}/>
      <path d="M150 103q4.6 5.6 2.8 8.6t-5.8 1.8" fill="none" stroke="${OUT}" stroke-width="2.6" stroke-linecap="round"/>
      <path d="M140 116q10 7.6 20 0" fill="none" stroke="${OUT}" stroke-width="3" stroke-linecap="round"/>
      <ellipse cx="128" cy="108" rx="4.8" ry="3" fill="${p.accent}" opacity=".22"/>
      <ellipse cx="172" cy="108" rx="4.8" ry="3" fill="${p.accent}" opacity=".22"/>
    </g></g>
  </svg>`;
}
function MyFace({ size = 44, ring = false, sport, avIdx }) {
  return (
    <div className="av" style={{ width: size, height: size,
      boxShadow: ring ? "0 0 0 3px var(--surface), 0 0 0 5px var(--accent-line)" : "none" }}
      dangerouslySetInnerHTML={{ __html: myFaceMarkup(size, sport, avIdx) }} />
  );
}
function HeroArt({ sport, rating, avIdx }) {
  return <div className="hero-stage" dangerouslySetInnerHTML={{ __html: heroArtMarkup(sport, rating, avIdx) }} />;
}

const NAMES = ["Tyler Brooks","Priya Raghavan","Marcus Idowu","Elena Vasquez","Dev Sharma","Hannah Kim","Omar Haddad","Grace Nolan","Ravi Menon","Sofia Bianchi","Jamal Carter","Aisha Rahman","Leo Fischer","Nina Petrova","Chris Okafor","Maya Lindqvist","Arjun Patel","Zoe Bennett","Kenji Watanabe","Laura Mendes","Tomas Novak","Ivy Chen","Daniel Osei","Farah Aziz","Ethan Wallace","Anika Desai","Pablo Herrera","Rachel Stone","Yusuf Demir","Clara Ferreira","Nathan Wu","Simran Kaur","Andre Dubois","Bella Rossi","Kwame Boateng","Hana Suzuki","Victor Almeida","Tara Sullivan","Rohit Verma","Julia Novakova","Sam Whitfield","Noor Al-Sayed"];
const VENUES = ["Riverside Courts","Meadow Park Center","Lakeview Athletic Club","Cedar Street Gym","Northgate Recreation","Harbour Point Courts","Willow Creek Complex","Fairmont Community Hall"];
const BIOS = [
  "Weekend competitor who plays for the rallies and stays for the coffee afterwards.",
  "Former college athlete easing back into competitive play. Always up for a friendly set.",
  "Plays three evenings a week and enjoys coaching newer players.",
  "Casual player chasing consistency more than trophies.",
  "Doubles specialist looking for a steady partner across the season.",
];
const SNIPPETS = ["Are we still on for Thursday?","Good game earlier, that last rally was brutal.","I booked court three for 7 PM.","Bring the spare paddle if you can.","My rating finally moved. Thanks for the practice.","Rain check on Saturday? The forecast looks rough.","Let me know when you want a rematch.","Nice win. You have improved a lot this month."];
/* Leagues, clubs, and facilities, grouped by sport. */
const COMMUNITIES = [
  { n: "Riverside Pickleball Club", sport: "pickleball", kind: "Club",     m: 64,  d: 1.2 },
  { n: "Meadow Park Open League",   sport: "pickleball", kind: "League",   m: 128, d: 2.6 },
  { n: "Northgate Courts",          sport: "pickleball", kind: "Facility", m: 0,   d: 0.9, courts: 8 },
  { n: "Sunrise Doubles Ladder",    sport: "pickleball", kind: "Ladder",   m: 46,  d: 3.4 },
  { n: "Thursday Badminton Social", sport: "badminton",  kind: "Club",     m: 38,  d: 2.4 },
  { n: "City Shuttle League",       sport: "badminton",  kind: "League",   m: 92,  d: 4.1 },
  { n: "Cedar Street Sports Hall",  sport: "badminton",  kind: "Facility", m: 0,   d: 1.6, courts: 6 },
  { n: "Winter Doubles Series",     sport: "badminton",  kind: "Ladder",   m: 31,  d: 2.9 },
  { n: "Cedar Street Ping Pong",    sport: "pingpong",   kind: "Club",     m: 27,  d: 0.8 },
  { n: "Lunchtime Table League",    sport: "pingpong",   kind: "League",   m: 54,  d: 1.4 },
  { n: "Harbour Point Rec Centre",  sport: "pingpong",   kind: "Facility", m: 0,   d: 2.2, courts: 10 },
  { n: "Sunday Cricket League",     sport: "cricket",    kind: "League",   m: 96,  d: 3.1 },
  { n: "Riverside XI",              sport: "cricket",    kind: "Club",     m: 22,  d: 1.1 },
  { n: "Fairmont Cricket Ground",   sport: "cricket",    kind: "Facility", m: 0,   d: 4.4, courts: 2 },
  { n: "Midweek T20 Cup",           sport: "cricket",    kind: "Cup",      m: 64,  d: 5.2 },
  { n: "Northgate Five-a-side",     sport: "soccer",     kind: "League",   m: 71,  d: 1.9 },
  { n: "Willow Creek FC",           sport: "soccer",     kind: "Club",     m: 34,  d: 2.7 },
  { n: "Lakeview 3G Pitches",       sport: "soccer",     kind: "Facility", m: 0,   d: 1.3, courts: 4 },
  { n: "Harbour Point Volleyball",  sport: "volleyball", kind: "Club",     m: 52,  d: 2.8 },
  { n: "Beach Doubles Series",      sport: "volleyball", kind: "League",   m: 40,  d: 5.6 },
  { n: "Meadow Park Sand Courts",   sport: "volleyball", kind: "Facility", m: 0,   d: 3.3, courts: 5 },
];
const DATES = ["Mon, Aug 11","Wed, Aug 12","Thu, Aug 13","Sat, Aug 15","Sun, Aug 16","Tue, Aug 18","Sat, Aug 22"];
const TIMES = ["7:00 AM","8:00 AM","9:00 AM","10:00 AM","12:00 PM","3:00 PM","5:00 PM","6:00 PM","6:30 PM","7:00 PM","7:45 PM","8:30 PM"];
/* Start times a challenge slot can take, on the 24-hour clock the
   calendar works in. */
const SLOT_TIMES = ["07:00","08:00","09:00","10:00","11:00","12:00","13:00","15:00","16:00","17:00","18:00","18:30","19:00","19:30","20:00","20:30","21:00"];
const TODAY = new Date(2026, 7, 11);
const DOW = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const MON_SHORT = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const CAL_START = 7, CAL_END = 23, HOUR_H = 40;
const CAL_TIMES = Array.from({ length: (CAL_END - CAL_START) * 2 }, (_, i) => {
  const m = CAL_START * 60 + i * 30;
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
});
const dateOf = (e) => { const [y, m, d] = e.date.split("-").map(Number); return new Date(y, m - 1, d); };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function startOfWeek(base, offset) {
  const d = new Date(base); const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day + offset * 7); d.setHours(0, 0, 0, 0); return d;
}
function weekDays(offset) {
  const s = startOfWeek(TODAY, offset);
  return Array.from({ length: 7 }, (_, i) => { const d = new Date(s); d.setDate(s.getDate() + i); return d; });
}
const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
function fmtTime(t) {
  const [h, m] = t.split(":").map(Number);
  return `${h % 12 === 0 ? 12 : h % 12}:${String(m).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
}
const fmtDate = (e) => { const d = dateOf(e); return `${DOW[(d.getDay() + 6) % 7]}, ${MON_SHORT[d.getMonth()]} ${d.getDate()}`; };

const ALL_PLAYERS = Array.from({ length: 42 }, (_, i) => {
  const name = NAMES[i % NAMES.length];
  const rating = 62 + ((i * 13) % 78);
  return {
    id: "p" + i, name, av: i % 50, rating,
    username: "@" + name.split(" ")[0].toLowerCase() + (10 + (i % 80)),
    age: 19 + (i % 26), gender: ["Male", "Female", "Non-binary"][i % 3],
    dist: (0.4 + ((i * 7) % 110) / 10).toFixed(1),
    bio: BIOS[i % BIOS.length],
    sports: [...new Set([ALL_SPORTS[i % 6], ALL_SPORTS[(i + 2) % 6]])],
    ratings: { pickleball: rating, badminton: Math.max(60, rating - 9), pingpong: Math.max(60, rating - 6) },
    mutual: 1 + (i % 9),
  };
});
const P = (id) => ALL_PLAYERS.find((x) => x.id === id) || ALL_PLAYERS[0];

const seedA = () => ({
  profile: "A", onboarded: false,
  me: { name: "", username: "", age: "", gender: "", av: 0 },
  sports: [], optOut: {}, connections: [],
  threads: [], msgRequests: [], verifications: [],
  upcoming: [], past: [], calendar: [], ratings: {}, peer: {}, notifications: [],
});
/* The two live proposals. The slot list is shared between the message in
   the conversation and the tentative blocks on the calendar, so the two
   can never drift apart. */
const CH_SLOTS = {
  c2: [{ date:"2026-08-13", start:"19:00", end:"20:30" },
       { date:"2026-08-15", start:"09:00", end:"10:30" },
       { date:"2026-08-16", start:"11:00", end:"12:30" }],
  c7: [{ date:"2026-08-11", start:"20:30", end:"22:00" },
       { date:"2026-08-14", start:"20:00", end:"21:30" }],
};
/* A challenge sits inside the conversation it came from. */
const CH_SEED = {
  6: { me:true,  kind:"challenge", cid:"c2", sport:"pickleball", venue:VENUES[6], chosen:null, declined:false, t:"8:22 PM", slots:CH_SLOTS.c2 },
  5: { me:false, kind:"challenge", cid:"c7", sport:"badminton",  venue:VENUES[2], chosen:null, declined:false, t:"7:04 PM", slots:CH_SLOTS.c7 },
};
const seedB = () => ({
  profile: "B", onboarded: true,
  me: { name: "Sasshh", username: "@sashpash", age: "25", gender: "Male", av: 0 },
  sports: ["pickleball", "badminton", "cricket"],
  optOut: {},
  /* People you have an open two-way conversation with. Everything
     social starts from a message, so this is the only social list. */
  connections: ALL_PLAYERS.slice(0, 10).map((p) => p.id),
  verifications: [
    { id:"v1", sport:"pickleball", from:"p3",  mode:"Singles", score:"2-1 games", games:[1,1,0],   date:"Aug 10, 2026", venue:VENUES[0], delta:2 },
    { id:"v2", sport:"pickleball", from:"p11", mode:"Doubles", score:"1-2 games", games:[0,1,0],   date:"Aug 9, 2026",  venue:VENUES[1], delta:-2, partner:"p6" },
    { id:"v3", sport:"pickleball", from:"p14", mode:"Singles", score:"2-0 games", games:[1,1],     date:"Aug 8, 2026",  venue:VENUES[5], delta:2 },
    { id:"v4", sport:"badminton",  from:"p7",  mode:"Doubles", score:"3-1 games", games:[1,0,1,1], date:"Aug 9, 2026",  venue:VENUES[2], delta:3, partner:"p2" },
    { id:"v5", sport:"badminton",  from:"p9",  mode:"Singles", score:"0-2 games", games:[0,0],     date:"Aug 7, 2026",  venue:VENUES[3], delta:-2 },
  ],
  /* Threads with your connections. A thread marked pending is one where
     you sent the opener and they have not written back yet, so you
     cannot challenge them. */
  threads: ALL_PLAYERS.slice(0, 9).map((p, i) => ({
    id: "t" + i, with: p.id, unread: i < 3 ? i + 1 : 0, pending: i === 8,
    msgs: i === 8 ? [{ me: true, tx: "Hi, I play at Riverside most evenings. Fancy a hit some time?", t: "4:02 PM" }] : [
      { me: false, tx: SNIPPETS[(i * 3) % SNIPPETS.length], t: "6:12 PM" },
      { me: true, tx: "Works for me. I will bring an extra set of balls.", t: "6:20 PM" },
      { me: false, tx: SNIPPETS[(i * 3 + 1) % SNIPPETS.length], t: "6:41 PM" },
      ...(CH_SEED[i] ? [JSON.parse(JSON.stringify(CH_SEED[i]))] : []),
    ],
  })),
  /* Openers from people you are not connected with yet. */
  msgRequests: [
    { id: "r1", with: "p12", hrs: 3,  tx: "Hey, I saw your profile on the map. Fancy a game this weekend?" },
    { id: "r2", with: "p18", hrs: 9,  tx: "We played in the Riverside ladder last year. Up for a rematch?" },
    { id: "r3", with: "p24", hrs: 16, tx: "Saw your rating on the map. Would love a hit if you are free midweek." },
    { id: "r4", with: "p22", hrs: 30, tx: "Do you ever play doubles? I have a partner but we need a second pair." },
    { id: "r5", with: "p31", hrs: 5,  tx: "I am new to the area and looking for regular hitting partners." },
    { id: "r6", with: "p35", hrs: 12, tx: "Your club runs a Thursday ladder, is that right? I would like to join." },
    { id: "r7", with: "p29", hrs: 40, tx: "Happy to travel if you have a court booked. I am free most evenings." },
    { id: "r8", with: "p27", hrs: 7,  tx: "We are a player short for Saturday. Any chance you are free?" },
  ],
  /* Individual-sport matches. Confirmed ones sit on the calendar in one
     block. Tentative ones are proposals with up to three slots, and
     every slot is drawn until the other player picks one. */
  upcoming: [
    { id: "c1", sport: "pickleball", opp: "p0", date: "2026-08-12", start: "18:30", end: "20:00", venue: VENUES[0], status: "Confirmed" },
    { id: "c6", sport: "pickleball", opp: "p4", date: "2026-08-14", start: "17:00", end: "18:30", venue: VENUES[4], status: "Confirmed" },
    { id: "c2", sport: "pickleball", opp: "p6", venue: VENUES[6], status: "Tentative", from: "me", slots: CH_SLOTS.c2 },
    { id: "c3", sport: "badminton",  opp: "p1", date: "2026-08-13", start: "19:45", end: "21:00", venue: VENUES[2], status: "Confirmed" },
    { id: "c8", sport: "badminton",  opp: "p7", date: "2026-08-16", start: "10:00", end: "11:30", venue: VENUES[2], status: "Confirmed" },
    { id: "c7", sport: "badminton",  opp: "p5", venue: VENUES[2], status: "Tentative", from: "them", slots: CH_SLOTS.c7 },
  ],
  past: [
    { id:"m1", sport:"pickleball", opp:"p3", partner:null, mode:"Singles", games:[1,1,0], won:true, score:"2-1 games", date:"Aug 6, 2026", venue:VENUES[0], delta:2, before:123, after:125, source:"Scheduled match", duration:"52 min" },
    { id:"m2", sport:"badminton", opp:"p7", partner:"p2", mode:"Doubles", games:[1,0,1,1], won:true, score:"3-1 games", date:"Aug 3, 2026", venue:VENUES[2], delta:3, before:118, after:121, source:"Manually uploaded score", duration:"1 hr 08 min" },
    { id:"m3", sport:"pickleball", opp:"p11", partner:null, mode:"Singles", games:[0,1,0], won:false, score:"1-2 games", date:"Jul 29, 2026", venue:VENUES[1], delta:-2, before:125, after:123, source:"Scheduled match", duration:"47 min" },
    { id:"m5", sport:"badminton", opp:"p9", partner:null, mode:"Singles", games:[1,1], won:true, score:"2-0 games", date:"Jul 21, 2026", venue:VENUES[3], delta:2, before:116, after:118, source:"Manually uploaded score", duration:"38 min" },
    { id:"m6", sport:"pickleball", opp:"p14", partner:"p6", mode:"Doubles", games:[1,0,1], won:true, score:"2-1 games", date:"Jul 18, 2026", venue:VENUES[5], delta:1, before:122, after:123, source:"Scheduled match", duration:"1 hr 02 min" },
  ],
  calendar: [
    { id:"e1", sport:"cricket", title:"League fixture", team:"Riverside XI", opponent:"Cedar Street CC", date:"2026-08-01", start:"10:00", end:"13:00", venue:VENUES[4], result:{ outcome:"Won", score:"Won by 24 runs" } },
    { id:"e2", sport:"cricket", title:"Friendly", team:"Riverside XI", opponent:"Meadow Park CC", date:"2026-08-05", start:"17:30", end:"20:00", venue:VENUES[1], result:{ outcome:"Lost", score:"Lost by 3 wickets" } },
    { id:"e3", sport:"cricket", title:"Cup quarter-final", team:"Riverside XI", opponent:"Northgate Nomads", date:"2026-08-09", start:"11:00", end:"14:30", venue:VENUES[7], result:null },
    { id:"e4", sport:"cricket", title:"League fixture", team:"Riverside XI", opponent:"Harbour Point CC", date:"2026-08-13", start:"18:00", end:"20:30", venue:VENUES[4], result:null },
    { id:"e5", sport:"cricket", title:"Net practice", team:"Riverside XI", opponent:"Squad session", date:"2026-08-11", start:"19:00", end:"20:30", venue:VENUES[3], result:null },
    { id:"e6", sport:"cricket", title:"League fixture", team:"Riverside XI", opponent:"Willow Creek CC", date:"2026-08-16", start:"09:30", end:"13:00", venue:VENUES[6], result:null },
    { id:"e7", sport:"cricket", title:"Away fixture", team:"Riverside XI", opponent:"Fairmont CC", date:"2026-08-22", start:"14:00", end:"17:00", venue:VENUES[7], result:null },
  ],
  ratings: { pickleball: 125, badminton: 121 },
  peer: { cricket: { Batting: 4.5, Bowling: 4.0, Fielding: 4.5 } },
  notifications: [
    { id:"n1", who:"p12", kind:"connect", tx:"wants to connect and sent you a message.", t:"3h", unread:true },
    { id:"n2", who:"p1", kind:"challenge", tx:"accepted your challenge for Wednesday at 6:30 PM.", t:"5h", unread:true },
    { id:"n3", who:"p3", kind:"verify", tx:"uploaded a score from Riverside Courts and needs your verification.", t:"1d", unread:true },
    { id:"n4", who:"p13", kind:"challenge", tx:"proposed two times for a Badminton match.", t:"1d", unread:true },
    { id:"n5", who:"p7", kind:"rating", tx:"lost to you, and your rating moved to 125.", t:"3d", unread:false },
    { id:"n6", who:"p24", kind:"connect", tx:"is waiting on a reply in your requests.", t:"5d", unread:false },
    { id:"n7", who:"p5", kind:"peer", tx:"rated your Cricket performance after the last match.", t:"1w", unread:false },
  ],
});

function ratingDelta(mine, theirs, won) {
  const d = theirs - mine;
  if (won) {
    if (d > 40) return 5;
    if (d > 22) return 4;
    if (d > 8) return 3;
    if (d >= -8) return Math.abs(d) <= 3 ? 2 : 1;
    return 1;
  }
  if (d < -40) return -5;
  if (d < -22) return -4;
  if (d < -8) return -3;
  if (d <= 8) return Math.abs(d) <= 3 ? -2 : -1;
  return -1;
}

const SecHead = ({ children, action }) => <div className="sec-head"><h4>{children}</h4>{action}</div>;
const KV = ({ k, v }) => <div className="kv"><span>{k}</span><b>{v}</b></div>;
const Stars = ({ value = 0, size = 13, color }) => (
  <span className="stars">{[1,2,3,4,5].map((n) => <span key={n}>{n <= Math.round(value) ? Ico.star(size, color) : Ico.starO(size)}</span>)}</span>
);
const Empty = ({ icon, title, body, action }) => (
  <div className="empty"><div className="empty-ic">{icon}</div><h3>{title}</h3><p>{body}</p>{action}</div>
);
const Select = ({ options, value, onChange, style }) => (
  <select className="input" value={value} onChange={(e) => onChange(e.target.value)} style={style}>
    {options.map((o) => (typeof o === "string" ? <option key={o} value={o}>{o}</option> : <option key={o.v} value={o.v}>{o.l}</option>))}
  </select>
);
const agoLabel = (h) => (h < 1 ? "Just now" : h < 24 ? `${h}h ago` : `${Math.floor(h / 24)}d ago`);
const OB_STEPS = ["intro1", "intro2", "intro3", "identity", "sports", "setup"];
const MAP_W = 760, MAP_H = 960;
const CLUSTER_R = 66;          /* screen px between marker centres */
const PIN_MAX_Z = 2.6, PIN_MIN_Z = 0.55;
/* Each venue is a tight knot, so its players merge into one bubble at
   the default zoom and come apart again once you zoom past it. The
   loners are spaced out between the venues, and every position is kept
   clear of your own dot at 380,480 even at the widest zoom. */
const PIN_POS = [
  [156,200],[192,196],[168,236],[204,232],       /* Riverside courts */
  [546,284],[582,280],[558,320],[594,316],       /* Northgate rec    */
  [92,470],                                      /* on their own     */
  [276,614],[312,610],[288,650],[324,646],       /* Meadow park      */
  [470,392],                                     /* on their own     */
  [626,764],[662,760],[638,800],                 /* Harbour point    */
  [702,520],[128,764]                            /* on their own     */
];
const ART_POS = [[6,7,44,0],[74,4,30,8],[38,15,26,-14],[86,19,38,16],[13,26,30,10],[58,29,46,-8],
  [30,38,28,20],[80,44,32,-12],[4,49,40,6],[50,54,26,14],[70,63,44,-16],[16,70,30,4],
  [44,76,38,12],[84,82,26,-10],[8,88,34,18],[58,92,30,-6]];

/* ================================================================
   ROOT COMPONENT
   ================================================================ */
export default function MatchPoint() {
  const [S, setS] = useState(seedB);
  const [V, setV] = useState({
    tab: "home", screen: "main", ob: 0, activeSport: "pickleball",
    fabOpen: false, layer: null, dirty: false, dirtyLabel: "", pendingSport: null,
    chatWith: null, matchTab: "upcoming", calTab: "week", weekOffset: 0,
    chatTab: "chats", friendQuery: "",
    mapFilters: { gender: "Any", rating: "Any" }, lastVictory: null,
  });
  const [draft, setDraft] = useState({ name: "", username: "", age: "", gender: "", av: 0, sports: [], optOut: {} });
  const [chDraft, setChDraft] = useState(null);
  const [scDraft, setScDraft] = useState(null);
  const [evDraft, setEvDraft] = useState(null);
  const [resDraft, setResDraft] = useState(null);
  const [revDraft, setRevDraft] = useState(null);
  const [avExpanded, setAvExpanded] = useState(false);
  const [welcome, setWelcome] = useState(false);
  const [toastMsg, setToastMsg] = useState(null);
  const [msgBox, setMsgBox] = useState("");

  const setVK = (patch) => setV((p) => ({ ...p, ...patch }));
  const setSK = (patch) => setS((p) => ({ ...p, ...patch }));
  const markDirty = (label) => setVK({ dirty: true, dirtyLabel: label });
  const clearDirty = () => setVK({ dirty: false, dirtyLabel: "" });
  const toast = (m) => setToastMsg(m);
  useEffect(() => {
    if (!toastMsg) return;
    const id = setTimeout(() => setToastMsg(null), 2600);
    return () => clearTimeout(id);
  }, [toastMsg]);

  const pal = paletteOf(V.activeSport);
  const themeVars = { "--accent": pal.accent, "--accent-mid": pal.mid, "--accent-soft": pal.soft, "--accent-line": pal.line };
  const activeSports = S.sports.length ? S.sports : ["pickleball"];
  const groupMode = !isIndividual(V.activeSport);
  const myRating = (sport) => {
    if (S.optOut[sport]) return null;
    if (S.ratings[sport] != null) return S.ratings[sport];
    return isIndividual(sport) ? 80 : null;
  };
  const sportUpcoming = () => S.upcoming.filter((c) => c.sport === V.activeSport);
  const sportPast = () => S.past.filter((m) => m.sport === V.activeSport);
  const sportEvents = () => S.calendar.filter((e) => e.sport === V.activeSport);
  const sportVerifications = () => S.verifications.filter((v) => v.sport === V.activeSport);
  /* Connections, chats, and opponents are all scoped to the sport you
     are in. Multi-sport labels only ever appear on a profile. */
  const isConnected = (id) => S.connections.includes(id);
  const sportConnections = () => S.connections.filter((id) => P(id).sports.includes(V.activeSport));
  const sportThreads = () => S.threads.filter((t) => P(t.with).sports.includes(V.activeSport));
  const sportMsgRequests = () => S.msgRequests.filter((r) => P(r.with).sports.includes(V.activeSport));
  const recentMsgRequests = () => sportMsgRequests().filter((r) => r.hrs < 24);
  /* A thread you opened that has not been answered yet. No challenges
     until the other player writes back. */
  const threadWith = (id) => S.threads.find((t) => t.with === id);
  const canChallenge = (id) => { const t = threadWith(id); return !!t && !t.pending; };
  /* One calendar for every sport. A tentative challenge draws every slot
     it proposed until one is picked, the way an unanswered Outlook
     invitation would. */
  const calendarItems = () => {
    const out = [];
    S.calendar.forEach((e) => out.push({ key: e.id, id: e.id, kind: "event", sport: e.sport,
      date: e.date, start: e.start, end: e.end, label: e.opponent, status: "Confirmed" }));
    S.upcoming.forEach((c) => {
      const nm = P(c.opp).name;
      if (c.status === "Tentative" && c.slots) {
        c.slots.forEach((s, i) => out.push({ key: `${c.id}-${i}`, id: c.id, kind: "challenge", sport: c.sport,
          date: s.date, start: s.start, end: s.end, label: nm, status: "Tentative", slot: i }));
      } else out.push({ key: c.id, id: c.id, kind: "challenge", sport: c.sport,
        date: c.date, start: c.start, end: c.end, label: nm, status: "Confirmed" });
    });
    return out;
  };
  const firstSlot = (c) => (c.slots && c.slots.length ? c.slots[0] : { date: c.date, start: c.start, end: c.end });
  const slotLabel = (s) => `${fmtDate(s)} · ${fmtTime(s.start)}`;
  const pendingResults = () => sportEvents().filter((e) => !e.result && dateOf(e) < TODAY);
  const unreadNotifs = S.notifications.filter((n) => n.unread).length;

  /* ---------- Profile simulation ---------- */
  const restartOnboarding = () => {
    setS(seedA());
    setDraft({ name: "", username: "", age: "", gender: "", av: 0, sports: [], optOut: {} });
    setVK({ screen: "onboarding", ob: 0, tab: "home", activeSport: "pickleball", layer: null, fabOpen: false, dirty: false, dirtyLabel: "" });
    setChDraft(null); setScDraft(null); setEvDraft(null); setAvExpanded(false);
  };
  const loadProfile = (which) => {
    if (which === "A") { restartOnboarding(); return; }
    setS(seedB());
    setVK({ screen: "main", tab: "home", activeSport: "pickleball", layer: null, fabOpen: false, chatWith: null,
      matchTab: "upcoming", calTab: "week", weekOffset: 0, chatTab: "chats", friendQuery: "",
      dirty: false, dirtyLabel: "", mapFilters: { gender: "Any", rating: "Any" } });
    setChDraft(null); setScDraft(null); setEvDraft(null);
  };

  /* ---------- Overlays and the sport switcher ---------- */
  const openLayer = (cfg) => setVK({ layer: cfg, fabOpen: false });
  const closeLayer = () => {
    if (V.layer && ["challenge","score","editProfile","addEvent","addResult","review"].includes(V.layer.type)) {
      clearDirty(); setChDraft(null); setScDraft(null); setEvDraft(null); setResDraft(null); setRevDraft(null);
    }
    setVK({ layer: null, pendingSport: null });
  };
  const openSportSwitcher = () => {
    if (V.dirty) { setVK({ layer: { type: "exitIntent" } }); return; }
    setVK({ layer: { type: "sportSwitcher" }, fabOpen: false });
  };
  const switchSport = (k) => {
    if (V.dirty) { setVK({ pendingSport: k, layer: { type: "exitIntent" } }); return; }
    setVK({ activeSport: k, layer: null, calTab: "week", weekOffset: 0, matchTab: "upcoming" });
    toast(`The active sport is now ${SPORTS[k].name}.`);
  };
  const discardAndSwitch = () => {
    const k = V.pendingSport;
    setChDraft(null); setScDraft(null); setEvDraft(null);
    if (k) { setVK({ dirty: false, dirtyLabel: "", pendingSport: null, layer: null, activeSport: k }); toast(`The active sport is now ${SPORTS[k].name}.`); }
    else setVK({ dirty: false, dirtyLabel: "", layer: { type: "sportSwitcher" } });
  };
  const goTab = (t) => setVK({ tab: t, fabOpen: false, screen: "main" });

  /* ---------- Connections ----------
     There is one social action in the app. Connect opens a thread and
     drops you into it; the other player has to answer before either of
     you can send a challenge. */
  const connectWith = (id) => {
    let th = threadWith(id);
    if (!th) {
      th = { id: "t" + Date.now(), with: id, unread: 0, pending: true, msgs: [] };
      setSK({ threads: [th, ...S.threads] });
    }
    setVK({ layer: null, chatWith: th.id, screen: "chat", fabOpen: false });
  };
  const acceptMsgRequest = (rid) => {
    const r = S.msgRequests.find((x) => x.id === rid); if (!r) return;
    setS((p) => ({ ...p,
      msgRequests: p.msgRequests.filter((x) => x.id !== rid),
      connections: p.connections.includes(r.with) ? p.connections : [...p.connections, r.with],
      threads: [{ id: "t" + Date.now(), with: r.with, unread: 0, pending: false, msgs: [{ me: false, tx: r.tx, t: "Now" }] }, ...p.threads],
      notifications: p.notifications.map((n) => (n.who === r.with && n.kind === "connect" ? { ...n, unread: false } : n)),
    }));
    setVK({ chatTab: "chats" });
    toast(`You are now connected with ${P(r.with).name}.`);
  };
  const deleteMsgRequest = (rid) => {
    const r = S.msgRequests.find((x) => x.id === rid);
    setS((p) => ({ ...p,
      msgRequests: p.msgRequests.filter((x) => x.id !== rid),
      notifications: r ? p.notifications.map((n) => (n.who === r.with && n.kind === "connect" ? { ...n, unread: false } : n)) : p.notifications,
    }));
    toast("The request has been deleted.");
  };
  /* Picking a slot turns the proposal into a confirmed match. */
  const pickSlot = (tid, cid, i) => {
    const th = S.threads.find((t) => t.id === tid); if (!th) return;
    const m = th.msgs.find((x) => x.kind === "challenge" && x.cid === cid); if (!m) return;
    const s = m.slots[i];
    setS((p) => ({ ...p,
      threads: p.threads.map((t) => (t.id !== tid ? t : { ...t,
        msgs: t.msgs.map((x) => (x.kind === "challenge" && x.cid === cid ? { ...x, chosen: i } : x)) })),
      upcoming: p.upcoming.some((x) => x.id === cid)
        ? p.upcoming.map((x) => (x.id !== cid ? x : { id: x.id, sport: x.sport, opp: x.opp, venue: x.venue,
            status: "Confirmed", date: s.date, start: s.start, end: s.end }))
        : [...p.upcoming, { id: cid, sport: m.sport, opp: th.with, date: s.date, start: s.start, end: s.end, venue: m.venue, status: "Confirmed" }],
    }));
    toast(`Confirmed for ${slotLabel(s)}.`);
  };
  const declineSlots = (tid, cid) => {
    setS((p) => ({ ...p,
      threads: p.threads.map((t) => (t.id !== tid ? t : { ...t,
        msgs: t.msgs.map((x) => (x.kind === "challenge" && x.cid === cid ? { ...x, declined: true } : x)) })),
      upcoming: p.upcoming.filter((x) => x.id !== cid),
    }));
    toast("The challenge has been declined.");
  };

  /* ---------- Challenges and scores ---------- */
  /* You can put up to three times on the table. The other player picks
     one from the conversation, which is the only way a match is made. */
  const MAX_SLOTS = 3;
  const challengeDates = () => Array.from({ length: 14 }, (_, i) => {
    const d = new Date(TODAY); d.setDate(d.getDate() + i + 1); return iso(d);
  });
  const openChallenge = (opp) => {
    const pool = sportConnections().filter(canChallenge);
    const dates = challengeDates();
    setChDraft({ opp: opp || pool[0] || null,
      sport: isIndividual(V.activeSport) ? V.activeSport : INDIVIDUAL[0],
      venue: VENUES[0], slots: [{ date: dates[1], start: "18:30" }] });
    openLayer({ type: "challenge" });
  };
  const chSlot = (i, k, v) => { setChDraft((d) => ({ ...d, slots: d.slots.map((s, j) => (j === i ? { ...s, [k]: v } : s)) })); markDirty("Creating a challenge"); };
  const chAddSlot = () => setChDraft((d) => {
    if (d.slots.length >= MAX_SLOTS) return d;
    const dates = challengeDates(), used = d.slots.map((s) => s.date);
    markDirty("Creating a challenge");
    return { ...d, slots: [...d.slots, { date: dates.find((x) => !used.includes(x)) || dates[0], start: "18:30" }] };
  });
  const chRemoveSlot = (i) => setChDraft((d) => (d.slots.length <= 1 ? d : { ...d, slots: d.slots.filter((_, j) => j !== i) }));
  const endOf = (start) => { const m = toMin(start) + 90; return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`; };
  const submitChallenge = () => {
    const d = chDraft;
    const slots = d.slots.map((s) => ({ date: s.date, start: s.start, end: endOf(s.start) }));
    const cid = "c" + Date.now();
    const now = new Date();
    const t = `${now.getHours() % 12 || 12}:${String(now.getMinutes()).padStart(2, "0")} ${now.getHours() < 12 ? "AM" : "PM"}`;
    const existing = threadWith(d.opp);
    const tid = existing ? existing.id : "t" + Date.now();
    const msg = { me: true, kind: "challenge", cid, sport: d.sport, venue: d.venue, slots, chosen: null, declined: false, t };
    setS((p) => ({ ...p,
      threads: existing
        ? p.threads.map((x) => (x.id !== tid ? x : { ...x, msgs: [...x.msgs, msg] }))
        : [{ id: tid, with: d.opp, unread: 0, pending: false, msgs: [msg] }, ...p.threads],
      upcoming: [...p.upcoming, { id: cid, sport: d.sport, opp: d.opp, venue: d.venue, status: "Tentative", from: "me", slots }],
    }));
    toast(`${slots.length} time${slots.length === 1 ? "" : "s"} sent to ${P(d.opp).name}.`);
    setChDraft(null); clearDirty();
    setVK({ layer: null, activeSport: d.sport, chatWith: tid, screen: "chat", fabOpen: false });
  };
  const removeChallenge = (id) => {
    const c = S.upcoming.find((x) => x.id === id); if (!c) return;
    setS((p) => ({ ...p,
      upcoming: p.upcoming.filter((x) => x.id !== id),
      threads: p.threads.map((t) => ({ ...t, msgs: t.msgs.map((m) => (m.kind === "challenge" && m.cid === id ? { ...m, declined: true } : m)) })),
    }));
    toast(`The challenge with ${P(c.opp).name} has been withdrawn.`);
  };
  const openScore = () => {
    const pool = sportConnections().length ? sportConnections() : ALL_PLAYERS.filter((x) => x.sports.includes(V.activeSport)).map((x) => x.id);
    setScDraft({ mode: "Singles", sport: isIndividual(V.activeSport) ? V.activeSport : INDIVIDUAL[0],
      partner: pool[1] || pool[0], opp1: pool[0], opp2: pool[2] || pool[0],
      count: 3, results: [1, 1, 0], venue: VENUES[0] });
    openLayer({ type: "score" });
  };
  const submitScore = () => {
    const d = scDraft;
    const myWins = d.results.slice(0, d.count).filter((x) => x === 1).length;
    const theirWins = d.count - myWins, won = myWins > theirWins, opp = P(d.opp1);
    const before = myRating(d.sport);
    let delta = 0, after = before;
    if (before != null) { delta = ratingDelta(before, opp.ratings[d.sport] || opp.rating, won); after = before + delta; }
    const rec = { id: "m" + Date.now(), sport: d.sport, opp: d.opp1, partner: d.mode === "Doubles" ? d.partner : null,
      mode: d.mode, games: d.results.slice(0, d.count), won, score: `${myWins}-${theirWins} games`,
      date: "Aug 10, 2026", venue: d.venue, delta, before: before || 0, after: after || 0,
      source: "Manually uploaded score", duration: `${34 + d.count * 9} min` };
    setS((p) => ({ ...p, past: [rec, ...p.past], ratings: before != null ? { ...p.ratings, [d.sport]: after } : p.ratings }));
    setVK({ layer: null, activeSport: d.sport, lastVictory: { won, score: `${myWins}-${theirWins} games`, before: before || 0, delta, after: after || 0 } });
    setScDraft(null); clearDirty();
    toast(`A verification prompt has been sent to ${opp.name}.`);
    setTimeout(() => setVK({ screen: "victory" }), 700);
  };
  const resolveVerification = (id, ok) => {
    const v = S.verifications.find((x) => x.id === id); if (!v) return;
    const before = myRating(v.sport);
    const won = v.games.filter((g) => g === 1).length > v.games.filter((g) => g === 0).length;
    setS((p) => ({ ...p,
      verifications: p.verifications.filter((x) => x.id !== id),
      ratings: ok && before != null ? { ...p.ratings, [v.sport]: before + v.delta } : p.ratings,
      past: ok ? [{ id: "m" + Date.now(), sport: v.sport, opp: v.from, partner: v.partner || null, mode: v.mode,
        games: v.games, won, score: v.score, date: v.date, venue: v.venue, delta: v.delta,
        before: before || 0, after: (before || 0) + v.delta, source: "Verified score", duration: "48 min" }, ...p.past] : p.past,
    }));
    setVK({ layer: null });
    toast(ok ? `The result against ${P(v.from).name} has been confirmed.` : `Your dispute has been sent to ${P(v.from).name}.`);
  };
  const demoVictory = () => setVK({ lastVictory: { won: true, score: "2-0 games", before: 55, delta: 13, after: 68 }, screen: "victory" });

  /* ---------- Calendar (group sports) ---------- */
  const openAddEvent = () => {
    setEvDraft({ title: "League fixture", team: "Riverside XI", opponent: "", date: iso(TODAY), start: "18:00", end: "20:00", venue: VENUES[0] });
    openLayer({ type: "addEvent" });
  };
  const submitEvent = () => {
    const d = evDraft;
    if (!(d.title.trim() && d.team.trim() && d.opponent.trim())) { toast("Please complete every required field."); return; }
    if (toMin(d.end) <= toMin(d.start)) { toast("The finish time must be after the start time."); return; }
    setS((p) => ({ ...p, calendar: [...p.calendar, { id: "e" + Date.now(), sport: V.activeSport, title: d.title.trim(),
      team: d.team.trim(), opponent: d.opponent.trim(), date: d.date, start: d.start, end: d.end, venue: d.venue, result: null }] }));
    const [y, m, dd] = d.date.split("-").map(Number);
    const diff = Math.round((startOfWeek(new Date(y, m - 1, dd), 0) - startOfWeek(TODAY, 0)) / (7 * 24 * 3600 * 1000));
    setEvDraft(null); clearDirty();
    setVK({ layer: null, tab: "matches", calTab: "week", weekOffset: diff });
    toast("The fixture has been added to your calendar.");
  };
  const removeEvent = (id) => {
    setSK({ calendar: S.calendar.filter((e) => e.id !== id) });
    setVK({ layer: null }); toast("The fixture has been removed from your calendar.");
  };
  const submitResult = (id) => {
    const e = S.calendar.find((x) => x.id === id);
    const outcome = resDraft.outcome;
    setS((p) => ({ ...p, calendar: p.calendar.map((x) => (x.id === id
      ? { ...x, result: { outcome, score: resDraft.score.trim() || `${outcome} against ${e.opponent}` } } : x)) }));
    setResDraft(null); clearDirty(); setVK({ layer: null });
    toast("The result has been saved.");
  };
  const submitReview = () => {
    const who = P(revDraft.who).name;
    setRevDraft(null); clearDirty(); setVK({ layer: null });
    toast(`Your review of ${who} has been submitted.`);
  };

  /* ---------- Chat ---------- */
  const openChat = (tid) => {
    setS((p) => ({ ...p, threads: p.threads.map((x) => (x.id === tid ? { ...x, unread: 0 } : x)) }));
    setVK({ chatWith: tid, screen: "chat", fabOpen: false, layer: null });
  };
  const sendMsg = () => {
    const tx = msgBox.trim(); if (!tx) return;
    const now = new Date();
    const t = `${now.getHours() % 12 || 12}:${String(now.getMinutes()).padStart(2, "0")} ${now.getHours() < 12 ? "AM" : "PM"}`;
    const th = S.threads.find((x) => x.id === V.chatWith);
    const first = th && th.pending && !th.msgs.length;
    setS((p) => ({ ...p, threads: p.threads.map((x) => (x.id === V.chatWith ? { ...x, msgs: [...x.msgs, { me: true, tx, t }] } : x)) }));
    setMsgBox("");
    if (first) toast(`Your message is waiting in ${P(th.with).name}'s requests.`);
    /* Their reply is what opens the connection and unlocks challenges. */
    setTimeout(() => setS((p) => {
      const target = p.threads.find((x) => x.id === V.chatWith);
      return { ...p,
        threads: p.threads.map((x) => (x.id === V.chatWith
          ? { ...x, pending: false, msgs: [...x.msgs, { me: false, tx: "Sounds good. See you on court.", t }] } : x)),
        connections: target && !p.connections.includes(target.with) ? [...p.connections, target.with] : p.connections };
    }), 1200);
  };

  /* ================================================================
     ONBOARDING
     ================================================================ */
  const obBack = () => { if (V.ob === 0) { toast("You are on the first screen of the introduction."); return; } setVK({ ob: V.ob - 1 }); };
  const obNext = () => setVK({ ob: V.ob + 1 });
  const identityComplete = () => !!(draft.name.trim() && draft.username.trim() && String(draft.age).trim() && draft.gender);
  const submitIdentity = () => {
    if (!identityComplete()) { toast("Please complete every field to continue."); return; }
    setSK({ me: { name: draft.name.trim(), username: draft.username.trim().startsWith("@") ? draft.username.trim() : "@" + draft.username.trim(),
      age: draft.age, gender: draft.gender, av: draft.av } });
    clearDirty(); obNext();
  };
  const toggleSport = (k) => {
    setDraft((d) => {
      const s = [...d.sports], i = s.indexOf(k);
      if (i > -1) s.splice(i, 1);
      else { if (s.length >= 4) { toast("You can select a maximum of four sports."); return d; } s.push(k); }
      return { ...d, sports: s };
    });
    markDirty("Sport selection");
  };
  const confirmSports = () => { setSK({ sports: [...draft.sports] }); setVK({ activeSport: draft.sports[0], ob: V.ob + 1, dirty: false, dirtyLabel: "" }); };
  const finishOnboarding = () => {
    const ratings = {}, peer = {};
    draft.sports.forEach((k) => { if (isIndividual(k) && !draft.optOut[k]) ratings[k] = 80; if (!isIndividual(k)) peer[k] = null; });
    setSK({ optOut: { ...draft.optOut }, ratings, peer, onboarded: true });
    clearDirty(); setWelcome(true);
    setTimeout(() => { setWelcome(false); setVK({ screen: "main", tab: "home" }); }, 2800);
  };

  const Hero = ({ tint, glyphs }) => (
    <div className="hero" style={{ background: tint }}>
      {glyphs.map(([sport, x, y, c, size, delay], i) => (
        <i key={i} style={{ left: `${x}%`, top: `${y}%`, animationDelay: `${delay}s` }}><SportIcon sport={sport} size={size} color={c} /></i>
      ))}
    </div>
  );

  function renderOnboarding() {
    const step = OB_STEPS[V.ob];
    const pct = Math.round(((V.ob + 1) / OB_STEPS.length) * 100);
    const cta = {
      intro1: ["Continue", obNext, true],
      intro2: ["Continue", obNext, true],
      intro3: ["Get started", obNext, true],
      identity: ["Create profile →", submitIdentity, identityComplete()],
      sports: [`Continue with ${draft.sports.length || "no"} sport${draft.sports.length === 1 ? "" : "s"}`, confirmSports, draft.sports.length > 0],
      setup: ["Finish setup", finishOnboarding, true],
    }[step];
    const sportRow = (k) => {
      const p = SPORTS[k], on = draft.sports.includes(k);
      return (
        <button key={k} className={`sport-row ${on ? "on" : ""}`} onClick={() => toggleSport(k)}
          style={on ? { borderColor: p.accent, background: p.soft } : undefined}>
          <span className="sr-ic" style={{ background: on ? "#fff" : p.soft }}><SportIcon sport={k} size={28} color={p.accent} /></span>
          <span style={{ flex: 1, minWidth: 0 }}>
            <span className="sr-nm" style={{ display: "block", color: on ? p.accent : undefined }}>{p.name}</span>
            <span className="sr-sub" style={{ display: "block" }}>{p.cat === "individual" ? "Individual sport · MP Rated" : "Group sport · Peer evaluated"}</span>
          </span>
          <span className="sr-ck" style={on ? { background: p.accent, borderColor: "transparent" } : undefined}>{on && Ico.check(12)}</span>
        </button>
      );
    };
    return (
      <div className="ob-wrap fade-in">
        <div className="ob-scroll">
          <div className="ob-top">
            <button className="back" onClick={obBack} aria-label="Go back">{Ico.back()}</button>
          </div>
          {V.ob >= 3 && <div className="progress"><i style={{ width: `${pct}%` }} /></div>}

          {step === "intro1" && (<>
            <Hero tint="linear-gradient(150deg,#EFF8F1,#ECF3FB 46%,#FDF3E9)"
              glyphs={[["pickleball",10,18,"#4CA85F",38,0],["badminton",66,12,"#3D82C4",36,.5],["cricket",38,42,"#CE5555",42,1],["pingpong",14,60,"#D0762F",32,1.4],["soccer",72,56,"#2F7A50",36,.8],["volleyball",50,74,"#7857BE",28,1.8]]} />
            <div className="eyebrow">Find your people</div>
            <h1 className="h1">Discover local sports partners.</h1>
            <p className="sub">Match Point connects you with players a few streets away who play the sports you play. Browse the neighbourhood, meet people on court, and build a regular group you look forward to seeing every week.</p>
            <div style={{ height: 20 }} />
            {[[Ico.pin(19),"Players near you","See who is playing inside your radius."],
              [Ico.users(19),"Local communities","Join groups that already play your sports."],
              [Ico.trophy(19),"Friendly competition","Track progress without losing the fun."]].map(([ic,t,s],i)=>(
              <div key={i} className="card tight" style={{ display:"flex", gap:12, alignItems:"center", marginBottom:10 }}>
                <div style={{ width:38, height:38, borderRadius:13, display:"grid", placeItems:"center", background:"var(--accent-soft)", color:"var(--accent)", flex:"0 0 auto" }}>{ic}</div>
                <div><div className="h3">{t}</div><div className="tiny" style={{ marginTop:2 }}>{s}</div></div>
              </div>
            ))}
          </>)}

          {step === "intro2" && (<>
            <Hero tint="linear-gradient(150deg,#ECF3FB,#FDF3E9 52%,#F3EEFC)"
              glyphs={[["badminton",18,24,"#3D82C4",48,0],["pickleball",58,32,"#4CA85F",42,.7],["pingpong",40,64,"#D0762F",34,1.3]]} />
            <div className="eyebrow">Fair matchmaking</div>
            <h1 className="h1">Play people at your level.</h1>
            <p className="sub">Individual sports use the MP Rating, a single number that moves in small, honest steps. Beat someone stronger and you climb faster. Group sports skip the number entirely and rely on peer skill evaluations from the people who played beside you.</p>
            <div style={{ height: 18 }} />
            <div className="card">
              {[["Even opponent","+1 to +2 points"],["Stronger opponent","+3 points"],["Significant upset","+4 to +5 points"]].map(([k,v],i)=>(
                <div key={k}>
                  <div className="kv"><span>{k}</span><b style={{ color:"var(--accent)" }}>{v}</b></div>
                  {i<2 && <div style={{ height:1, background:"var(--line)" }} />}
                </div>
              ))}
            </div>
          </>)}

          {step === "intro3" && (<>
            <Hero tint="linear-gradient(150deg,#FCEEEE,#EAF5EF 52%,#F3EEFC)"
              glyphs={[["cricket",22,20,"#CE5555",44,0],["soccer",60,50,"#2F7A50",40,.6],["volleyball",34,60,"#7857BE",32,1.2]]} />
            <div className="eyebrow">Stay organised</div>
            <h1 className="h1">Challenge, play, log the score.</h1>
            <p className="sub">In individual sports you send a challenge, play the match, and upload the score for your opponent to verify. In group sports you keep a shared calendar of fixtures and rate each other afterwards, because a squad of eleven needs a schedule far more than it needs a ladder.</p>
          </>)}

          {step === "identity" && (<>
            <div className="eyebrow">Your identity</div>
            <h1 className="h1">Create your profile.</h1>
            <p className="sub">This is how other players will find you and recognise you on the map. Every field below is required.</p>
            <div style={{ height: 20 }} />
            <div style={{ display:"flex", justifyContent:"center", marginBottom:18 }}><Avatar idx={draft.av} size={92} ring /></div>
            <div className="btn-row" style={{ marginBottom:16 }}>
              <button className="btn btn-ghost" onClick={() => toast("Photo library access is simulated in this prototype.")}>{Ico.gallery()} Photo library</button>
              <button className="btn btn-ghost" onClick={() => toast("Camera access is simulated in this prototype.")}>{Ico.camera()} Camera</button>
            </div>
            <div className="sec-head" style={{ marginTop:6 }}>
              <h4 style={{ fontSize:"var(--fs-label)", fontWeight:800, letterSpacing:".05em", textTransform:"uppercase", color:"var(--ink-3)" }}>Or choose from 50 avatars</h4>
              <button className="more" onClick={() => setAvExpanded(!avExpanded)}>{avExpanded ? "Collapse" : "Expand"}</button>
            </div>
            <div style={avExpanded
              ? { display:"grid", gridTemplateColumns:"repeat(6,1fr)", gap:8 }
              : { display:"flex", gap:10, overflowX:"auto", padding:"2px 0 8px" }}>
              {Array.from({ length: 50 }, (_, i) => (
                <button key={i} className="av" onClick={() => { setDraft((d) => ({ ...d, av: i })); markDirty("Profile details"); }}
                  style={{ flex:"0 0 auto", width: avExpanded ? "100%" : 54, aspectRatio: avExpanded ? "1" : undefined,
                    height: avExpanded ? undefined : 54,
                    border: `2px solid ${draft.av === i ? "var(--accent)" : "var(--line)"}` }}
                  dangerouslySetInnerHTML={{ __html: personSVG(i, 54) }} />
              ))}
            </div>
            <div style={{ height: 20 }} />
            <div className="field"><label>Name <span className="req">*</span></label>
              <input className="input" placeholder="Sasshh" value={draft.name} onChange={(e) => { const v = e.target.value; setDraft((d) => ({ ...d, name: v })); markDirty("Profile details"); }} /></div>
            <div className="field"><label>Unique username <span className="req">*</span></label>
              <input className="input" placeholder="@sashpash" value={draft.username} onChange={(e) => { const v = e.target.value; setDraft((d) => ({ ...d, username: v })); markDirty("Profile details"); }} />
              <div className="hint">This must be unique. It is how friends search for you.</div></div>
            <div className="field"><label>Age <span className="req">*</span></label>
              <input className="input" inputMode="numeric" placeholder="25" value={draft.age} onChange={(e) => { const v = e.target.value; setDraft((d) => ({ ...d, age: v })); markDirty("Profile details"); }} /></div>
            <div className="field"><label>Gender <span className="req">*</span></label>
              <div className="pill-row">{["Male","Female","Non-binary"].map((g) => (
                <button key={g} className={`pill ${draft.gender === g ? "on" : ""}`} onClick={() => { setDraft((d) => ({ ...d, gender: g })); markDirty("Profile details"); }}>{g}</button>
              ))}</div></div>
          </>)}

          {step === "sports" && (<>
            <div className="eyebrow">Your sports</div>
            <h1 className="h1">Pick up to four sports.</h1>
            <p className="sub">Every sport has its own colour, and the whole app takes on that colour while you are playing it.</p>
            <div style={{ height: 22 }} />
            <SecHead>Individual and dual sports</SecHead>
            {INDIVIDUAL.map(sportRow)}
            <SecHead>Group sports</SecHead>
            {GROUP.map(sportRow)}
            <div style={{ height: 6 }} />
            <div className="tiny">{draft.sports.length} of 4 selected.</div>
          </>)}

          {step === "setup" && (<>
            <div className="eyebrow">Set up your sports</div>
            <h1 className="h1">Configure each sport.</h1>
            <p className="sub">Individual sports use the MP Rating. Group sports run on a calendar and are evaluated by the people who play alongside you.</p>
            <div style={{ height: 20 }} />
            {draft.sports.map((k) => {
              const p = SPORTS[k];
              if (isIndividual(k)) {
                const off = !!draft.optOut[k];
                return (
                  <div key={k} className="setup-card" style={{ borderColor: p.line }}>
                    <div className="sc-wash" style={{ background: `radial-gradient(circle, ${p.soft}, transparent 70%)` }} />
                    <div className="sc-ic"><SportIcon sport={k} size={28} color={p.accent} /></div>
                    <div className="sc-nm" style={{ color: p.accent }}>{p.name}</div>
                    <div className="sc-val" style={{ color: off ? "var(--ink-4)" : "var(--ink)" }}>{off ? "Unrated" : "80"}</div>
                    <div className="sc-sub">{off ? "You will play without a competitive score." : "Everyone starts at 80 and moves in small steps."}</div>
                    <div className="sc-foot">
                      <div className="checkrow" style={{ flex: 1 }} onClick={() => { setDraft((d) => ({ ...d, optOut: { ...d.optOut, [k]: !d.optOut[k] } })); markDirty("Sport setup"); }}>
                        <div className={`checkbox ${off ? "on" : ""}`} style={off ? { background: p.accent, borderColor: p.accent } : undefined}>{off && Ico.check()}</div>
                        <div style={{ fontSize: "var(--fs-label)", fontWeight: 600 }}>Opt out of the rating system.</div>
                      </div>
                      <button className="link" style={{ color: p.accent }} onClick={() => openLayer({ type: "readmore", sport: k })}>Read more</button>
                    </div>
                  </div>
                );
              }
              return (
                <div key={k} className="setup-card" style={{ borderColor: p.line }}>
                  <div className="sc-wash" style={{ background: `radial-gradient(circle, ${p.soft}, transparent 70%)` }} />
                  <div className="sc-ic"><SportIcon sport={k} size={28} color={p.accent} /></div>
                  <div className="sc-nm" style={{ color: p.accent }}>{p.name}</div>
                  <div className="sc-val text">Peer rated</div>
                  <div className="sc-sub">Fixtures live on a shared calendar. Teammates rate you afterwards.</div>
                  <div className="sc-foot">
                    <div style={{ flex: 1 }}><Stars value={5} color={p.mid} size={14} /></div>
                    <button className="link" style={{ color: p.accent }} onClick={() => openLayer({ type: "readmore", sport: k })}>Read more</button>
                  </div>
                </div>
              );
            })}
          </>)}
          <div style={{ height: 8 }} />
        </div>
        <div className="ob-foot">
          <button className="btn btn-dark" disabled={!cta[2]} onClick={cta[1]}>{cta[0]}</button>
        </div>
      </div>
    );
  }

  /* ================================================================
     SHELL
     ================================================================ */
  const tabTitle = { home: "Home", map: "Map", matches: groupMode ? "Calendar" : "Matches", chats: "Chats", profile: "Profile" }[V.tab];
  const AppBar = () => (
    <div className="appbar">
      <button className="bar-btn" onClick={openSportSwitcher} title="Switch the active sport" aria-label="Switch the active sport">
        <SportIcon sport={V.activeSport} size={21} color={pal.accent} />
        <span className="caret">{Ico.down(11)}</span>
      </button>
      <div className="appbar-title">{tabTitle}</div>
      <button className="bar-btn" onClick={() => openLayer({ type: "notifications" })} aria-label="Notifications">
        {Ico.bell(19)}<span className={`bar-badge ${unreadNotifs ? "" : "zero"}`}>{unreadNotifs}</span>
      </button>
    </div>
  );
  const NavBar = () => {
    const item = (k, label, ic) => (
      <button key={k} className={`nav-item ${V.tab === k ? "on" : ""}`} onClick={() => goTab(k)}>
        <i className="dash" />{ic(21)}<span>{label}</span>
      </button>
    );
    return (
      <div className="navwrap">
        <div className="navbar">
          {item("map", "Map", Ico.map)}
          {item("matches", groupMode ? "Calendar" : "Matches", groupMode ? Ico.calendar : Ico.matches)}
          <button className={`nav-center ${V.tab === "home" ? "on" : ""}`} onClick={() => goTab("home")}>
            <span className="bubble">{Ico.home(26)}</span><span>Home</span>
          </button>
          {item("chats", "Chats", Ico.friends)}
          {item("profile", "Profile", Ico.profile)}
        </div>
      </div>
    );
  };
  /* A black circle on top of a black button reads as one shape. When the
     fab overlaps anything with a solid dark fill it flips to white with a
     dark ring, so it stays a separate, tappable object. */
  const fabRef = useRef(null);
  const syncFab = () => {
    const fab = fabRef.current; if (!fab) return;
    const r = fab.getBoundingClientRect();
    if (!r.width) { fab.classList.remove("invert"); return; }
    const over = [...document.querySelectorAll(".mp .btn-dark, .mp .fab-opt")].some((el) => {
      if (el === fab) return false;
      const b = el.getBoundingClientRect();
      if (!b.width) return false;
      return !(b.right < r.left || b.left > r.right || b.bottom < r.top || b.top > r.bottom);
    });
    fab.classList.toggle("invert", over);
  };
  /* The overlap changes as the page scrolls, so recheck as it moves. */
  useEffect(() => {
    if (V.screen !== "main") return;
    syncFab();
    const body = document.querySelector(".mp .body");
    if (!body) return;
    body.addEventListener("scroll", syncFab, { passive: true });
    return () => body.removeEventListener("scroll", syncFab);
  });
  const Fab = () => {
    const opts = groupMode
      ? [[Ico.star(15, "currentColor"), "Submit a review", () => { setRevDraft({ who: S.connections[0] || ALL_PLAYERS[0].id, scores: Object.fromEntries((PEER_SKILLS[V.activeSport] || []).map((s) => [s, 4])) }); openLayer({ type: "review" }); }],
         [Ico.calendar(15), "Add to calendar", openAddEvent]]
      : [[Ico.trophy(15), "Add a challenge", () => openChallenge()],
         [Ico.chart(15), "Upload scores", openScore]];
    return (
      <div className="fab-wrap">
        {V.fabOpen && opts.map(([ic, label, fn], i) => (
          <button key={label} className="fab-opt" style={{ animationDelay: `${i * 0.05}s` }} onClick={fn}>{ic} {label}</button>
        ))}
        <button ref={fabRef} className={`fab ${V.fabOpen ? "open" : ""}`} aria-label="Open quick actions" onClick={() => setVK({ fabOpen: !V.fabOpen })}>{Ico.plus()}</button>
      </div>
    );
  };

  /* ================================================================
     HOME
     ================================================================ */
  const PosterVerify = ({ v }) => {
    const o = P(v.from);
    return (
      <div className="poster">
        <AvatarPanel idx={o.av} sport={v.sport} />
        <div className="poster-body">
          <div className="poster-t">{o.name}</div>
          <div className="poster-s">{v.mode} · {v.score}</div>
          <div className="poster-s">{v.date}</div>
          <div className="poster-foot">
            <span className="chip" style={{ background: "#FDF3E9", color: "#D0762F" }}>Verify</span>
            <button className="open-btn" aria-label="Open this verification"
              onClick={(e) => { e.stopPropagation(); openLayer({ type: "verifyDetail", id: v.id }); }}>{Ico.chev(14)}</button>
          </div>
        </div>
      </div>
    );
  };
  const PosterConnectReq = ({ r }) => {
    const o = P(r.with);
    return (
      <div className="poster">
        <AvatarPanel idx={o.av} sport={V.activeSport} />
        <div className="poster-body">
          <div className="poster-t">{o.name}</div>
          <div className="poster-s">{o.dist} miles away</div>
          <div className="poster-s">{agoLabel(r.hrs)}</div>
          <div className="poster-foot">
            <span className="chip accent">Wants to connect</span>
            <button className="open-btn" aria-label="Open this connection request"
              onClick={(e) => { e.stopPropagation(); openLayer({ type: "connectReqDetail", id: r.id }); }}>{Ico.chev(14)}</button>
          </div>
        </div>
      </div>
    );
  };
  const PosterChallenge = ({ c }) => {
    const o = P(c.opp), tent = c.status === "Tentative", s = firstSlot(c);
    return (
      <div className="poster" onClick={() => openLayer({ type: "challengeDetail", id: c.id })}>
        <AvatarPanel idx={o.av} sport={c.sport} />
        <div className="poster-body">
          <div className="poster-t">{o.name}</div>
          <div className="poster-s">{slotLabel(s)}</div>
          <div className="poster-s">{tent ? `${c.slots.length} time${c.slots.length === 1 ? "" : "s"} proposed` : c.venue}</div>
          <div className="poster-foot">
            <span className={`chip ${tent ? "" : "accent"}`}>{tent ? (c.from === "me" ? "Awaiting reply" : "Needs a reply") : "Confirmed"}</span>
          </div>
        </div>
      </div>
    );
  };
  const PosterEvent = ({ e }) => {
    const p = paletteOf(e.sport);
    return (
      <div className="poster" onClick={() => openLayer({ type: "eventDetail", id: e.id })}>
        <div className="poster-top" style={{ height: 124, background: `linear-gradient(165deg, ${p.soft}, #fff)` }}>
          <span className="glyph"><SportIcon sport={e.sport} size={96} color={p.mid} /></span>
          <div style={{ textAlign: "center", position: "relative" }}>
            <div style={{ fontSize: "var(--fs-micro)", fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase", color: p.accent }}>{fmtDate(e)}</div>
            <div style={{ fontSize: "var(--fs-h1)", fontWeight: 800, color: "var(--ink)", marginTop: 2 }}>{fmtTime(e.start)}</div>
          </div>
        </div>
        <div className="poster-body">
          <div className="poster-t">{e.opponent}</div>
          <div className="poster-s">{e.title}</div>
          <div className="poster-s">{e.venue}</div>
        </div>
      </div>
    );
  };
  const PosterResultPrompt = ({ e }) => (
    <div className="poster">
      <div className="poster-top" style={{ height: 124, background: "linear-gradient(165deg,#FDF3E9,#fff)" }}>
        <span className="glyph"><SportIcon sport={e.sport} size={96} color="#F2BE93" /></span>
        <div style={{ textAlign: "center", position: "relative" }}>
          <div style={{ fontSize: "var(--fs-micro)", fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase", color: "#D0762F" }}>Result needed</div>
          <div style={{ fontSize: "var(--fs-h1)", fontWeight: 800, marginTop: 2 }}>{fmtDate(e)}</div>
        </div>
      </div>
      <div className="poster-body">
        <div className="poster-t">{e.opponent}</div>
        <div className="poster-s">{e.title}</div>
        <button className="btn btn-dark btn-sm" style={{ width: "100%", marginTop: 8 }}
          onClick={() => { setResDraft({ outcome: "Won", score: "" }); openLayer({ type: "addResult", id: e.id }); }}>Add the result</button>
      </div>
    </div>
  );
  const PosterPlayer = ({ pl }) => {
    const k = V.activeSport;
    return (
      <div className="poster" onClick={() => openLayer({ type: "drawer", id: pl.id })}>
        <AvatarPanel idx={pl.av} sport={k} />
        <div className="poster-body">
          <div className="poster-t">{pl.name}</div>
          <div className="poster-s">{pl.dist} miles away</div>
          <div className="poster-foot">
            <span className="chip accent">{isIndividual(k) ? pl.ratings[k] || pl.rating : "Peer rated"}</span>
            <span className="tiny">{pl.age}</span>
          </div>
        </div>
      </div>
    );
  };
  const PosterCommunity = ({ c }) => {
    const p = paletteOf(c.sport);
    const meta = c.kind === "Facility" ? `${c.courts} courts · ${c.d} miles away` : `${c.m} members · ${c.d} miles away`;
    const cta = c.kind === "Facility" ? "View facility" : (c.kind === "League" || c.kind === "Cup" ? "Join league" : "Join community");
    return (
      <div className="poster wide">
        <div className="poster-top venue" style={{ height: 104 }}>
          <div style={{ width: "100%", height: "100%" }} dangerouslySetInnerHTML={{ __html: venueArt(c) }} />
          <span className="venue-kind" style={{ color: p.accent }}>{c.kind}</span>
        </div>
        <div className="poster-body">
          <div className="poster-t">{c.n}</div>
          <div className="poster-s">{meta}</div>
          <button className="btn btn-outline btn-sm" style={{ width: "100%", marginTop: 8 }} onClick={() => toast(`A request has been sent to ${c.n}.`)}>{cta}</button>
        </div>
      </div>
    );
  };

  function viewHome() {
    const k = V.activeSport, mine = myRating(k);
    const hour = new Date().getHours();
    const greet = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";
    const vers = sportVerifications();
    const reqs = recentMsgRequests();
    const ups = [...sportUpcoming()].sort((a, b) => {
      const rank = (c) => (c.status === "Tentative" ? (c.from === "them" ? 0 : 1) : 2);
      return rank(a) - rank(b) || firstSlot(a).date.localeCompare(firstSlot(b).date);
    });
    const evs = sportEvents().filter((e) => dateOf(e) >= TODAY).sort((a, b) => a.date.localeCompare(b.date));
    const pend = pendingResults();
    const pool = ALL_PLAYERS.filter((pl) => pl.sports.includes(k) && !isConnected(pl.id)).slice(0, 8);
    const comms = COMMUNITIES.filter((c) => c.sport === k);
    const sections = [];

    if (vers.length) sections.push(
      <React.Fragment key="ver">
        <SecHead action={<span className="more">{vers.length} waiting</span>}>Verifications</SecHead>
        <div className="rail">{vers.map((v) => <PosterVerify key={v.id} v={v} />)}</div>
      </React.Fragment>);

    if (reqs.length) sections.push(
      <React.Fragment key="req">
        <SecHead action={<span className="more" onClick={() => { goTab("chats"); setVK({ chatTab: "requests" }); }}>See all</span>}>Connection requests</SecHead>
        <div className="rail">{reqs.map((r) => <PosterConnectReq key={r.id} r={r} />)}</div>
      </React.Fragment>);

    if (groupMode) {
      if (evs.length) sections.push(
        <React.Fragment key="fix">
          <SecHead action={<span className="more" onClick={() => goTab("matches")}>Calendar</span>}>Upcoming fixtures</SecHead>
          <div className="rail">{evs.map((e) => <PosterEvent key={e.id} e={e} />)}</div>
        </React.Fragment>);
      if (pend.length) sections.push(
        <React.Fragment key="res">
          <SecHead action={<span className="more">{pend.length} waiting</span>}>Add your results</SecHead>
          <div className="rail">{pend.map((e) => <PosterResultPrompt key={e.id} e={e} />)}</div>
        </React.Fragment>);
    } else if (ups.length) {
      sections.push(
        <React.Fragment key="ch">
          <SecHead action={<span className="more" onClick={() => goTab("matches")}>See all</span>}>Challenges</SecHead>
          <div className="rail">{ups.map((c) => <PosterChallenge key={c.id} c={c} />)}</div>
        </React.Fragment>);
    }

    if (pool.length) sections.push(
      <React.Fragment key="opp">
        <SecHead action={<span className="more" onClick={() => goTab("map")}>Open map</span>}>{groupMode ? "Players in your area" : "Recommended opponents"}</SecHead>
        <div className="rail">{pool.map((pl) => <PosterPlayer key={pl.id} pl={pl} />)}</div>
      </React.Fragment>);

    if (comms.length) sections.push(
      <React.Fragment key="near">
        <SecHead>{SPORTS[k].name} near you</SecHead>
        <div className="rail">{comms.map((c) => <PosterCommunity key={c.n} c={c} />)}</div>
      </React.Fragment>);

    return (
      <div className="body fade-in">
        <div className="hero-wrap">
          <div className="hero-greet">{greet}, {S.me.name || "player"}!</div>
          <div className="hero-sub">{SPORTS[k].name} · {isIndividual(k) ? (mine == null ? "Unrated" : `MP Rating ${mine}`) : "Peer rated by your squad"}</div>
          <HeroArt sport={k} rating={isIndividual(k) ? mine : null} avIdx={S.me.av} />
        </div>
        {sections.length ? sections : (
          <Empty icon={Ico.home(30)} title="Nothing needs you right now."
            body="Challenges, verifications, and connection requests will collect here as they arrive." />
        )}
        <div style={{ height: 8 }} />
      </div>
    );
  }

  /* ================================================================
     MAP — a full, pannable, zoomable board with clustering
     ================================================================ */
  const mapViewRef = useRef(null);
  const mapWorldRef = useRef(null);
  const mapPinsRef = useRef(null);
  const mapState = useRef({ x: 0, y: 0, z: 1, ready: false, clusters: [] });

  const mapList = () => {
    const f = V.mapFilters;
    let list = ALL_PLAYERS.filter((p) => p.sports.includes(V.activeSport)).slice(0, 19);
    if (f.gender !== "Any") list = list.filter((p) => p.gender === f.gender);
    if (f.rating !== "Any") {
      const [lo, hi] = { "Under 80": [0, 79], "80 to 110": [80, 110], "Above 110": [111, 999] }[f.rating];
      list = list.filter((p) => { const r = p.ratings[V.activeSport] || p.rating; return r >= lo && r <= hi; });
    }
    return list;
  };
  /* Markers merge on the distance they end up at ON SCREEN, not on which
     grid cell they happen to fall in, which is how Figma keeps comment
     pins from ever sitting on top of one another. Two markers are
     therefore never closer than CLUSTER_R pixels, at any zoom. */
  const mapPoints = () => mapList().map((p, i) => {
    const [x, y] = PIN_POS[i % PIN_POS.length];
    return { p, x, y };
  });
  const mapClusters = () => {
    const rw = CLUSTER_R / mapState.current.z;      /* the radius in world units */
    /* Sorting first keeps the grouping identical between renders. */
    const pts = mapPoints().sort((a, b) => a.y - b.y || a.x - b.x || (a.p.id < b.p.id ? -1 : 1));
    const taken = new Array(pts.length).fill(false);
    const out = [];
    pts.forEach((seed, si) => {
      if (taken[si]) return;
      taken[si] = true;
      const items = [seed];
      let cx = seed.x, cy = seed.y, grew = true;
      /* Absorb anything inside the radius, then re-check from the new
         centre, so a long row of players collapses into one bubble. */
      while (grew) {
        grew = false;
        pts.forEach((o, oi) => {
          if (taken[oi]) return;
          if (Math.hypot(o.x - cx, o.y - cy) <= rw) {
            taken[oi] = true; items.push(o); grew = true;
            cx = items.reduce((s, q) => s + q.x, 0) / items.length;
            cy = items.reduce((s, q) => s + q.y, 0) / items.length;
          }
        });
      }
      out.push({ x: cx, y: cy, items });
    });
    /* Centroids can drift towards each other while groups grow, so make
       one merging pass to guarantee the minimum spacing holds. */
    for (let i = 0; i < out.length; i++) {
      for (let j = i + 1; j < out.length; j++) {
        if (Math.hypot(out[i].x - out[j].x, out[i].y - out[j].y) <= rw) {
          out[i].items = out[i].items.concat(out[j].items);
          out[i].x = out[i].items.reduce((s, q) => s + q.x, 0) / out[i].items.length;
          out[i].y = out[i].items.reduce((s, q) => s + q.y, 0) / out[i].items.length;
          out.splice(j, 1); j = i;
        }
      }
    }
    return out;
  };
  const renderPins = () => {
    const el = mapPinsRef.current; if (!el) return;
    const inv = 1 / mapState.current.z;
    const clusters = mapClusters();
    mapState.current.clusters = clusters;
    el.innerHTML = clusters.map((c, i) => {
      if (c.items.length === 1) {
        const { p, x, y } = c.items[0];
        const r = isIndividual(V.activeSport) ? (p.ratings[V.activeSport] || p.rating) : "★";
        const linked = isConnected(p.id);
        return `<div class="pin ${linked ? "linked" : ""}" data-id="${p.id}" style="left:${x}px;top:${y}px;transform:translate(-50%,-50%) scale(${inv})">
          <div class="av" style="width:28px;height:28px">${personSVG(p.av, 28)}</div><span class="pin-rt">${r}</span>
        </div>`;
      }
      const n = c.items.length;
      const size = Math.min(60, 40 + n * 2.6);
      return `<div class="map-cluster" data-cluster="${i}" role="button" aria-label="${n} players here, tap to zoom in"
        style="left:${c.x}px;top:${c.y}px;width:${size}px;height:${size}px;transform:translate(-50%,-50%) scale(${inv})">
        <i class="s1"></i><i class="s2"></i>
        <span class="mc-face"><span class="mc-n" style="font-size:${n > 9 ? 15 : 17}px">${n}</span></span></div>`;
    }).join("");
  };
  const mapApply = (animate) => {
    const view = mapViewRef.current, world = mapWorldRef.current;
    if (!view || !world) return;
    const m = mapState.current;
    const vw = view.clientWidth, vh = view.clientHeight;
    const w = MAP_W * m.z, h = MAP_H * m.z;
    m.x = w <= vw ? (vw - w) / 2 : Math.min(0, Math.max(vw - w, m.x));
    m.y = h <= vh ? (vh - h) / 2 : Math.min(0, Math.max(vh - h, m.y));
    world.classList.toggle("anim", !!animate);
    world.style.transform = `translate(${m.x}px, ${m.y}px) scale(${m.z})`;
    const me = world.querySelector(".map-me");
    if (me) me.style.transform = `translate(-50%,-50%) scale(${1 / m.z})`;
  };
  const mapRecentre = () => {
    const view = mapViewRef.current; if (!view) return;
    const m = mapState.current;
    m.z = 1; m.x = view.clientWidth / 2 - 380; m.y = view.clientHeight / 2 - 480;
    mapApply(true); renderPins();
  };
  /* Zoom about a point on screen, so a pinch keeps its centre still. */
  const mapZoomAt = (factor, px, py) => {
    const m = mapState.current;
    const cx = (px - m.x) / m.z, cy = (py - m.y) / m.z;
    m.z = Math.min(PIN_MAX_Z, Math.max(PIN_MIN_Z, m.z * factor));
    m.x = px - cx * m.z; m.y = py - cy * m.z;
    mapApply(); renderPins();
  };
  /* Tapping a cluster zooms far enough in that its members come apart. */
  const clusterZoom = (items) => {
    let minD = Infinity;
    for (let i = 0; i < items.length; i++)
      for (let j = i + 1; j < items.length; j++)
        minD = Math.min(minD, Math.hypot(items[i].x - items[j].x, items[i].y - items[j].y));
    const m = mapState.current;
    const needed = isFinite(minD) && minD > 0 ? (CLUSTER_R + 8) / minD : m.z * 1.8;
    return Math.min(PIN_MAX_Z, Math.max(m.z * 1.35, needed));
  };
  const mapFocus = (c) => {
    const view = mapViewRef.current; if (!view) return;
    const m = mapState.current;
    m.z = clusterZoom(c.items);
    m.x = view.clientWidth / 2 - c.x * m.z;
    m.y = view.clientHeight / 2 - c.y * m.z;
    mapApply(true); renderPins();
  };
  useEffect(() => {
    if (V.screen !== "main" || V.tab !== "map") return;
    const view = mapViewRef.current; if (!view) return;
    const m = mapState.current;
    if (!m.ready) { mapRecentre(); m.ready = true; } else { mapApply(); renderPins(); }
    let drag = null, pinch = null;
    const local = (t) => { const b = view.getBoundingClientRect(); return [t.clientX - b.left, t.clientY - b.top]; };
    const spread = (ts) => Math.hypot(ts[0].clientX - ts[1].clientX, ts[0].clientY - ts[1].clientY);
    const start = (e) => {
      if (e.touches && e.touches.length === 2) {
        const [mx, my] = local({ clientX: (e.touches[0].clientX + e.touches[1].clientX) / 2,
                                 clientY: (e.touches[0].clientY + e.touches[1].clientY) / 2 });
        pinch = { d: spread(e.touches), mx, my }; drag = null; return;
      }
      const t = e.touches ? e.touches[0] : e;
      drag = { sx: t.clientX, sy: t.clientY, ox: m.x, oy: m.y, moved: false };
      view.classList.add("grabbing");
      if (mapWorldRef.current) mapWorldRef.current.classList.remove("anim");
    };
    const move = (e) => {
      if (pinch && e.touches && e.touches.length === 2) {
        const d = spread(e.touches);
        if (pinch.d > 0) { mapZoomAt(d / pinch.d, pinch.mx, pinch.my); pinch.d = d; }
        if (e.cancelable) e.preventDefault();
        return;
      }
      if (!drag) return;
      const t = e.touches ? e.touches[0] : e;
      const dx = t.clientX - drag.sx, dy = t.clientY - drag.sy;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) drag.moved = true;
      m.x = drag.ox + dx; m.y = drag.oy + dy; mapApply();
      if (e.cancelable) e.preventDefault();
    };
    const end = (e) => {
      if (pinch) { pinch = null; drag = null; return; }
      if (!drag) return;
      view.classList.remove("grabbing");
      if (!drag.moved && e.target.closest) {
        const cluster = e.target.closest(".map-cluster");
        if (cluster) {
          const c = mapState.current.clusters[Number(cluster.dataset.cluster)];
          if (c) mapFocus(c);
          drag = null; return;
        }
        const pin = e.target.closest(".pin");
        if (pin) openLayer({ type: "drawer", id: pin.dataset.id });
      }
      drag = null;
    };
    view.addEventListener("mousedown", start);
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", end);
    view.addEventListener("touchstart", start, { passive: true });
    view.addEventListener("touchmove", move, { passive: false });
    view.addEventListener("touchend", end);
    const wheel = (e) => { const [mx, my] = local(e); mapZoomAt(e.deltaY < 0 ? 1.12 : 1 / 1.12, mx, my); if (e.cancelable) e.preventDefault(); };
    view.addEventListener("wheel", wheel, { passive: false });
    return () => {
      view.removeEventListener("mousedown", start);
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", end);
      view.removeEventListener("touchstart", start);
      view.removeEventListener("touchmove", move);
      view.removeEventListener("touchend", end);
      view.removeEventListener("wheel", wheel);
    };
  });

  function viewMap() {
    const f = V.mapFilters;
    const list = mapList();
    const filtered = f.gender !== "Any" || f.rating !== "Any";
    return (
      <div className="body flush" style={{ position: "relative", overflow: "hidden" }}>
        <div className="map-view" ref={mapViewRef}>
          <div className="map-world" ref={mapWorldRef}>
            <svg viewBox="0 0 760 960" preserveAspectRatio="none">
              <rect width="760" height="960" fill="#E9EDF4" />
              <g fill="#DCE6DD">
                <rect x="40" y="60" width="150" height="120" rx="14" />
                <rect x="480" y="240" width="210" height="160" rx="18" />
                <rect x="90" y="640" width="180" height="140" rx="16" />
                <rect x="560" y="740" width="150" height="170" rx="16" />
              </g>
              <g stroke="#FFFFFF" fill="none" strokeLinecap="round">
                <path d="M0 220 L760 260" strokeWidth="26" />
                <path d="M0 540 L760 500" strokeWidth="22" />
                <path d="M0 800 L760 830" strokeWidth="18" />
                <path d="M180 0 L240 960" strokeWidth="24" />
                <path d="M520 0 L470 960" strokeWidth="20" />
                <path d="M700 0 L720 960" strokeWidth="14" />
              </g>
              <g stroke="#F3F6FA" strokeWidth="8" fill="none">
                <path d="M0 380 L760 350" /><path d="M0 680 L760 700" />
                <path d="M340 0 L360 960" /><path d="M620 0 L600 960" />
              </g>
              <g fill="#E3EAF4">
                <rect x="250" y="60" width="120" height="90" rx="12" />
                <rect x="600" y="90" width="110" height="90" rx="12" />
                <rect x="60" y="330" width="90" height="120" rx="12" />
                <rect x="380" y="600" width="130" height="100" rx="12" />
                <rect x="270" y="380" width="120" height="90" rx="12" />
              </g>
              <g fill="#CFE0D2">
                <circle cx="410" cy="180" r="34" /><circle cx="150" cy="500" r="28" /><circle cx="660" cy="580" r="30" />
              </g>
            </svg>
            <div className="map-me" style={{ left: 380, top: 480 }} />
            <div ref={mapPinsRef} />
          </div>
        </div>
        <div className="map-filters">
          <button className={`gchip ${f.gender !== "Any" ? "on" : ""}`} onClick={() => openLayer({ type: "filter", which: "gender" })}>
            {f.gender === "Any" ? "Gender" : f.gender}<span className="gcaret">{Ico.down(11)}</span></button>
          <button className={`gchip ${f.rating !== "Any" ? "on" : ""}`} onClick={() => openLayer({ type: "filter", which: "rating" })}>
            {f.rating === "Any" ? "Rating" : f.rating}<span className="gcaret">{Ico.down(11)}</span></button>
          {filtered && (
            <button className="gchip clear" onClick={() => { setVK({ mapFilters: { gender: "Any", rating: "Any" } }); toast("All filters have been cleared."); }}>
              {Ico.close(12)} Clear</button>
          )}
        </div>
        <button className="map-locate" onClick={mapRecentre} aria-label="Recentre the map">{Ico.locate(15)}</button>
        <div className="map-count">{list.length} {SPORTS[V.activeSport].name} player{list.length === 1 ? "" : "s"} nearby</div>
        {!list.length && <div style={{ position: "absolute", left: 0, right: 0, top: "44%", textAlign: "center" }}><span className="chip">No players match these filters.</span></div>}
      </div>
    );
  }

  /* ================================================================
     MATCHES — individual sports
     ================================================================ */
  const PastCard = ({ m }) => {
    const o = P(m.opp);
    return (
      <div className="card" style={{ marginBottom: 10 }} onClick={() => openLayer({ type: "matchDetail", id: m.id })}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Avatar idx={o.av} size={42} />
          <div style={{ flex: 1, minWidth: 0 }}><div className="row-t">{m.won ? "Win against" : "Loss to"} {o.name}</div>
            <div className="tiny" style={{ marginTop: 2 }}>{m.mode} · {m.score}</div></div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: "var(--fs-h2)", fontWeight: 800, color: m.won ? "var(--accent)" : "var(--danger)" }}>
              {m.delta > 0 ? "+" + m.delta : m.delta < 0 ? m.delta : "Peer"}</div>
            <div className="tiny">{m.date}</div>
          </div>
        </div>
        <div className="divider" />
        <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <span className="tiny" style={{ display: "flex", alignItems: "center", gap: 5 }}>{Ico.pin(13)} {m.venue}</span>
          <span className="chip" style={{ marginLeft: "auto" }}>{m.source}</span>
        </div>
      </div>
    );
  };
  function viewMatches() {
    const t = V.matchTab, k = V.activeSport, past = sportPast();
    return (
      <div className="body fade-in">
        <div className="seg">
          {[["past", "Past"], ["upcoming", "Upcoming"]].map(([x, label]) => (
            <button key={x} className={t === x ? "on" : ""} onClick={() => setVK({ matchTab: x })}>{label}</button>
          ))}
        </div>
        {t === "upcoming" ? (<>
          <WeekCalendar />
          <CalendarKey />
          <div style={{ height: 14 }} />
          <button className="btn btn-dark" onClick={() => openChallenge()}>{Ico.plus(17)} Add a Challenge</button>
        </>) : (
          past.length ? (<>
            <div className="tiny" style={{ margin: "0 2px 12px" }}>This log combines scheduled matches and manually uploaded scores.</div>
            {past.map((m) => <PastCard key={m.id} m={m} />)}
          </>) : <Empty icon={Ico.trophy(30)} title={`No past ${SPORTS[k].name} matches.`}
              body="Play a game and upload the score. Scheduled matches and manually logged games both appear here."
              action={<button className="btn btn-dark btn-sm" onClick={openScore}>Upload scores</button>} />
        )}
        <div style={{ height: 8 }} />
      </div>
    );
  }

  /* ================================================================
     CALENDAR — group sports
     ================================================================ */
  /* ================================================================
     THE WEEKLY CALENDAR — shared by every sport
     Every booking you have is drawn, whatever the sport, so you can see
     your week. Only the sport you are in keeps its full colour; the rest
     fade back. Tentative proposals are striped, the way an unanswered
     Outlook invitation is.
     ================================================================ */
  const WeekCalendar = () => {
    const k = V.activeSport;
    const days = weekDays(V.weekOffset);
    const items = calendarItems();
    const monthLabel = days[0].getMonth() === days[6].getMonth()
      ? `${MONTHS[days[0].getMonth()]} ${days[0].getFullYear()}`
      : `${MON_SHORT[days[0].getMonth()]} – ${MON_SHORT[days[6].getMonth()]} ${days[6].getFullYear()}`;
    const nowTop = V.weekOffset === 0 ? ((19 * 60 - CAL_START * 60) / 60) * HOUR_H : null;
    return (<>
      <div className="cal-head">
        <div className="cal-title">{monthLabel}</div>
        <button className="cal-nav" onClick={() => setVK({ weekOffset: V.weekOffset - 1 })} aria-label="Previous week">{Ico.chevL(14)}</button>
        <button className="cal-nav" style={{ width: "auto", padding: "0 11px", fontSize: "var(--fs-caption)", fontWeight: 700 }} onClick={() => setVK({ weekOffset: 0 })} aria-label="This week">Today</button>
        <button className="cal-nav" onClick={() => setVK({ weekOffset: V.weekOffset + 1 })} aria-label="Next week">{Ico.chev(14)}</button>
      </div>
      <div className="cal-days">
        <div />
        {days.map((d) => (
          <div key={iso(d)} className={`cal-day ${iso(d) === iso(TODAY) ? "today" : ""}`}>
            <div className="dw">{DOW[(d.getDay() + 6) % 7][0]}</div>
            <div className="dn">{d.getDate()}</div>
          </div>
        ))}
      </div>
      <div className="cal-grid">
        <div className="cal-hours">
          {Array.from({ length: CAL_END - CAL_START }, (_, i) => {
            const h = CAL_START + i;
            return <div key={h} className="hr" style={{ top: i * HOUR_H }}>{h % 12 === 0 ? 12 : h % 12} {h < 12 ? "AM" : "PM"}</div>;
          })}
        </div>
        {days.map((d) => {
          const key = iso(d);
          /* Anything on the same day shares the column width. */
          const day = items.filter((e) => e.date === key).sort((a, b) => toMin(a.start) - toMin(b.start));
          return (
            <div key={key} className="cal-col">
              {Array.from({ length: CAL_END - CAL_START }, (_, i) => <div key={i} className="cal-line" style={{ top: i * HOUR_H }} />)}
              {day.map((e, i) => {
                const p = paletteOf(e.sport);
                const mine = e.sport === k, tent = e.status === "Tentative";
                const top = ((toMin(e.start) - CAL_START * 60) / 60) * HOUR_H;
                const h = Math.max(((toMin(e.end) - toMin(e.start)) / 60) * HOUR_H, 20);
                const w = 100 / day.length;
                const fill = tent
                  ? { background: p.soft, color: p.accent, border: `1.5px dashed ${p.accent}` }
                  : { background: p.accent, color: "#fff" };
                return (
                  <div key={e.key} className={`cal-ev ${mine ? "" : "dim"} ${tent ? "tent" : ""}`}
                    style={{ top, height: h, left: `${w * i}%`, width: `calc(${w}% - 2px)`, ...fill }}
                    onClick={(ev) => { ev.stopPropagation(); openLayer({ type: e.kind === "event" ? "eventDetail" : "challengeDetail", id: e.id }); }}>
                    {e.label}
                  </div>
                );
              })}
            </div>
          );
        })}
        {nowTop !== null && <div className="cal-now" style={{ top: nowTop }} />}
      </div>
    </>);
  };
  /* A short legend, because two visual rules are doing a lot of work. */
  const CalendarKey = () => {
    const k = V.activeSport, p = paletteOf(k);
    const others = activeSports.filter((s) => s !== k);
    return (
      <div className="cal-key">
        <span className="ck"><i style={{ background: p.accent }} />{SPORTS[k].name}, confirmed</span>
        <span className="ck"><i className="tent" style={{ background: p.soft, borderColor: p.accent }} />Awaiting a reply</span>
        {!!others.length && <span className="ck"><i className="dim" style={{ background: paletteOf(others[0]).accent }} />{others.map((s) => SPORTS[s].name).join(" and ")}</span>}
      </div>
    );
  };
  function viewCalendar() {
    const k = V.activeSport;
    const segments = (
      <div className="seg">
        <button className={V.calTab === "week" ? "on" : ""} onClick={() => setVK({ calTab: "week" })}>Week</button>
        <button className={V.calTab === "past" ? "on" : ""} onClick={() => setVK({ calTab: "past" })}>Past matches</button>
      </div>
    );
    if (V.calTab === "past") {
      const past = sportEvents().filter((e) => dateOf(e) < TODAY).sort((a, b) => b.date.localeCompare(a.date));
      return (
        <div className="body fade-in">
          {segments}
          {past.length ? past.map((e) => {
            const p = paletteOf(e.sport), r = e.result;
            return (
              <div key={e.id} className="card" style={{ marginBottom: 10 }} onClick={() => openLayer({ type: "eventDetail", id: e.id })}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 15, display: "grid", placeItems: "center", background: p.soft, flex: "0 0 auto" }}>
                    <SportIcon sport={e.sport} size={22} color={p.accent} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="row-t">{e.opponent}</div>
                    <div className="tiny" style={{ marginTop: 2 }}>{e.title} · {fmtDate(e)}</div>
                  </div>
                  {r ? <span className="chip" style={r.outcome === "Won" ? { background: "var(--accent-soft)", color: "var(--accent)" } : { background: "var(--danger-soft)", color: "var(--danger)" }}>{r.outcome}</span>
                     : <span className="chip" style={{ background: "#FDF3E9", color: "#D0762F" }}>Result needed</span>}
                </div>
                <div className="divider" />
                <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                  <span className="tiny" style={{ display: "flex", alignItems: "center", gap: 5 }}>{Ico.pin(13)} {e.venue}</span>
                  <span className="tiny" style={{ marginLeft: "auto" }}>{r ? r.score : "Tap to add the result"}</span>
                </div>
              </div>
            );
          }) : <Empty icon={Ico.calendar(30)} title={`No past ${SPORTS[k].name} matches.`}
                body="Fixtures move here once the date has passed, and you can add the result afterwards." />}
          <div style={{ height: 8 }} />
        </div>
      );
    }
    return (
      <div className="body fade-in">
        {segments}
        <WeekCalendar />
        <CalendarKey />
        <div style={{ height: 14 }} />
        <button className="btn btn-dark" onClick={openAddEvent}>{Ico.plus(17)} Add to calendar</button>
        <div className="tiny" style={{ textAlign: "center", marginTop: 10 }}>
          You and your squad both add fixtures here. There are no challenges or score uploads in {SPORTS[k].name}.
        </div>
        <div style={{ height: 8 }} />
      </div>
    );
  }

  /* ================================================================
     FRIENDS
     ================================================================ */
  const matchQuery = (p) => {
    const q = V.friendQuery.trim().toLowerCase();
    return !q || p.name.toLowerCase().includes(q) || p.username.toLowerCase().includes(q);
  };
  function viewChats() {
    const t = V.chatTab, nreq = sportMsgRequests().length;
    return (
      <div className="body fade-in">
        <div className="seg">
          <button className={t === "chats" ? "on" : ""} onClick={() => setVK({ chatTab: "chats" })}>Chats</button>
          <button className={t === "requests" ? "on" : ""} onClick={() => setVK({ chatTab: "requests" })}>Requests{nreq ? ` · ${nreq}` : ""}</button>
        </div>
        <div style={{ position: "relative", marginBottom: 14 }}>
          <span style={{ position: "absolute", left: 14, top: 13, color: "var(--ink-4)" }}>{Ico.search()}</span>
          <input className="input" style={{ paddingLeft: 40 }} placeholder="Search by name or username"
            value={V.friendQuery} onChange={(e) => setVK({ friendQuery: e.target.value })} />
        </div>
        {t === "chats" ? <ChatList /> : <RequestList />}
        <div style={{ height: 8 }} />
      </div>
    );
  }
  const ChatList = () => {
    const threads = sportThreads().filter((th) => matchQuery(P(th.with)));
    if (!threads.length) return <Empty icon={Ico.friends(30)} title={`No ${SPORTS[V.activeSport].name} conversations yet.`}
      body="Open a player on the map and tap Connect. Every connection starts with a message."
      action={<button className="btn btn-dark btn-sm" onClick={() => goTab("map")}>Find players nearby</button>} />;
    return threads.map((th) => {
      const p = P(th.with), last = th.msgs.length ? th.msgs[th.msgs.length - 1] : null;
      const preview = last ? (last.kind === "challenge"
        ? `Challenge · ${last.slots.length} time${last.slots.length === 1 ? "" : "s"} proposed`
        : `${last.me ? "You: " : ""}${last.tx}`) : "";
      return (
        <div key={th.id} className="row" style={{ cursor: "pointer" }} onClick={() => openChat(th.id)}>
          <span onClick={(e) => { e.stopPropagation(); openLayer({ type: "drawer", id: p.id }); }}><Avatar idx={p.av} size={46} /></span>
          <div className="row-main"><div className="row-t">{p.name}</div>
            <div className="row-s">{preview}</div>
            {th.pending && <div className="tiny" style={{ marginTop: 3 }}>Waiting on their first reply.</div>}</div>
          <div style={{ textAlign: "right", flex: "0 0 auto" }}>
            <div className="tiny">{last ? last.t : ""}</div>
            {!!th.unread && <div className="badge-n" style={{ marginTop: 5, marginLeft: "auto" }}>{th.unread}</div>}
          </div>
        </div>
      );
    });
  };
  const RequestList = () => {
    const reqs = sportMsgRequests().filter((r) => matchQuery(P(r.with)));
    if (!reqs.length) return <Empty icon={Ico.connect(30)} title="No pending requests."
      body={`When a ${SPORTS[V.activeSport].name} player messages you for the first time, it waits here.`} />;
    return (<>
      <div className="tiny" style={{ margin: "2px 2px 10px" }}>Accepting a request connects you and moves the conversation into your chats.</div>
      {reqs.map((r) => {
        const p = P(r.with);
        return (
          <div key={r.id} className="card" style={{ marginBottom: 11 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 11, cursor: "pointer" }} onClick={() => openLayer({ type: "drawer", id: p.id })}>
              <Avatar idx={p.av} size={44} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="name-line"><span className="row-t">{p.name}</span>
                  <span className="chip accent">{isIndividual(V.activeSport) ? (p.ratings[V.activeSport] || p.rating) : "Peer"}</span></div>
                <div className="tiny" style={{ marginTop: 2 }}>{p.username} · {agoLabel(r.hrs)}</div>
              </div>
            </div>
            <div className="sub" style={{ marginTop: 10 }}>{r.tx}</div>
            <div className="btn-row" style={{ marginTop: 12 }}>
              <button className="btn btn-ghost btn-sm" style={{ width: "100%" }} onClick={() => deleteMsgRequest(r.id)}>Delete</button>
              <button className="btn btn-dark btn-sm" style={{ width: "100%" }} onClick={() => acceptMsgRequest(r.id)}>Accept</button>
            </div>
          </div>
        );
      })}
    </>);
  };

  /* A challenge lives inside the conversation. The player who receives
     it sees every slot that was proposed and picks the one that suits. */
  const ChallengeBubble = ({ m, th }) => {
    const p = P(th.with), pal = paletteOf(m.sport);
    const done = m.chosen != null || m.declined;
    const head = m.me ? `You proposed ${m.slots.length} time${m.slots.length === 1 ? "" : "s"}`
                      : `${p.name} proposed ${m.slots.length} time${m.slots.length === 1 ? "" : "s"}`;
    return (
      <div className={`ch-card ${m.me ? "me" : ""}`}>
        <div className="ch-top"><span style={{ color: pal.accent }}><SportIcon sport={m.sport} size={15} color={pal.accent} /></span>
          <span className="ch-t">{head}</span></div>
        <div className="tiny" style={{ marginBottom: 9 }}>{SPORTS[m.sport].name} · {m.venue}</div>
        {m.slots.map((s, i) => {
          const picked = m.chosen === i;
          if (done) return <div key={i} className={`slot ${picked ? "picked" : ""}`}>{slotLabel(s)}{picked && <span className="slot-tick">{Ico.check(12, "currentColor")}</span>}</div>;
          if (m.me) return <div key={i} className="slot">{slotLabel(s)}</div>;
          return <button key={i} className="slot pick" onClick={() => pickSlot(th.id, m.cid, i)}>{slotLabel(s)}<span className="slot-go">{Ico.chev(13)}</span></button>;
        })}
        {m.declined ? <div className="tiny" style={{ marginTop: 8 }}>This challenge was declined.</div>
         : m.chosen != null ? <div className="tiny" style={{ marginTop: 8 }}>Confirmed and added to your calendar.</div>
         : m.me ? <div className="tiny" style={{ marginTop: 8 }}>Waiting for {p.name} to pick a time.</div>
         : <button className="btn btn-ghost btn-sm" style={{ width: "100%", marginTop: 9 }} onClick={() => declineSlots(th.id, m.cid)}>None of these work</button>}
        <div className="bub-t" style={{ textAlign: "right" }}>{m.t}</div>
      </div>
    );
  };
  function renderChat() {
    const th = S.threads.find((x) => x.id === V.chatWith);
    if (!th) return null;
    const p = P(th.with);
    const opener = !th.msgs.length || th.pending;
    const allow = canChallenge(th.with) && !groupMode;
    return (<>
      <div className="appbar">
        <button className="back" onClick={() => setVK({ screen: "main" })}>{Ico.back()}</button>
        <div style={{ display: "flex", alignItems: "center", gap: 10, flex: 1, marginLeft: 6, cursor: "pointer" }} onClick={() => openLayer({ type: "drawer", id: p.id })}>
          <Avatar idx={p.av} size={36} />
          <div><div style={{ fontSize: "var(--fs-title)", fontWeight: 700 }}>{p.name}</div><div className="tiny">{p.username}</div></div>
        </div>
        {allow && <button className="icon-btn" aria-label="Send a challenge" onClick={() => openChallenge(p.id)}>{Ico.trophy(17)}</button>}
      </div>
      <div className="chat-wrap">
        <div className="chat-body">
          {opener && (
            <div className="chat-note">{Ico.connect(16)}
              <div>You need to start a conversation and wait for their response before sending your first challenge to them.</div>
            </div>
          )}
          <div className="day-sep">Today</div>
          {th.msgs.map((m, i) => m.kind === "challenge"
            ? <ChallengeBubble key={i} m={m} th={th} />
            : <div key={i} className={`bub ${m.me ? "me" : "them"}`}>{m.tx}<div className="bub-t">{m.t}</div></div>)}
        </div>
        <div className="chat-input">
          <input className="input" placeholder="Write a message" value={msgBox}
            onChange={(e) => setMsgBox(e.target.value)} onKeyDown={(e) => e.key === "Enter" && sendMsg()} />
          <button onClick={sendMsg} style={{ width: 42, height: 42, borderRadius: "50%", display: "grid", placeItems: "center", background: "var(--accent)", flex: "0 0 auto" }}>{Ico.send(17)}</button>
        </div>
      </div>
    </>);
  }

  /* ================================================================
     PROFILE
     ================================================================ */
  function viewProfile() {
    const k = V.activeSport, ind = isIndividual(k), mine = myRating(k);
    const games = ind ? sportPast() : sportEvents().filter((e) => e.result);
    const wins = ind ? games.filter((m) => m.won).length : games.filter((e) => e.result.outcome === "Won").length;
    const skills = PEER_SKILLS[k] || [];
    const peer = (S.peer || {})[k] || null;
    let trendNode = null;
    if (ind && games.length) {
      const pts = [...games].filter((m) => m.after).reverse().map((m) => m.after);
      const series = pts.length ? pts : [80];
      const min = Math.min(...series) - 3, max = Math.max(...series) + 3, w = 300, h = 72;
      const path = series.map((v, i) => `${i === 0 ? "M" : "L"}${(i / Math.max(series.length - 1, 1)) * w},${h - ((v - min) / Math.max(max - min, 1)) * h}`).join(" ");
      trendNode = (<>
        <SecHead>Rating trend</SecHead>
        <div className="card">
          <svg style={{ width: "100%", height: 72 }} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
            <path d={`${path} L${w},${h} L0,${h} Z`} fill="var(--accent-soft)" />
            <path d={path} fill="none" stroke="var(--accent)" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
          </svg>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            <span className="tiny">Oldest logged match</span><span className="tiny">Most recent</span></div>
        </div>
        <SecHead>Recent results</SecHead>
        <div className="card">
          <div className="bars">{[...games].slice(0, 7).reverse().map((m) => (
            <div key={m.id} className={`b ${m.won ? "" : "loss"}`} style={{ height: `${m.won ? 62 + Math.abs(m.delta) * 7 : 34}%` }} />))}</div>
          <div className="divider" />
          <KV k="Longest winning streak" v="3 matches" />
          <KV k="Average match length" v="54 minutes" />
          <KV k="Favourite venue" v={VENUES[0]} />
        </div>
      </>);
    } else if (!ind && games.length) {
      trendNode = (<>
        <SecHead>Recent results</SecHead>
        <div className="card">
          <div className="bars">{[...games].slice(0, 7).reverse().map((e) => (
            <div key={e.id} className={`b ${e.result.outcome === "Won" ? "" : "loss"}`} style={{ height: `${e.result.outcome === "Won" ? 76 : 36}%` }} />))}</div>
          <div className="divider" />
          <KV k="Fixtures this season" v={sportEvents().length} />
          <KV k="Home ground" v={VENUES[4]} />
          <KV k="Squad" v="Riverside XI" />
        </div>
      </>);
    } else {
      trendNode = (<>
        <SecHead>Performance analytics</SecHead>
        <Empty icon={Ico.chart(30)} title="No statistics yet."
          body={`Your results and analytics appear once you have logged your first ${SPORTS[k].name} outing.`} />
      </>);
    }
    return (
      <div className="body fade-in">
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: "6px 0 16px" }}>
          <MyFace size={84} ring sport={V.activeSport} avIdx={S.me.av} />
          <div className="h2" style={{ marginTop: 12 }}>{S.me.name || "Your name"}</div>
          <div className="tiny" style={{ marginTop: 3 }}>{S.me.username || "@username"}{S.me.age ? ` · ${S.me.age}` : ""}{S.me.gender ? ` · ${S.me.gender}` : ""}</div>
          <div className="pill-row" style={{ justifyContent: "center", marginTop: 14 }}>
            {activeSports.map((s) => {
              const p = SPORTS[s], on = s === k;
              return (
                <button key={s} className={`pill ${on ? "on" : ""}`} onClick={() => switchSport(s)}
                  style={on ? { background: p.soft, borderColor: p.line, color: p.accent } : undefined}>
                  <span style={{ display: "inline-flex", verticalAlign: -2, marginRight: 5 }}><SportIcon sport={s} size={13} color={on ? p.accent : "var(--ink-3)"} /></span>{p.name}
                </button>
              );
            })}
          </div>
        </div>

        <div id="mp-analytics">
          {ind ? (
            <div className="card accent">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div>
                  <div className="tiny" style={{ fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase" }}>MP Rating</div>
                  <div style={{ fontSize: 40, fontWeight: 800, letterSpacing: "-1.4px", color: "var(--accent)", lineHeight: 1.1 }}>{mine == null ? "Unrated" : mine}</div>
                  <div className="tiny">{mine == null ? "You opted out of the rating system for this sport." : "Everyone starts at 80 and moves in small steps."}</div>
                </div>
                <div style={{ opacity: .6 }}><SportIcon sport={k} size={50} color={pal.mid} /></div>
              </div>
              <div className="divider" />
              <button className="link" onClick={() => openLayer({ type: "readmore", sport: k })}>How the MP Rating works</button>
            </div>
          ) : (
            <div className="card accent">
              <div className="tiny" style={{ fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 8 }}>Peer skill evaluation</div>
              {peer ? skills.map((s) => (
                <div key={s} style={{ padding: "7px 0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: "var(--fs-body)", fontWeight: 600 }}>{s}</span>
                    <span style={{ display: "flex", alignItems: "center", gap: 7 }}><Stars value={peer[s] || 0} /><b style={{ fontSize: "var(--fs-label)" }}>{(peer[s] || 0).toFixed(1)}</b></span>
                  </div>
                  <div className="meter"><i style={{ width: `${((peer[s] || 0) / 5) * 100}%` }} /></div>
                </div>
              )) : <div className="tiny" style={{ padding: "8px 0" }}>You have not received any peer evaluations yet. Play a fixture and your teammates will rate you across {skills.join(", ")}.</div>}
            </div>
          )}
        </div>

        <SecHead>{SPORTS[k].name} statistics</SecHead>
        <div className="stat-grid">
          <div className="stat"><b>{games.length}</b><span>{ind ? "Matches" : "Fixtures"}</span></div>
          <div className="stat"><b style={{ color: "var(--accent)" }}>{wins}</b><span>Wins</span></div>
          <div className="stat"><b>{games.length ? Math.round((wins / games.length) * 100) : 0}%</b><span>Win rate</span></div>
        </div>
        {trendNode}

        {!ind && !!S.connections.length && (<>
          <SecHead>Peer testimonials</SecHead>
          {[["p3", "Reads the game better than anyone I play with. Fair, punctual, and always up for one more over."],
            ["p7", "A tough competitor who keeps the mood light. Highly recommended for any weekend side."],
            ["p2", "Reliable in the field and a great attitude after a loss. Always a pleasure."]].map(([id, tx]) => {
            const p = P(id);
            return (
              <div key={id} className="card tight" style={{ marginBottom: 10 }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 8 }}>
                  <Avatar idx={p.av} size={32} />
                  <div style={{ flex: 1 }}><div className="row-t" style={{ fontSize: "var(--fs-label)" }}>{p.name}</div><Stars value={5} size={11} /></div>
                </div>
                <div className="sub" style={{ fontSize: "var(--fs-label)" }}>{tx}</div>
              </div>
            );
          })}
        </>)}

        <SecHead>Account configuration</SecHead>
        <div className="card" style={{ padding: "2px 16px" }}>
          {[["Edit profile details", "editProfile"], ["Manage your sports", "manageSports"], ["Privacy and visibility", "privacy"], ["Notification preferences", "notifs"]].map(([label, key]) => (
            <button key={key} style={{ width: "100%", display: "flex", alignItems: "center", gap: 11, padding: "14px 0", borderBottom: "1px solid var(--line)", textAlign: "left" }}
              onClick={() => openLayer({ type: key })}>
              <span style={{ color: "var(--ink-4)" }}>{Ico.settings()}</span>
              <span style={{ flex: 1, fontSize: "var(--fs-body)", fontWeight: 600 }}>{label}</span>
              <span style={{ color: "var(--ink-4)" }}>{Ico.chev()}</span>
            </button>
          ))}
          <button style={{ width: "100%", display: "flex", alignItems: "center", gap: 11, padding: "14px 0", textAlign: "left", color: "var(--danger)" }} onClick={restartOnboarding}>
            {Ico.block()}<span style={{ flex: 1, fontSize: "var(--fs-body)", fontWeight: 600 }}>Reset this account</span>
          </button>
        </div>
        <div style={{ height: 8 }} />
      </div>
    );
  }

  function renderVictory() {
    const v = V.lastVictory || { won: true, score: "2-0 games", before: 55, delta: 13, after: 68 };
    const cols = ALL_SPORTS.map((s) => SPORTS[s].mid);
    return (
      <div className="victory">
        <div className="confetti">
          {Array.from({ length: 24 }, (_, i) => (
            <i key={i} style={{ left: `${(i * 4.2) % 100}%`, background: cols[i % 6], animationDuration: `${2.4 + (i % 5) * .4}s`, animationDelay: `${(i % 9) * .22}s` }} />
          ))}
        </div>
        <div className="vk">{v.won ? "MATCH WON" : "MATCH LOST"}</div>
        <div className="vring" dangerouslySetInnerHTML={{ __html: personSVG(S.me.av, 116) }} />
        <div className="vt">{v.won ? "You brought it home." : "A tough one to lose."}</div>
        <div className="vs">{v.score} · loser buys tacos 🌮</div>
        <div style={{ height: 20 }} />
        <div className="rating-card">
          <div><small>BEFORE</small><b>{v.before}</b></div>
          <div><small>CHANGE</small><b style={{ color: v.delta >= 0 ? "var(--accent)" : "var(--danger)" }}>{v.delta >= 0 ? "+" : ""}{v.delta}</b></div>
          <div><small>NEW RATING</small><b style={{ color: "var(--accent)" }}>{v.after}</b></div>
        </div>
        <div style={{ height: 18 }} />
        <p className="sub" style={{ textAlign: "center", maxWidth: 270 }}>
          {v.won ? "Your recommendations now include slightly stronger nearby players." : "Your recommendations now include players closer to your current level."}</p>
        <div style={{ height: 22 }} />
        <button className="btn btn-dark" onClick={() => setVK({ screen: "main", tab: "home" })}>Back to home</button>
      </div>
    );
  }

  /* ================================================================
     OVERLAYS
     ================================================================ */
  const Sheet = ({ title, sub, children }) => (
    <div className="scrim" onClick={(e) => { if (e.target === e.currentTarget) closeLayer(); }}>
      <div className="sheet">
        <div className="sheet-head">
          <div className="sheet-grab" />
          <div className="sheet-head-row">
            <div style={{ minWidth: 0 }}><div className="h2">{title}</div>{sub && <div className="tiny" style={{ marginTop: 3 }}>{sub}</div>}</div>
            <button className="icon-btn" onClick={closeLayer} aria-label="Close">{Ico.close()}</button>
          </div>
        </div>
        <div className="sheet-body">{children}</div>
      </div>
    </div>
  );
  const Modal = ({ children }) => (
    <div className="scrim center" onClick={(e) => { if (e.target === e.currentTarget) closeLayer(); }}>
      <div className="modal">{children}</div>
    </div>
  );

  function renderLayer() {
    if (!V.layer) return null;
    const L = V.layer;

    if (L.type === "sportSwitcher") return (
      <div className="scrim" style={{ background: "rgba(21,24,33,.2)" }} onClick={closeLayer}>
        <div className="dropdown" onClick={(e) => e.stopPropagation()}>
          <div className="tiny" style={{ padding: "8px 11px 6px", fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase" }}>Your sports</div>
          {activeSports.map((k) => {
            const p = SPORTS[k], r = myRating(k), on = k === V.activeSport;
            return (
              <button key={k} className="dd-item" style={on ? { background: p.soft } : undefined} onClick={() => switchSport(k)}>
                <SportIcon sport={k} size={20} color={p.accent} />
                <span className="dd-nm" style={on ? { color: p.accent } : undefined}>{p.name}</span>
                <span className="dd-rt">{isIndividual(k) ? (r == null ? "Unrated" : r) : "Peer"}</span>
              </button>
            );
          })}
          <div style={{ height: 1, background: "var(--line)", margin: "5px 8px" }} />
          <button className="dd-item" onClick={() => openLayer({ type: "manageSports" })}>
            <span style={{ color: "var(--ink-4)" }}>{Ico.plus(18)}</span><span className="dd-nm">Manage your sports</span>
          </button>
        </div>
      </div>
    );

    if (L.type === "exitIntent") return (
      <Modal>
        <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
          {Ico.warn()}
          <div><div className="h2" style={{ marginBottom: 6 }}>You have unsaved changes.</div>
            <p className="sub">You are in the middle of {V.dirtyLabel ? `"${V.dirtyLabel.toLowerCase()}"` : "an unsaved edit"}. Switching the active sport now will discard everything you have entered. Save your changes first if you want to keep them.</p></div>
        </div>
        <div className="btn-row" style={{ marginTop: 20 }}>
          <button className="btn btn-ghost" onClick={closeLayer}>Keep editing</button>
          <button className="btn btn-danger" onClick={discardAndSwitch}>Discard and switch</button>
        </div>
      </Modal>
    );

    if (L.type === "readmore") {
      const k = L.sport, p = SPORTS[k];
      if (isIndividual(k)) return (
        <Sheet title="The MP Rating" sub="Everything the number means, in one place.">
          <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 14 }}>
            <SportIcon sport={k} size={28} color={p.accent} />
            <span className="chip" style={{ background: p.soft, color: p.accent }}>{p.name} · Rated</span>
          </div>
          {RATING_COPY.map((t, i) => <p key={i} className="sub" style={{ marginBottom: 12 }}>{t}</p>)}
          <SecHead>How points move</SecHead>
          <div className="card"><KV k="Even opponent" v="+1 to +2" /><KV k="Stronger opponent" v="+3" /><KV k="Significant upset" v="+4 to +5" /><KV k="Starting rating" v="80" /></div>
          <SecHead>Opting out</SecHead>
          {OPTOUT_COPY.map((t, i) => <p key={i} className="sub" style={{ marginBottom: 12 }}>{t}</p>)}
          <div style={{ height: 10 }} />
          <button className="btn btn-dark" onClick={closeLayer}>Got it</button>
        </Sheet>
      );
      const skills = PEER_SKILLS[k] || [];
      return (
        <Sheet title={`How ${p.name} works`} sub={`${p.name} runs on a calendar and peer reviews.`}>
          <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 14 }}>
            <SportIcon sport={k} size={28} color={p.accent} />
            <span className="chip" style={{ background: p.soft, color: p.accent }}>Group sport</span>
          </div>
          <p className="sub">{PEER_COPY[k]}</p>
          <SecHead>How fixtures work</SecHead>
          <p className="sub">Group sports do not use challenges or uploaded scores, because a squad of eleven cannot agree a ladder. Instead you and your teammates keep a shared calendar. Anyone can add a fixture with a title, a team, an opponent, a time, and a location. After the day has passed you are prompted to add the result.</p>
          <SecHead>Rated categories</SecHead>
          {skills.map((s) => (
            <div key={s} className="card tight" style={{ marginBottom: 9, display: "flex", alignItems: "center", gap: 11 }}>
              <Stars value={0} /><div style={{ flex: 1 }} className="h3">{s}</div></div>
          ))}
          <div className="card" style={{ marginTop: 10 }}><KV k="Scale" v="1 to 5 stars" /><KV k="Minimum submissions" v="3 teammates" /><KV k="Shown on profile" v="Rolling average" /></div>
          <div style={{ height: 10 }} />
          <button className="btn btn-dark" onClick={closeLayer}>Got it</button>
        </Sheet>
      );
    }

    if (L.type === "challenge" && chDraft) {
      const pool = sportConnections().filter(canChallenge).map(P);
      const dates = challengeDates();
      const set = (k, v) => { setChDraft((d) => ({ ...d, [k]: v })); markDirty("Creating a challenge"); };
      if (!pool.length) return (
        <Sheet title={`Challenge a ${SPORTS[V.activeSport].name} player`} sub="Connections only.">
          <Empty icon={Ico.connect(28)} title="No one to challenge yet."
            body="Challenges only go to people you are connected with. Find a player on the map, tap Connect, and start a conversation."
            action={<button className="btn btn-dark btn-sm" onClick={() => { closeLayer(); goTab("map"); }}>Open the map</button>} />
        </Sheet>
      );
      return (
        <Sheet title={`Challenge a ${SPORTS[V.activeSport].name} player`} sub="Offer up to three slots and let them pick.">
          <div className="field"><label>Opponent</label>
            <Select value={chDraft.opp} onChange={(v) => set("opp", v)} options={pool.map((p) => ({ v: p.id, l: `${p.name} · ${p.ratings[V.activeSport] || p.rating}` }))} />
            <div className="hint">You can only challenge people you are already connected with.</div>
          </div>
          <div className="field"><label>Venue</label><Select value={chDraft.venue} onChange={(v) => set("venue", v)} options={VENUES} /></div>
          <div className="field">
            <label>Times you can play</label>
            {chDraft.slots.map((s, i) => (
              <div key={i} className="slot-row">
                <div className="slot-n">{i + 1}</div>
                <Select value={s.date} onChange={(v) => chSlot(i, "date", v)} options={dates.map((x) => ({ v: x, l: fmtDate({ date: x }) }))} />
                <Select value={s.start} onChange={(v) => chSlot(i, "start", v)} options={SLOT_TIMES.map((x) => ({ v: x, l: fmtTime(x) }))} />
                {chDraft.slots.length > 1
                  ? <button className="slot-x" aria-label="Remove this time" onClick={() => chRemoveSlot(i)}>{Ico.close(13)}</button>
                  : <span style={{ width: 26 }} />}
              </div>
            ))}
            {chDraft.slots.length < MAX_SLOTS
              ? <button className="btn btn-outline btn-sm" style={{ width: "100%", marginTop: 8 }} onClick={chAddSlot}>{Ico.plus(15)} Offer another time</button>
              : <div className="hint">Three is the maximum. Give them a real choice, not a calendar.</div>}
          </div>
          <button className="btn btn-dark" onClick={submitChallenge}>Send {chDraft.slots.length} time{chDraft.slots.length === 1 ? "" : "s"}</button>
          <div style={{ height: 10 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Cancel</button>
        </Sheet>
      );
    }

    if (L.type === "verifyDetail") {
      const v = S.verifications.find((x) => x.id === L.id);
      if (!v) return (<Sheet title="Verification"><div className="tiny">This score has already been dealt with.</div>
        <div style={{ height: 14 }} /><button className="btn btn-ghost" onClick={closeLayer}>Close</button></Sheet>);
      const o = P(v.from), mine = myRating(v.sport);
      return (
        <Sheet title="Verify this score" sub="Confirming updates both rating histories.">
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <Avatar idx={o.av} size={48} />
            <div style={{ flex: 1, minWidth: 0 }}><div className="row-t">{o.name}</div>
              <div className="tiny" style={{ marginTop: 2 }}>{o.username} · uploaded {v.date}</div></div>
          </div>
          <div className="card">
            <KV k="Sport" v={SPORTS[v.sport].name} /><KV k="Format" v={v.mode} />
            {v.partner && <KV k="Your teammate" v={P(v.partner).name} />}
            <KV k="Result" v={v.score} /><KV k="Venue" v={v.venue} />
          </div>
          <SecHead>Game by game</SecHead>
          <div className="card">{v.games.map((g, i) => (
            <div key={i} className="kv"><span>Game {i + 1}</span><b style={{ color: g ? "var(--accent)" : "var(--danger)" }}>{g ? "You won" : "You lost"}</b></div>))}</div>
          <SecHead>If you confirm</SecHead>
          <div className="rating-card">
            <div><small>BEFORE</small><b>{mine == null ? "—" : mine}</b></div>
            <div><small>CHANGE</small><b style={{ color: v.delta >= 0 ? "var(--accent)" : "var(--danger)" }}>{v.delta >= 0 ? "+" : ""}{v.delta}</b></div>
            <div><small>NEW RATING</small><b style={{ color: "var(--accent)" }}>{mine == null ? "—" : mine + v.delta}</b></div>
          </div>
          <div style={{ height: 16 }} />
          <div className="btn-row">
            <button className="btn btn-ghost" onClick={() => resolveVerification(v.id, false)}>Dispute</button>
            <button className="btn btn-dark" onClick={() => resolveVerification(v.id, true)}>Confirm</button>
          </div>
        </Sheet>
      );
    }

    /* Someone has written to you for the first time. */
    if (L.type === "connectReqDetail") {
      const r = S.msgRequests.find((x) => x.id === L.id);
      if (!r) return (<Sheet title="Connection request"><div className="tiny">This request has already been dealt with.</div>
        <div style={{ height: 14 }} /><button className="btn btn-ghost" onClick={closeLayer}>Close</button></Sheet>);
      const p = P(r.with), k = V.activeSport;
      const others = p.sports.filter((s) => s !== k).map((s) => SPORTS[s].name);
      return (
        <Sheet title="Connection request" sub="Accepting connects you and opens the conversation.">
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <Avatar idx={p.av} size={52} />
            <div style={{ flex: 1, minWidth: 0 }}><div className="row-t">{p.name}</div>
              <div className="tiny" style={{ marginTop: 2 }}>{p.username} · {agoLabel(r.hrs)}</div></div>
            <span className="chip accent">{isIndividual(k) ? (p.ratings[k] || p.rating) : "Peer"}</span>
          </div>
          <div className="card tight" style={{ marginBottom: 12 }}><div className="sub">{r.tx}</div></div>
          <p className="sub">{p.bio}</p>
          <div className="card" style={{ marginTop: 14 }}>
            <KV k="Sport" v={SPORTS[k].name} />
            <KV k="Distance" v={`${p.dist} miles away`} />
            <KV k="Age" v={p.age} />
          </div>
          {!!others.length && <div className="tiny" style={{ marginTop: 12 }}>They also play {others.join(" and ")}.</div>}
          <div style={{ height: 16 }} />
          <div className="btn-row">
            <button className="btn btn-ghost" onClick={() => { deleteMsgRequest(r.id); closeLayer(); }}>Delete</button>
            <button className="btn btn-dark" onClick={() => { acceptMsgRequest(r.id); closeLayer(); }}>Accept</button>
          </div>
        </Sheet>
      );
    }

    if (L.type === "challengeDetail") {
      const c = S.upcoming.find((x) => x.id === L.id);
      if (!c) return null;
      const o = P(c.opp), tent = c.status === "Tentative", th = threadWith(c.opp);
      return (
        <Sheet title="Challenge details">
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <Avatar idx={o.av} size={50} />
            <div style={{ flex: 1 }}><div className="h3">{o.name}</div>
              <div className="tiny" style={{ marginTop: 2 }}>{o.username} · {o.dist} miles away</div></div>
            <span className={`chip ${tent ? "" : "accent"}`}>{c.status}</span>
          </div>
          {tent ? (<>
            <div className="tiny" style={{ marginBottom: 10 }}>{SPORTS[c.sport].name} · {c.venue}</div>
            <div className="tiny" style={{ marginBottom: 6 }}>{c.from === "me" ? "You proposed" : `${o.name} proposed`} {c.slots.length} time{c.slots.length === 1 ? "" : "s"}.</div>
            {c.slots.map((s, i) => <div key={i} className="slot">{slotLabel(s)}</div>)}
          </>) : (
            <div className="card">
              <KV k="Sport" v={SPORTS[c.sport].name} />
              <KV k="Date" v={fmtDate(c)} />
              <KV k="Time" v={`${fmtTime(c.start)} – ${fmtTime(c.end)}`} />
              <KV k="Venue" v={c.venue} />
            </div>
          )}
          <div style={{ height: 14 }} />
          <div className="btn-row">
            {th && <button className="btn btn-ghost" onClick={() => { closeLayer(); openChat(th.id); }}>Open the chat</button>}
            {tent
              ? <button className="btn btn-danger" onClick={() => { removeChallenge(c.id); closeLayer(); }}>Withdraw</button>
              : <button className="btn btn-dark" onClick={() => { closeLayer(); openScore(); }}>Upload scores</button>}
          </div>
        </Sheet>
      );
    }

    if (L.type === "score" && scDraft) {
      const pool = sportConnections().length ? sportConnections().map(P) : ALL_PLAYERS.filter((x) => x.sports.includes(V.activeSport)).slice(0, 14);
      const opts = pool.map((p) => ({ v: p.id, l: p.name }));
      const set = (k, v) => { setScDraft((d) => { const n = { ...d, [k]: v }; if (k === "count") { const r = [...d.results]; while (r.length < v) r.push(1); n.results = r; } return n; }); markDirty("Entering scores"); };
      const myWins = scDraft.results.slice(0, scDraft.count).filter((x) => x === 1).length;
      const theirWins = scDraft.count - myWins;
      return (
        <Sheet title={`Upload ${SPORTS[V.activeSport].name} scores`} sub="Singles and doubles sessions are both supported.">
          <div className="field"><label>Format</label>
            <div className="pill-row">{["Singles", "Doubles"].map((m) => <button key={m} className={`pill ${scDraft.mode === m ? "on" : ""}`} onClick={() => set("mode", m)}>{m}</button>)}</div></div>
          {scDraft.mode === "Doubles" ? (<>
            <div className="field"><label>Your teammate</label><Select value={scDraft.partner} onChange={(v) => set("partner", v)} options={opts} /></div>
            <div className="field"><label>Opponent one</label><Select value={scDraft.opp1} onChange={(v) => set("opp1", v)} options={opts} /></div>
            <div className="field"><label>Opponent two</label><Select value={scDraft.opp2} onChange={(v) => set("opp2", v)} options={opts} /></div>
          </>) : <div className="field"><label>Opponent</label><Select value={scDraft.opp1} onChange={(v) => set("opp1", v)} options={opts} /></div>}
          <div className="field"><label>Games played in this session</label>
            <div className="pill-row">{[1,2,3,4,5,6,7].map((n) => <button key={n} className={`pill ${scDraft.count === n ? "on" : ""}`} onClick={() => set("count", n)}>{n}</button>)}</div>
            <div className="hint">Record every individual game you played during the outing.</div></div>
          <div className="field"><label>Mark the winning side for each game</label>
            {Array.from({ length: scDraft.count }, (_, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 8 }}>
                <span className="tiny" style={{ width: 56, fontWeight: 700 }}>Game {i + 1}</span>
                <button className={`pill ${scDraft.results[i] === 1 ? "on" : ""}`} style={{ flex: 1 }}
                  onClick={() => { setScDraft((d) => { const r = [...d.results]; r[i] = 1; return { ...d, results: r }; }); markDirty("Entering scores"); }}>
                  {scDraft.mode === "Doubles" ? "Our team" : "You"}</button>
                <button className={`pill ${scDraft.results[i] === 0 ? "on" : ""}`} style={{ flex: 1 }}
                  onClick={() => { setScDraft((d) => { const r = [...d.results]; r[i] = 0; return { ...d, results: r }; }); markDirty("Entering scores"); }}>
                  {scDraft.mode === "Doubles" ? "Their team" : "Opponent"}</button>
              </div>
            ))}</div>
          <div className="field"><label>Venue</label><Select value={scDraft.venue} onChange={(v) => set("venue", v)} options={VENUES} /></div>
          <div className="card tight" style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 14 }}>
            <div style={{ flex: 1 }}><div className="h3">Session result</div>
              <div className="tiny" style={{ marginTop: 2 }}>{myWins}-{theirWins} games · {myWins > theirWins ? "You won the session." : myWins === theirWins ? "The session is level." : "Your opponent won the session."}</div></div>
            <span className="chip accent">{myWins}-{theirWins}</span>
          </div>
          <button className="btn btn-dark" onClick={submitScore}>Submit for verification</button>
          <div style={{ height: 10 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Cancel</button>
        </Sheet>
      );
    }

    if (L.type === "matchDetail") {
      const m = S.past.find((x) => x.id === L.id); if (!m) return null;
      const o = P(m.opp);
      return (
        <Sheet title="Match breakdown">
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <Avatar idx={o.av} size={50} />
            <div style={{ flex: 1 }}><div className="h3">{m.won ? "Win against" : "Loss to"} {o.name}</div>
              <div className="tiny" style={{ marginTop: 2 }}>{m.date} · {m.venue}</div></div>
            <div style={{ fontSize: "var(--fs-h1)", fontWeight: 800, color: m.won ? "var(--accent)" : "var(--danger)" }}>{m.delta > 0 ? "+" + m.delta : m.delta < 0 ? m.delta : "—"}</div>
          </div>
          <div className="card">
            <KV k="Sport" v={SPORTS[m.sport].name} /><KV k="Format" v={m.mode} />
            {m.partner && <KV k="Your teammate" v={P(m.partner).name} />}
            <KV k="Result" v={m.score} /><KV k="Duration" v={m.duration} /><KV k="Source" v={m.source} />
          </div>
          <SecHead>Game by game</SecHead>
          <div className="card">
            {m.games.length ? m.games.map((g, i) => (
              <div key={i} className="kv"><span>Game {i + 1}</span><b style={{ color: g ? "var(--accent)" : "var(--danger)" }}>{g ? "Won" : "Lost"}</b></div>
            )) : <div className="tiny">No individual games were recorded for this match.</div>}
          </div>
          {!!m.before && (<>
            <SecHead>Rating adjustment</SecHead>
            <div className="rating-card">
              <div><small>BEFORE</small><b>{m.before}</b></div>
              <div><small>CHANGE</small><b style={{ color: m.delta >= 0 ? "var(--accent)" : "var(--danger)" }}>{m.delta >= 0 ? "+" : ""}{m.delta}</b></div>
              <div><small>NEW RATING</small><b style={{ color: "var(--accent)" }}>{m.after}</b></div>
            </div>
          </>)}
          <div style={{ height: 18 }} />
          <div style={{ textAlign: "center" }}>
            <button className="link" onClick={() => {
              setVK({ layer: null, tab: "profile", screen: "main" });
              toast("Opened your personal performance statistics.");
              setTimeout(() => { const el = document.getElementById("mp-analytics"); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }, 140);
            }}>View personal performance statistics</button>
          </div>
          <div style={{ height: 18 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Close</button>
        </Sheet>
      );
    }

    /* ---- Calendar layers ---- */
    if (L.type === "addEvent" && evDraft) {
      const ok = evDraft.title.trim() && evDraft.team.trim() && evDraft.opponent.trim();
      const set = (k, v) => { setEvDraft((d) => ({ ...d, [k]: v })); markDirty("Adding a fixture"); };
      const dayOpts = Array.from({ length: 28 }, (_, i) => { const d = new Date(TODAY); d.setDate(d.getDate() + i - 7); return d; })
        .map((d) => ({ v: iso(d), l: `${DOW[(d.getDay() + 6) % 7]}, ${MON_SHORT[d.getMonth()]} ${d.getDate()}` }));
      return (
        <Sheet title="Add to calendar" sub={`A ${SPORTS[V.activeSport].name} fixture for your squad.`}>
          <div className="field"><label>Title <span className="req">*</span></label>
            <input className="input" placeholder="League fixture" value={evDraft.title} onChange={(e) => set("title", e.target.value)} /></div>
          <div className="field"><label>Your team <span className="req">*</span></label>
            <input className="input" placeholder="Riverside XI" value={evDraft.team} onChange={(e) => set("team", e.target.value)} /></div>
          <div className="field"><label>Opponent <span className="req">*</span></label>
            <input className="input" placeholder="Cedar Street CC" value={evDraft.opponent} onChange={(e) => set("opponent", e.target.value)} /></div>
          <div className="field"><label>Date</label><Select value={evDraft.date} onChange={(v) => set("date", v)} options={dayOpts} /></div>
          <div className="grid2">
            <div className="field"><label>Starts</label>
              <Select value={evDraft.start} onChange={(v) => set("start", v)} options={CAL_TIMES.map((t) => ({ v: t, l: fmtTime(t) }))} /></div>
            <div className="field"><label>Ends</label>
              <Select value={evDraft.end} onChange={(v) => set("end", v)} options={CAL_TIMES.map((t) => ({ v: t, l: fmtTime(t) }))} /></div>
          </div>
          <div className="field"><label>Location</label><Select value={evDraft.venue} onChange={(v) => set("venue", v)} options={VENUES} /></div>
          <div className="tiny" style={{ marginBottom: 14 }}>Everyone in your squad sees this fixture. After the date has passed you will be prompted to add the result.</div>
          <button className="btn btn-dark" disabled={!ok} onClick={submitEvent}>Add to calendar</button>
          <div style={{ height: 10 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Cancel</button>
        </Sheet>
      );
    }

    if (L.type === "eventDetail") {
      const e = S.calendar.find((x) => x.id === L.id); if (!e) return null;
      const p = SPORTS[e.sport], past = dateOf(e) < TODAY;
      return (
        <Sheet title={e.opponent} sub={`${fmtDate(e)} · ${fmtTime(e.start)}`}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <div style={{ width: 52, height: 52, borderRadius: 17, display: "grid", placeItems: "center", background: p.soft, flex: "0 0 auto" }}>
              <SportIcon sport={e.sport} size={26} color={p.accent} /></div>
            <div style={{ flex: 1 }}><div className="h3">{e.title}</div><div className="tiny" style={{ marginTop: 2 }}>{e.team} versus {e.opponent}</div></div>
            {e.result && <span className="chip" style={e.result.outcome === "Won" ? { background: "var(--accent-soft)", color: "var(--accent)" } : { background: "var(--danger-soft)", color: "var(--danger)" }}>{e.result.outcome}</span>}
          </div>
          <div className="card">
            <KV k="Sport" v={p.name} /><KV k="Date" v={fmtDate(e)} />
            <KV k="Time" v={`${fmtTime(e.start)} – ${fmtTime(e.end)}`} /><KV k="Location" v={e.venue} />
            {e.result && <KV k="Result" v={e.result.score} />}
          </div>
          <div style={{ height: 16 }} />
          {past && !e.result && (<>
            <button className="btn btn-dark" onClick={() => { setResDraft({ outcome: "Won", score: "" }); openLayer({ type: "addResult", id: e.id }); }}>Add the result</button>
            <div style={{ height: 10 }} /></>)}
          {past && (<>
            <button className="btn btn-outline" onClick={() => { setRevDraft({ who: S.connections[0] || ALL_PLAYERS[0].id, scores: Object.fromEntries((PEER_SKILLS[V.activeSport] || []).map((s) => [s, 4])) }); openLayer({ type: "review" }); }}>Submit a review</button>
            <div style={{ height: 10 }} /></>)}
          <button className="btn btn-ghost" onClick={() => removeEvent(e.id)}>Remove from calendar</button>
          <div style={{ height: 10 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Close</button>
        </Sheet>
      );
    }

    if (L.type === "addResult" && resDraft) {
      const e = S.calendar.find((x) => x.id === L.id); if (!e) return null;
      return (
        <Sheet title="Add the result" sub="Only you and your squad can see this.">
          <div className="card tight" style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 16 }}>
            <SportIcon sport={e.sport} size={24} color={SPORTS[e.sport].accent} />
            <div style={{ flex: 1 }}><div className="row-t">{e.team} versus {e.opponent}</div>
              <div className="tiny" style={{ marginTop: 2 }}>{fmtDate(e)} · {e.venue}</div></div>
          </div>
          <div className="field"><label>Outcome</label>
            <div className="pill-row">{["Won", "Lost", "Drawn"].map((o) => (
              <button key={o} className={`pill ${resDraft.outcome === o ? "on" : ""}`} onClick={() => { setResDraft((d) => ({ ...d, outcome: o })); markDirty("Adding a result"); }}>{o}</button>
            ))}</div></div>
          <div className="field"><label>Summary</label>
            <input className="input" placeholder="Won by 24 runs" value={resDraft.score} onChange={(ev) => { const v = ev.target.value; setResDraft((d) => ({ ...d, score: v })); markDirty("Adding a result"); }} />
            <div className="hint">Write the result the way your squad would say it out loud.</div></div>
          <button className="btn btn-dark" onClick={() => submitResult(e.id)}>Save the result</button>
          <div style={{ height: 10 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Cancel</button>
        </Sheet>
      );
    }

    if (L.type === "review" && revDraft) {
      const skills = PEER_SKILLS[V.activeSport] || [];
      const pool = S.connections.length ? S.connections.map(P) : ALL_PLAYERS.slice(0, 14);
      return (
        <Sheet title="Submit a review" sub={`Rate a ${SPORTS[V.activeSport].name} performance.`}>
          <div className="field"><label>Teammate or opponent</label>
            <Select value={revDraft.who} onChange={(v) => { setRevDraft((d) => ({ ...d, who: v })); markDirty("Submitting a review"); }} options={pool.map((p) => ({ v: p.id, l: p.name }))} /></div>
          {skills.map((s) => (
            <div key={s} className="field">
              <label>{s}</label>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                {[1,2,3,4,5].map((n) => (
                  <button key={n} style={{ padding: 2 }} onClick={() => { setRevDraft((d) => ({ ...d, scores: { ...d.scores, [s]: n } })); markDirty("Submitting a review"); }}>
                    {n <= revDraft.scores[s] ? Ico.star(28, "var(--accent-mid)") : Ico.starO(28)}</button>
                ))}
                <span className="tiny" style={{ marginLeft: "auto", fontWeight: 700 }}>{revDraft.scores[s]}.0</span>
              </div>
            </div>
          ))}
          <div className="tiny" style={{ marginBottom: 16 }}>Reviews stay anonymous. A rating only appears on someone's profile once at least three teammates have submitted one.</div>
          <button className="btn btn-dark" onClick={submitReview}>Submit review</button>
          <div style={{ height: 10 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Cancel</button>
        </Sheet>
      );
    }

    if (L.type === "drawer") {
      const p = P(L.id);
      const linked = isConnected(p.id);
      const thread = threadWith(p.id);
      const waiting = !!thread && thread.pending;
      return (
        <div className="scrim" onClick={(e) => { if (e.target === e.currentTarget) closeLayer(); }}>
          <div className="sheet">
            <div className="sheet-head">
              <div className="sheet-grab" />
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <Avatar idx={p.av} size={54} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="h2" style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</div>
                  <div className="tiny" style={{ marginTop: 2 }}>{p.username} · {p.dist} miles away</div>
                </div>
                <button className="icon-btn" onClick={closeLayer} aria-label="Close">{Ico.close()}</button>
              </div>
            </div>
            <div className="sheet-body">
              <div className="card" style={{ marginBottom: 11 }}>
                <div className="tiny" style={{ fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 6 }}>About</div>
                <div className="sub">{p.bio}</div>
                <div className="divider" />
                <KV k="Age" v={p.age} /><KV k="Gender" v={p.gender} />
              </div>
              <div className="card" style={{ marginBottom: 11 }}>
                <div className="tiny" style={{ fontWeight: 800, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 2 }}>Sport skill ratings</div>
                {(() => { const q = SPORTS[V.activeSport]; return (
                  <div className="kv">
                    <span style={{ display: "flex", alignItems: "center", gap: 8, color: q.accent }}><SportIcon sport={V.activeSport} size={15} color={q.accent} /> {q.name}</span>
                    <b>{isIndividual(V.activeSport) ? p.ratings[V.activeSport] || p.rating : "Peer rated"}</b>
                  </div>); })()}
                {(() => { const others = p.sports.filter((s) => s !== V.activeSport).map((s) => SPORTS[s].name);
                  return others.length ? <div className="tiny" style={{ marginTop: 8 }}>They also play {others.join(" and ")}.</div> : null; })()}
              </div>
              <button className="card" style={{ width: "100%", marginBottom: 11, display: "flex", alignItems: "center", gap: 11, textAlign: "left" }}
                onClick={() => toast("Shared media is simulated in this prototype.")}>
                <span style={{ color: "var(--ink-4)" }}>{Ico.media()}</span>
                <span style={{ flex: 1, fontSize: "var(--fs-body)", fontWeight: 600 }}>Media, links, and documents</span>
                <span className="tiny">12</span><span style={{ color: "var(--ink-4)" }}>{Ico.chev()}</span>
              </button>
              <div className="card" style={{ marginBottom: 11 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 10 }}>
                  <span style={{ color: "var(--ink-4)" }}>{Ico.users()}</span>
                  <span style={{ flex: 1, fontSize: "var(--fs-body)", fontWeight: 600 }}>{p.mutual} connections in common</span>
                </div>
                <div className="av-stack">{S.connections.slice(0, 6).map((id) => <Avatar key={id} idx={P(id).av} size={32} />)}</div>
              </div>
              {/* One action. Connect opens the conversation, and everything
                  else in the app follows from there. */}
              <button className="btn btn-dark" style={{ width: "100%" }}
                onClick={() => (thread ? (closeLayer(), openChat(thread.id)) : connectWith(p.id))}>
                {Ico.connect(17, "#fff")} {linked ? "Open the chat" : waiting ? "Awaiting their reply" : "Connect"}
              </button>
              <div style={{ height: 10 }} />
              <div className="card" style={{ padding: "2px 16px" }}>
                <button style={{ width: "100%", textAlign: "left", padding: "14px 0", fontSize: "var(--fs-body)", fontWeight: 600, color: "var(--danger)", display: "flex", gap: 10, alignItems: "center" }}
                  onClick={() => toast(`${p.name} has been blocked in this simulation.`)}>{Ico.block()} Block {p.name}</button>
              </div>
              <div style={{ height: 12 }} />
            </div>
          </div>
        </div>
      );
    }

    if (L.type === "filter") {
      const opts = L.which === "gender" ? ["Any", "Male", "Female", "Non-binary"] : ["Any", "Under 80", "80 to 110", "Above 110"];
      const cur = V.mapFilters[L.which];
      return (
        <Sheet title={L.which === "gender" ? "Filter by gender" : "Filter by rating"}>
          {opts.map((o) => (
            <button key={o} className="dd-item" style={{ width: "100%", ...(o === cur ? { background: "var(--accent-soft)" } : {}) }}
              onClick={() => setVK({ mapFilters: { ...V.mapFilters, [L.which]: o }, layer: null })}>
              <span className="dd-nm" style={o === cur ? { color: "var(--accent)" } : undefined}>{o}</span>
              {o === cur && <span style={{ color: "var(--accent)" }}>{Ico.check(14, "currentColor")}</span>}
            </button>
          ))}
          <div style={{ height: 16 }} />
          <button className="btn btn-ghost" onClick={closeLayer}>Close</button>
        </Sheet>
      );
    }

    if (L.type === "notifications") {
      const row = (n) => {
        const p = P(n.who);
        let action;
        const req = S.msgRequests.find((r) => r.with === n.who);
        if (n.kind === "connect" && req) {
          action = (<div style={{ display: "flex", gap: 6 }}>
            <button className="btn btn-dark btn-sm" onClick={() => acceptMsgRequest(req.id)}>Accept</button>
            <button className="btn btn-ghost btn-sm" onClick={() => deleteMsgRequest(req.id)}>Delete</button></div>);
        } else if (n.kind === "connect") {
          action = <span style={{ color: "var(--accent)" }}>{Ico.connect(17)}</span>;
        } else if (n.kind === "verify") {
          action = <button className="btn btn-dark btn-sm" onClick={() => { closeLayer(); toast("The result has been verified."); }}>Verify</button>;
        } else if (n.kind === "challenge") {
          action = <span style={{ color: "var(--accent)" }}>{Ico.trophy(17)}</span>;
        } else {
          action = <span style={{ color: "var(--ink-4)" }}>{Ico.chev()}</span>;
        }
        return (
          <div key={n.id} className={`nt ${n.unread ? "new" : ""}`} onClick={() => openLayer({ type: "drawer", id: n.who })}>
            <Avatar idx={p.av} size={44} />
            <div className="nt-tx"><b>{p.name}</b> {n.tx}<i>{n.t}</i></div>
            <div style={{ flex: "0 0 auto" }} onClick={(e) => e.stopPropagation()}>{action}</div>
          </div>
        );
      };
      const unread = S.notifications.filter((n) => n.unread), earlier = S.notifications.filter((n) => !n.unread);
      return (
        <Sheet title="Notifications">
          {S.notifications.length ? (<>
            {!!unread.length && (<><div className="nt-group" style={{ marginTop: 0 }}>New</div>{unread.map(row)}</>)}
            {!!earlier.length && (<><div className="nt-group">Earlier</div>{earlier.map(row)}</>)}
            <div style={{ height: 16 }} />
            <button className="btn btn-ghost" onClick={() => { setSK({ notifications: S.notifications.map((n) => ({ ...n, unread: false })) }); setVK({ layer: null }); toast("All notifications have been marked as read."); }}>Mark all as read</button>
          </>) : (<>
            <Empty icon={Ico.bell(28)} title="You are all caught up." body="New challenges, fixtures, and connection requests will appear here." />
            <button className="btn btn-ghost" onClick={closeLayer}>Close</button>
          </>)}
        </Sheet>
      );
    }

    if (L.type === "editProfile") return (
      <Sheet title="Edit profile details">
        <div className="field"><label>Name</label>
          <input className="input" value={S.me.name} onChange={(e) => { const v = e.target.value; setS((s) => ({ ...s, me: { ...s.me, name: v } })); markDirty("Editing profile details"); }} /></div>
        <div className="field"><label>Unique username</label>
          <input className="input" value={S.me.username} onChange={(e) => { const v = e.target.value; setS((s) => ({ ...s, me: { ...s.me, username: v } })); markDirty("Editing profile details"); }} /></div>
        <div className="field"><label>Age</label>
          <input className="input" inputMode="numeric" value={S.me.age} onChange={(e) => { const v = e.target.value; setS((s) => ({ ...s, me: { ...s.me, age: v } })); markDirty("Editing profile details"); }} /></div>
        <div className="field"><label>Gender</label>
          <div className="pill-row">{["Male", "Female", "Non-binary"].map((g) => (
            <button key={g} className={`pill ${S.me.gender === g ? "on" : ""}`} onClick={() => { setS((s) => ({ ...s, me: { ...s.me, gender: g } })); markDirty("Editing profile details"); }}>{g}</button>
          ))}</div></div>
        <div className="field"><label>Avatar</label>
          <div style={{ display: "flex", gap: 10, overflowX: "auto", padding: "2px 0 8px" }}>
            {Array.from({ length: 50 }, (_, i) => (
              <button key={i} className="av" style={{ flex: "0 0 auto", width: 52, height: 52, border: `2px solid ${S.me.av === i ? "var(--accent)" : "var(--line)"}` }}
                onClick={() => { setS((s) => ({ ...s, me: { ...s.me, av: i } })); markDirty("Editing profile details"); }}
                dangerouslySetInnerHTML={{ __html: personSVG(i, 52) }} />
            ))}
          </div></div>
        <button className="btn btn-dark" onClick={() => { clearDirty(); setVK({ layer: null }); toast("Your profile has been updated."); }}>Save changes</button>
      </Sheet>
    );

    if (L.type === "manageSports") {
      const toggleMy = (k) => {
        if (S.sports.includes(k)) {
          if (S.sports.length === 1) { toast("You must keep at least one sport."); return; }
          const next = S.sports.filter((x) => x !== k);
          setSK({ sports: next });
          if (V.activeSport === k) setVK({ activeSport: next[0] });
        } else {
          if (S.sports.length >= 4) { toast("You can select a maximum of four sports."); return; }
          setS((s) => ({ ...s, sports: [...s.sports, k],
            ratings: isIndividual(k) && s.ratings[k] == null ? { ...s.ratings, [k]: 80 } : s.ratings,
            peer: !isIndividual(k) && s.peer[k] === undefined ? { ...s.peer, [k]: null } : s.peer }));
        }
      };
      const row = (k) => {
        const p = SPORTS[k], on = S.sports.includes(k);
        return (
          <button key={k} className={`sport-row ${on ? "on" : ""}`} onClick={() => toggleMy(k)} style={on ? { borderColor: p.accent, background: p.soft } : undefined}>
            <span className="sr-ic" style={{ background: on ? "#fff" : p.soft }}><SportIcon sport={k} size={26} color={p.accent} /></span>
            <span style={{ flex: 1, minWidth: 0 }}>
              <span className="sr-nm" style={{ display: "block", color: on ? p.accent : undefined }}>{p.name}</span>
              <span className="sr-sub" style={{ display: "block" }}>{p.colour} · {p.cat === "individual" ? "MP Rated" : "Calendar and peer reviews"}</span>
            </span>
            <span className="sr-ck" style={on ? { background: p.accent, borderColor: "transparent" } : undefined}>{on && Ico.check(12)}</span>
          </button>
        );
      };
      return (
        <Sheet title="Manage your sports">
          <div className="tiny" style={{ marginBottom: 14 }}>{S.sports.length} of 4 selected. Every sport keeps its own colour wherever it appears.</div>
          <SecHead>Individual and dual sports</SecHead>
          {INDIVIDUAL.map(row)}
          <SecHead>Group sports</SecHead>
          {GROUP.map(row)}
          <div style={{ height: 16 }} />
          <button className="btn btn-dark" onClick={() => { setVK({ layer: null }); toast("Your sports have been updated."); }}>Done</button>
        </Sheet>
      );
    }

    if (L.type === "privacy" || L.type === "notifs") {
      const cfg = L.type === "privacy"
        ? { title: "Privacy and visibility", rows: [["Show me on the player map", true], ["Display my rating publicly", true], ["Allow messages from anyone nearby", true], ["Show my calendar to my squad", true]] }
        : { title: "Notification preferences", rows: [["Challenge invitations", true], ["Calendar changes", true], ["Connection requests", true], ["Community announcements", false]] };
      return <SettingsSheet cfg={cfg} onClose={() => { setVK({ layer: null }); toast("Your preferences have been saved."); }} closeLayer={closeLayer} />;
    }
    return null;
  }

  /* ================================================================
     COMPOSITION
     ================================================================ */
  return (
    <div className="mp" style={{ ...themeVars, minHeight: "100vh", width: "100%", display: "flex", flexDirection: "column",
      alignItems: "center", gap: 14, padding: "20px 14px 54px",
      background: "linear-gradient(180deg,#EEF1F8,#E4E8F1 60%,#DFE4EE)" }}>
      <style>{CSS}</style>

      <div className="sim-bar">
        <div className="sim-brand">Match<span>Point</span></div>
        <div className="sim-lab">Simulated profile</div>
        {[["A", "State A · New user"], ["B", "State B · Veteran user"]].map(([wch, label]) => (
          <button key={wch} className={`sim-btn ${S.profile === wch ? "on" : ""}`} onClick={() => loadProfile(wch)}>{label}</button>
        ))}
        <div className="sim-lab">Shortcuts</div>
        <button className="sim-btn" onClick={restartOnboarding}>Replay onboarding</button>
        <button className="sim-btn" onClick={demoVictory}>Victory screen</button>
        <button className="sim-btn" onClick={() => { switchSport("cricket"); goTab("matches"); }}>Group sport calendar</button>
        <div className="sim-note">iPhone 17 Pro · 402 × 874 pt</div>
      </div>

      <div className="device">
        <div className="screen">
          <div className="island" />
          <div className="bg-art">
            {ART_POS.map(([x, y, s, r], i) => (
              <i key={i} style={{ left: `${x}%`, top: `${y}%`, transform: `rotate(${r}deg)` }}>
                <SportIcon sport={V.activeSport} size={s} color="currentColor" /></i>
            ))}
          </div>
          <div className="statusbar">
            <div>9:41</div>
            <div className="sb-r">
              <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor"><rect x="0" y="7" width="3" height="4" rx="1" /><rect x="4.5" y="5" width="3" height="6" rx="1" /><rect x="9" y="2.5" width="3" height="8.5" rx="1" /><rect x="13.5" y="0" width="3" height="11" rx="1" /></svg>
              <svg width="24" height="12" viewBox="0 0 24 12" fill="none"><rect x=".6" y=".6" width="19" height="10.8" rx="3" stroke="currentColor" strokeOpacity=".4" /><rect x="2.2" y="2.2" width="15.8" height="7.6" rx="1.8" fill="currentColor" /></svg>
            </div>
          </div>

          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", position: "relative", zIndex: 1 }}>
            {V.screen === "onboarding" ? renderOnboarding()
              : V.screen === "chat" ? renderChat()
              : V.screen === "victory" ? renderVictory()
              : (<>
                  <AppBar />
                  {V.tab === "home" && viewHome()}
                  {V.tab === "map" && viewMap()}
                  {V.tab === "matches" && (groupMode ? viewCalendar() : viewMatches())}
                  {V.tab === "chats" && viewChats()}
                  {V.tab === "profile" && viewProfile()}
                  <Fab />
                  <NavBar />
                </>)}
          </div>

          {renderLayer()}

          {welcome && (
            <div className="welcome">
              <div style={{ position: "relative", display: "grid", placeItems: "center", height: 150, width: 150 }}>
                <div className="wm-rings"><i /><i /><i /></div>
                <div className="wm-orb" dangerouslySetInnerHTML={{ __html: personSVG(S.me.av, 104) }} />
              </div>
              <div className="wm-txt">Welcome to Match Point, {S.me.name || "player"}!</div>
              <div className="wm-sub">Your profile is live. We are finding players near you.</div>
            </div>
          )}

          {toastMsg && <div className="toast"><i className="tk" /><div>{toastMsg}</div></div>}
          <div className="home-ind" />
        </div>
      </div>
    </div>
  );
}

/* Settings sheet keeps its own toggle state. */
function SettingsSheet({ cfg, onClose, closeLayer }) {
  const [rows, setRows] = useState(cfg.rows);
  return (
    <div className="scrim" onClick={(e) => { if (e.target === e.currentTarget) closeLayer(); }}>
      <div className="sheet">
        <div className="sheet-head">
          <div className="sheet-grab" />
          <div className="sheet-head-row">
            <div className="h2">{cfg.title}</div>
            <button className="icon-btn" onClick={closeLayer} aria-label="Close">{Ico.close()}</button>
          </div>
        </div>
        <div className="sheet-body">
          {rows.map(([label, on], i) => (
            <div key={label} className="row" style={{ padding: "13px 2px", borderBottom: "1px solid var(--line)" }}>
              <div className="row-main"><div className="row-t">{label}</div></div>
              <div className={`checkbox ${on ? "on" : ""}`} style={{ cursor: "pointer" }}
                onClick={() => setRows((r) => r.map((x, j) => (j === i ? [x[0], !x[1]] : x)))}>{on && Ico.check()}</div>
            </div>
          ))}
          <div style={{ height: 18 }} />
          <button className="btn btn-dark" onClick={onClose}>Save preferences</button>
        </div>
      </div>
    </div>
  );
}
