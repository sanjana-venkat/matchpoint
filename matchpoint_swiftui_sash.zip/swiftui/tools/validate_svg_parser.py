#!/usr/bin/env python3
"""
Prototypes the SVG path parser that SVGPath.swift implements, and runs it
over every path string in the app.

There is no Swift toolchain here, so the parser cannot be compiled and
tested directly. Proving the *algorithm* against the real data in a
language I can run is the next best thing.

The subtlety this exists to catch: in an elliptical arc the two flag
arguments are single digits and may be written with no separator at all
("a3.6 3.6 0 00-3.6-3.6" packs both flags into "00"). A general number
scanner swallows them as one token and every rounded corner in the icon
set silently disappears. Flags must be read one character at a time.
"""
import re, sys, os

CMDS = set("MmLlHhVvCcSsQqTtAaZz")
ARGS = {"M":2,"L":2,"H":1,"V":1,"C":6,"S":4,"Q":4,"T":2,"A":7,"Z":0}
NUM = re.compile(r'[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?')

class Scanner:
    def __init__(self, d):
        self.d, self.i = d, 0
    def skip(self):
        while self.i < len(self.d) and self.d[self.i] in " ,\t\n\r":
            self.i += 1
    def at_end(self):
        self.skip(); return self.i >= len(self.d)
    def peek_cmd(self):
        self.skip()
        if self.i < len(self.d) and self.d[self.i] in CMDS:
            return self.d[self.i]
        return None
    def take_cmd(self):
        c = self.peek_cmd()
        if c: self.i += 1
        return c
    def number(self):
        self.skip()
        m = NUM.match(self.d, self.i)
        if not m or not m.group():
            raise ValueError(f"expected a number at {self.i}: {self.d[self.i:self.i+16]!r}")
        self.i = m.end()
        return float(m.group())
    def flag(self):
        """An arc flag is exactly one character, 0 or 1."""
        self.skip()
        if self.i >= len(self.d) or self.d[self.i] not in "01":
            raise ValueError(f"expected an arc flag at {self.i}: {self.d[self.i:self.i+16]!r}")
        v = self.d[self.i] == "1"
        self.i += 1
        return v

def run(d):
    s = Scanner(d)
    cx = cy = sx = sy = 0.0
    cmd, pts = None, []
    while not s.at_end():
        c = s.peek_cmd()
        if c is not None:
            cmd = s.take_cmd()
            if cmd in "Zz":
                cx, cy = sx, sy
                pts.append((cx, cy))
                continue
        else:
            if cmd is None:
                raise ValueError("number before any command")
            # An implicit repeat; a repeated moveto becomes a lineto.
            if cmd == "M": cmd = "L"
            elif cmd == "m": cmd = "l"
        up, rel = cmd.upper(), cmd.islower()
        if up == "A":
            _rx, _ry, _rot = s.number(), s.number(), s.number()
            _large, _sweep = s.flag(), s.flag()
            x, y = s.number(), s.number()
            cx, cy = (cx + x, cy + y) if rel else (x, y)
        elif up == "H":
            x = s.number(); cx = cx + x if rel else x
        elif up == "V":
            y = s.number(); cy = cy + y if rel else y
        else:
            a = [s.number() for _ in range(ARGS[up])]
            ex, ey = a[-2], a[-1]
            cx, cy = (cx + ex, cy + ey) if rel else (ex, ey)
            if up == "M": sx, sy = cx, cy
        pts.append((cx, cy))
    return pts

root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
sources = [os.path.join(root, "match-point", "src", "react", "01-icons-art-data.txt"),
           os.path.join(root, "match-point", "dist", "match-point-prototype.html")]
paths, seen = [], set()
for f in sources:
    for m in re.finditer(r"(?<![a-zA-Z-])d=\"([^\"]{4,})\"", open(f, encoding="utf-8").read()):
        d = m.group(1)
        if "${" in d or "\\(" in d:
            d = re.sub(r'\$\{[^}]*\}|\\\([^)]*\)', "1", d)
        if d not in seen:
            seen.add(d); paths.append((os.path.basename(f), d))

ok = bad = 0
cmds_seen, xs, ys = set(), [], []
for src, d in paths:
    try:
        pts = run(d)
        if not pts: raise ValueError("produced no points")
        cmds_seen |= {c for c in d if c in CMDS}
        xs += [p[0] for p in pts]; ys += [p[1] for p in pts]
        ok += 1
    except Exception as e:
        bad += 1
        if bad <= 6: print(f"FAIL [{src}] {e}\n     {d[:90]}")
print(f"{ok} path strings parsed, {bad} failed")
print("commands in use:", "".join(sorted(cmds_seen)))
print(f"coordinate range: x {min(xs):.0f}..{max(xs):.0f}   y {min(ys):.0f}..{max(ys):.0f}")
sys.exit(1 if bad else 0)
