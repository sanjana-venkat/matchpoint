#!/usr/bin/env python3
"""
The checks that are still possible without a Swift toolchain.

This is not a compiler and does not pretend to be one. It catches the
class of mistakes that are cheap to make when writing a lot of Swift
blind: unbalanced delimiters, unterminated strings, duplicate type
declarations, and references to types that are never defined anywhere in
the sources.
"""
import re, sys, os, collections

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
files = []
for base, _, names in os.walk(os.path.join(ROOT, "MatchPoint")):
    for n in sorted(names):
        if n.endswith(".swift"):
            files.append(os.path.join(base, n))

problems = []

def strip(src):
    """Remove comments and string bodies so delimiter counting is honest."""
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if c == '"':
            if src[i:i+3] == '"""':
                j = src.find('"""', i+3)
                i = (j + 3) if j != -1 else n
                continue
            j = i + 1
            while j < n:
                if src[j] == '\\': j += 2; continue
                if src[j] == '"': break
                j += 1
            i = j + 1
            continue
        if src[i:i+2] == "//":
            j = src.find("\n", i); i = j if j != -1 else n; continue
        if src[i:i+2] == "/*":
            j = src.find("*/", i+2); i = (j+2) if j != -1 else n; continue
        out.append(c); i += 1
    return "".join(out)

declared, referenced = {}, collections.defaultdict(set)
DECL = re.compile(r'^\s*(?:public |private |internal |final |@\w+\s+)*'
                  r'(struct|class|enum|protocol|extension|actor)\s+(\w+)', re.M)

for f in files:
    src = open(f).read()
    name = os.path.relpath(f, ROOT)
    code = strip(src)

    for open_c, close_c in [("{", "}"), ("(", ")"), ("[", "]")]:
        a, b = code.count(open_c), code.count(close_c)
        if a != b:
            problems.append(f"{name}: {a} '{open_c}' vs {b} '{close_c}'")

    if src.count('"""') % 2:
        problems.append(f"{name}: odd number of \"\"\" delimiters")

    for m in DECL.finditer(src):
        kind, nm = m.group(1), m.group(2)
        if kind == "extension":
            continue
        if nm in declared:
            problems.append(f"{name}: '{nm}' also declared in {declared[nm]}")
        declared[nm] = name

    for m in re.finditer(r'\b([A-Z][A-Za-z0-9]{2,})\b', code):
        referenced[m.group(1)].add(name)

KNOWN = set("""
String Int Double Bool CGFloat Float Date UUID Color View Text Image Path Shape Canvas
VStack HStack ZStack ScrollView List Button Spacer Divider Group Circle Rectangle
RoundedRectangle Capsule Ellipse GeometryReader Font Angle Animation Namespace
DispatchQueue Calendar DateComponents TimeZone Scanner Set Array Dictionary Optional
Identifiable Hashable Equatable Codable CaseIterable Comparable Sendable Error
StrokeStyle CGPoint CGRect CGSize LinearGradient RadialGradient EdgeInsets Alignment
Binding State StateObject ObservedObject EnvironmentObject Environment Observable
ObservableObject Published App Scene WindowGroup Never AnyView EmptyView ForEach
TextField SecureField Toggle Picker Slider Stepper NavigationStack NavigationLink
Section Form Label Menu Sheet Alert Task MainActor Void Any AnyHashable Character
Text Void Bundle URL Data JSONDecoder JSONEncoder NumberFormatter DateFormatter
UIScreen UIColor UIFont UIApplication Notification Timer Result Range ClosedRange
Transaction UnitPoint Axis ScrollViewProxy ScrollViewReader Material Visibility
ToolbarItem ToolbarItemGroup PreferenceKey ViewModifier ButtonStyle LabelStyle
SwiftUI Foundation CoreGraphics Combine Observation XCTest XCTestCase
Self Weight Level Style Alignment Edge Axis
""".split())

undefined = sorted(
    n for n, where in referenced.items()
    if n not in declared and n not in KNOWN
    and not n.startswith(("NS", "UI", "CG", "CA", "SF"))
)
if undefined:
    problems.append("possibly undefined types referenced: " + ", ".join(undefined[:25]))

print(f"{len(files)} Swift files, {sum(len(open(f).readlines()) for f in files)} lines")
print(f"{len(declared)} types declared\n")
if problems:
    print("ISSUES")
    for p in problems: print("  " + p)
else:
    print("no structural issues found")
print("\nNOTE: no Swift toolchain is available here, so none of this has been compiled.")
sys.exit(1 if problems else 0)
