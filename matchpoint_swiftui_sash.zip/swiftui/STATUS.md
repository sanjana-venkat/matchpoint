# Match Point · SwiftUI port — status

**Read this first. This port is unfinished, and none of it has been compiled.**

I have no Swift toolchain in my environment and the download is blocked, so
every line here is written blind. I got the foundation done properly rather
than rushing the whole thing badly — below is exactly what exists, what
doesn't, and what I'd do next.

## What is done

| File | Lines | What it is |
| --- | --- | --- |
| `Model/Sport.swift` | 120 | The six sports, their permanent palettes, peer-skill categories and all long-form copy |
| `Model/Domain.swift` | 250 | Every value type, plus the 42 generated players and the community list |
| `Model/DateHelpers.swift` | 140 | ISO dates, 24-hour times, week maths, slot labels, and the MP Rating curve |
| `Model/AppState.swift` | 640 | The entire state layer: both seeded accounts, every sport-scoped selector, and every action |
| `Model/MapClustering.swift` | 150 | Screen-distance clustering and zoom-to-split |
| `DesignSystem/Tokens.swift` | 100 | Colours, type scale, spacing, radii, elevation |
| `DesignSystem/SVGPath.swift` | 260 | Runtime SVG path parser, including a correct elliptical-arc implementation |
| `DesignSystem/Icons.swift` | 110 | The icon renderer and the six sport marks |
| `DesignSystem/IconData.swift` | 200 | All 34 icons, generated from the React source |
| `DesignSystem/ArtData.swift` | 50 | Avatar palettes and the hair/kit sets, generated |

Roughly 2,150 lines. Every product rule from the web build is carried over:
one active sport scoping everything, Connect as the only social action, the
reply gate before challenges, up to three slots answered from the chat, and
one calendar across all sports.

## What is not done

- **The view layer.** Around twenty files: the shell with its tab bar, app
  bar and FAB; Home, Map, Matches, Calendar, Chats, Chat, Profile,
  Onboarding, Victory; and the twenty sheets.
- **The avatar and hero renderer.** `ArtData.swift` has the extracted data
  but the assembly functions (`personSVG`, `heroArt`, `venueArt`,
  `myFace`) and the SVG-markup renderer that draws them are not written.
- **`MatchPoint.xcodeproj`.** Nothing to open yet.
- **Tests.** No XCTest translations of the JavaScript suites.

## What has actually been verified

Very little, and I want to be precise about it:

- **Structure.** `tools/check_swift.py` confirms delimiters balance across
  all files, no type is declared twice, and no type is referenced without
  being defined. That is not a compile.
- **The SVG path parser algorithm.** This one is genuinely verified.
  `tools/validate_svg_parser.py` implements the identical algorithm in
  Python and runs it against all 168 path strings in the product; every one
  parses. It caught a real bug in the process: SVG arc flags can be written
  with no separator (`a3.6 3.6 0 00-3.6-3.6` packs both flags into `00`), and
  a general number scanner swallows them as one token, leaving the arc short
  of arguments. Unfixed, every rounded corner in the icon set would have
  silently vanished. The Swift version reads flags one character at a time.
- **The icon and art extraction.** Generated from the React source by script
  rather than retyped, so the geometry cannot drift. Re-run
  `tools/extract_icons.py` and `tools/extract_art.py` after any change.

Everything else — that it compiles, that the layout matches, that the
gestures feel right — is unverified.

## If you want me to continue

The remaining work is mostly mechanical now that the state layer and design
system exist. In rough order:

1. `DesignSystem/Components.swift` — card, chip, poster, row, segmented
   tabs, empty state, primary/ghost/outline buttons. Everything else depends
   on these.
2. `DesignSystem/Art.swift` + `SVGView` — the markup renderer, then the four
   art functions transliterated from the JS string builders.
3. `Views/RootView.swift` — the shell, then the five tab views.
4. The sheets, which are all variations on one presentation.
5. `MatchPoint.xcodeproj` and the XCTest suites.

## A suggestion

Since I can't compile any of this, the fastest path for you is probably to
create a fresh iOS App project in Xcode, drag in the ten files that exist,
and build. The model layer has no SwiftUI dependencies beyond `Color`, so it
should surface any problems quickly and cheaply. Send me the first round of
errors and I'll fix them and carry on with the views.

Alternatively, if you'd rather I just push on and write the rest blind, say
so and I will — but you'd be fixing compile errors across five thousand
lines instead of two thousand, which is why I stopped where I did.
