//  Icons.swift
//  Renders the extracted icon table. One view walks the primitives, so all
//  thirty-four icons stay consistent and none of them is redrawn by hand.

import SwiftUI

struct Ico: View {
    let name: String
    var size: CGFloat = 21
    var color: Color = .primary

    init(_ name: String, _ size: CGFloat = 21, _ color: Color = .primary) {
        self.name = name; self.size = size; self.color = color
    }

    var body: some View {
        let spec = IconData.all[name]
        let tint = spec?.fixedStroke.map { Color(hex: $0) } ?? color
        let fill = spec?.fill.map { Color(hex: $0) }
        Canvas { ctx, sizeRect in
            guard let spec else { return }
            let k = min(sizeRect.width, sizeRect.height) / 24
            for el in spec.elements {
                switch el {
                case .path(let d, let w, let solid):
                    let p = SVGPath.path(d, viewBox: 24, target: min(sizeRect.width, sizeRect.height))
                    if let fill, spec.fixedStroke == nil {
                        ctx.fill(p, with: .color(fill))
                    } else if solid {
                        ctx.fill(p, with: .color(tint))
                    } else {
                        ctx.stroke(p, with: .color(tint),
                                   style: StrokeStyle(lineWidth: (w ?? spec.strokeWidth) * k,
                                                      lineCap: .round, lineJoin: .round))
                    }
                case .circle(let cx, let cy, let r, let solid):
                    let rect = CGRect(x: (cx - r) * k, y: (cy - r) * k, width: r * 2 * k, height: r * 2 * k)
                    let p = Path(ellipseIn: rect)
                    if solid { ctx.fill(p, with: .color(tint)) }
                    else { ctx.stroke(p, with: .color(tint), style: StrokeStyle(lineWidth: spec.strokeWidth * k)) }
                case .rect(let x, let y, let w, let h, let rx, let solid):
                    let rect = CGRect(x: x * k, y: y * k, width: w * k, height: h * k)
                    let p = Path(roundedRect: rect, cornerRadius: rx * k)
                    if solid { ctx.fill(p, with: .color(tint)) }
                    else { ctx.stroke(p, with: .color(tint), style: StrokeStyle(lineWidth: spec.strokeWidth * k, lineJoin: .round)) }
                }
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

/// The six sport marks. Drawn directly rather than through the icon table
/// because each one is a distinct little illustration.
struct SportIcon: View {
    let sport: Sport
    var size: CGFloat = 21
    var color: Color

    init(_ sport: Sport, _ size: CGFloat = 21, _ color: Color? = nil) {
        self.sport = sport; self.size = size
        self.color = color ?? sport.palette.accent
    }

    private var spec: (paths: [String], circles: [(CGFloat, CGFloat, CGFloat)], strokeWidth: CGFloat) {
        switch sport {
        case .pickleball:
            return (["M12 2.6c4.2 0 7 3.2 7 7.2 0 4.4-3.2 7.4-7 7.4s-7-3-7-7.4c0-4 2.8-7.2 7-7.2z",
                     "M10.6 17.2l-.5 3.4h3.8l-.5-3.4"],
                    [(9.4, 8.2, 0.9), (12, 6.6, 0.9), (14.6, 8.2, 0.9), (9.4, 11.6, 0.9), (12, 13.2, 0.9), (14.6, 11.6, 0.9)], 1.6)
        case .badminton:
            return (["M12 3.4l4.4 4.4-6 6-4.4-4.4z", "M6 9.4L3.4 12l8.6 8.6 2.6-2.6"], [(17.2, 6.6, 2.4)], 1.6)
        case .pingpong:
            return (["M4.6 13.4a6.6 6.6 0 019.4-9.4c2.6 2.6 2.6 6.8 0 9.4s-6.8 2.6-9.4 0z",
                     "M11 15.6l4.6 4.6a1.7 1.7 0 002.4-2.4l-4.6-4.6"], [(18.6, 8.2, 2.2)], 1.6)
        case .cricket:
            return (["M14.6 3.2l6.2 6.2-8 8-6.2-6.2z", "M6.6 11.2L3.4 14.4a2 2 0 000 2.8l3.4 3.4a2 2 0 002.8 0l3.2-3.2"], [(6, 6, 2.6)], 1.6)
        case .soccer:
            return (["M12 7.1l3.6 2.6-1.4 4.3H9.8L8.4 9.7 12 7.1z",
                     "M12 2.8v4.3M20.9 10.2l-5.3-.5M17.6 20.3l-3.4-6.3M6.4 20.3l3.4-6.3M3.1 10.2l5.3-.5"], [(12, 12, 9.2)], 1.4)
        case .volleyball:
            return (["M12 2.8c-3.4 4-3.9 12.4 1.4 18.2M21 9.6c-5 .6-11.4 4.8-12.4 11.2M4 6.2c1.8 4.7 8.5 8.6 15.5 7.5"], [(12, 12, 9.2)], 1.4)
        }
    }

    var body: some View {
        let s = spec
        Canvas { ctx, rect in
            let k = min(rect.width, rect.height) / 24
            for (cx, cy, r) in s.circles {
                let box = CGRect(x: (cx - r) * k, y: (cy - r) * k, width: r * 2 * k, height: r * 2 * k)
                ctx.stroke(Path(ellipseIn: box), with: .color(color),
                           style: StrokeStyle(lineWidth: s.strokeWidth * k))
            }
            for d in s.paths {
                ctx.stroke(SVGPath.path(d, viewBox: 24, target: min(rect.width, rect.height)),
                           with: .color(color),
                           style: StrokeStyle(lineWidth: s.strokeWidth * k, lineCap: .round, lineJoin: .round))
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}
