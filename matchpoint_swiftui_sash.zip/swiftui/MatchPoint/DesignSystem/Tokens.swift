//  Tokens.swift
//  Every colour, size and radius in the product comes from here. The web
//  build holds these as CSS custom properties and rewrites four of them when
//  the sport changes; the Swift equivalent is reading `state.pal`.

import SwiftUI

extension Color {
    /// "#4CA85F" or "#fff" — the two forms used across the source.
    init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespaces)
        if s.hasPrefix("#") { s.removeFirst() }
        if s.count == 3 { s = s.map { "\($0)\($0)" }.joined() }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        let r, g, b, a: Double
        if s.count == 8 {
            r = Double((v >> 24) & 0xFF) / 255; g = Double((v >> 16) & 0xFF) / 255
            b = Double((v >> 8) & 0xFF) / 255;  a = Double(v & 0xFF) / 255
        } else {
            r = Double((v >> 16) & 0xFF) / 255; g = Double((v >> 8) & 0xFF) / 255
            b = Double(v & 0xFF) / 255;         a = 1
        }
        self.init(.sRGB, red: r, green: g, blue: b, opacity: a)
    }
}

enum MPColor {
    static let bgHex = "#F7F8FB"
    static let surfaceHex = "#FFFFFF"
    static let surface2Hex = "#F4F6FA"
    static let surface3Hex = "#EBEEF4"
    static let lineHex = "#E6E9F0"
    static let line2Hex = "#D9DEE8"
    static let inkHex = "#151821"
    static let ink2Hex = "#565D70"
    static let ink3Hex = "#858C9E"
    static let ink4Hex = "#A9B0BF"
    static let blackHex = "#14161C"
    static let dangerHex = "#CE5555"
    static let dangerSoftHex = "#FCEEEE"
    static let warnHex = "#D0762F"
    static let warnSoftHex = "#FDF3E9"
    static let accentMidHex = "#8FD3A0"

    static let bg = Color(hex: bgHex)
    static let surface = Color(hex: surfaceHex)
    static let surface2 = Color(hex: surface2Hex)
    static let surface3 = Color(hex: surface3Hex)
    static let line = Color(hex: lineHex)
    static let line2 = Color(hex: line2Hex)
    static let ink = Color(hex: inkHex)
    static let ink2 = Color(hex: ink2Hex)
    static let ink3 = Color(hex: ink3Hex)
    static let ink4 = Color(hex: ink4Hex)
    static let black = Color(hex: blackHex)
    static let danger = Color(hex: dangerHex)
    static let dangerSoft = Color(hex: dangerSoftHex)
    static let warn = Color(hex: warnHex)
    static let warnSoft = Color(hex: warnSoftHex)
}

/// The eight-step scale, matched to the web build point for point.
enum MPFont {
    static func display(_ w: Font.Weight = .heavy) -> Font { .system(size: 26, weight: w) }
    static func h1(_ w: Font.Weight = .heavy) -> Font      { .system(size: 21, weight: w) }
    static func h2(_ w: Font.Weight = .bold) -> Font       { .system(size: 17, weight: w) }
    static func title(_ w: Font.Weight = .semibold) -> Font { .system(size: 15.5, weight: w) }
    static func body(_ w: Font.Weight = .regular) -> Font  { .system(size: 14.5, weight: w) }
    static func label(_ w: Font.Weight = .semibold) -> Font { .system(size: 13, weight: w) }
    static func caption(_ w: Font.Weight = .medium) -> Font { .system(size: 12, weight: w) }
    static func micro(_ w: Font.Weight = .bold) -> Font    { .system(size: 10.5, weight: w) }
}

enum MPSpace {
    static let pad: CGFloat = 20
    static let navHeight: CGFloat = 92
}

enum MPRadius {
    static let chip: CGFloat = 999
    static let card: CGFloat = 18
    static let poster: CGFloat = 22
    static let button: CGFloat = 14
    static let sheet: CGFloat = 28
}

extension View {
    func mpShadowSm() -> some View { shadow(color: .black.opacity(0.05), radius: 4, y: 2) }
    func mpShadowMd() -> some View { shadow(color: .black.opacity(0.07), radius: 12, y: 5) }
    func mpShadowLg() -> some View { shadow(color: .black.opacity(0.16), radius: 22, y: 10) }
}
