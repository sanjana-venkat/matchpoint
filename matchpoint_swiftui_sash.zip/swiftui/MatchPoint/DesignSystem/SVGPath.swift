//  SVGPath.swift
//  Turns an SVG path "d" string into a SwiftUI Path.
//
//  Why this exists: the icon set and the fifty procedural avatars are
//  hundreds of path strings. Hand-converting them into Path.move/addCurve
//  calls would be the single most likely place for this build to drift away
//  from the web one, so the path data is carried across verbatim and parsed
//  here instead.
//
//  The one genuine subtlety is arc flags. In "a3.6 3.6 0 00-3.6-3.6" the two
//  flag arguments are single digits written with no separator, so a general
//  number scanner swallows "00" as one token, the arc is left short of
//  arguments, and every rounded corner in the icon set silently disappears.
//  Flags are therefore read one character at a time.
//
//  The algorithm here was prototyped and run against all 168 path strings in
//  the product before being written in Swift.

import SwiftUI

enum SVGPath {

    private struct Scanner {
        let s: [Character]
        var i = 0
        init(_ text: String) { s = Array(text) }

        static let commands = Set("MmLlHhVvCcSsQqTtAaZz")

        mutating func skipSeparators() {
            while i < s.count, s[i] == " " || s[i] == "," || s[i] == "\n"
                    || s[i] == "\t" || s[i] == "\r" {
                i += 1
            }
        }

        mutating func atEnd() -> Bool { skipSeparators(); return i >= s.count }

        mutating func peekCommand() -> Character? {
            skipSeparators()
            guard i < s.count, Scanner.commands.contains(s[i]) else { return nil }
            return s[i]
        }

        mutating func takeCommand() -> Character? {
            guard let c = peekCommand() else { return nil }
            i += 1
            return c
        }

        mutating func number() -> CGFloat? {
            skipSeparators()
            var j = i
            if j < s.count, s[j] == "-" || s[j] == "+" { j += 1 }
            var sawDigit = false
            while j < s.count, s[j].isNumber { j += 1; sawDigit = true }
            if j < s.count, s[j] == "." {
                j += 1
                while j < s.count, s[j].isNumber { j += 1; sawDigit = true }
            }
            if sawDigit, j < s.count, s[j] == "e" || s[j] == "E" {
                var k = j + 1
                if k < s.count, s[k] == "-" || s[k] == "+" { k += 1 }
                var expDigits = false
                while k < s.count, s[k].isNumber { k += 1; expDigits = true }
                if expDigits { j = k }
            }
            guard sawDigit, let v = Double(String(s[i..<j])) else { return nil }
            i = j
            return CGFloat(v)
        }

        /// An arc flag is exactly one character, 0 or 1.
        mutating func flag() -> Bool? {
            skipSeparators()
            guard i < s.count, s[i] == "0" || s[i] == "1" else { return nil }
            let v = s[i] == "1"
            i += 1
            return v
        }
    }

    /// Parse `d`, scaling from a `viewBox` of `size` into `target` points.
    static func path(_ d: String, viewBox: CGFloat = 24, target: CGFloat = 24) -> Path {
        let k = target / viewBox
        var p = Path()
        var sc = Scanner(d)
        var current = CGPoint.zero
        var start = CGPoint.zero
        var lastControl: CGPoint?
        var cmd: Character?

        func pt(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x * k, y: y * k) }

        while !sc.atEnd() {
            if let c = sc.peekCommand() {
                cmd = sc.takeCommand()
                if c == "Z" || c == "z" {
                    p.closeSubpath()
                    current = start
                    lastControl = nil
                    continue
                }
            } else {
                guard let existing = cmd else { break }
                // An implicit repeat; a repeated moveto becomes a lineto.
                if existing == "M" { cmd = "L" } else if existing == "m" { cmd = "l" }
            }
            guard let c = cmd else { break }
            let rel = c.isLowercase
            let up = Character(c.uppercased())

            switch up {
            case "M":
                guard let x = sc.number(), let y = sc.number() else { return p }
                current = rel ? CGPoint(x: current.x + x, y: current.y + y) : CGPoint(x: x, y: y)
                start = current
                p.move(to: pt(current.x, current.y))
                lastControl = nil

            case "L":
                guard let x = sc.number(), let y = sc.number() else { return p }
                current = rel ? CGPoint(x: current.x + x, y: current.y + y) : CGPoint(x: x, y: y)
                p.addLine(to: pt(current.x, current.y))
                lastControl = nil

            case "H":
                guard let x = sc.number() else { return p }
                current.x = rel ? current.x + x : x
                p.addLine(to: pt(current.x, current.y))
                lastControl = nil

            case "V":
                guard let y = sc.number() else { return p }
                current.y = rel ? current.y + y : y
                p.addLine(to: pt(current.x, current.y))
                lastControl = nil

            case "C":
                guard let x1 = sc.number(), let y1 = sc.number(),
                      let x2 = sc.number(), let y2 = sc.number(),
                      let x = sc.number(), let y = sc.number() else { return p }
                let c1 = rel ? CGPoint(x: current.x + x1, y: current.y + y1) : CGPoint(x: x1, y: y1)
                let c2 = rel ? CGPoint(x: current.x + x2, y: current.y + y2) : CGPoint(x: x2, y: y2)
                let e  = rel ? CGPoint(x: current.x + x,  y: current.y + y)  : CGPoint(x: x, y: y)
                p.addCurve(to: pt(e.x, e.y), control1: pt(c1.x, c1.y), control2: pt(c2.x, c2.y))
                current = e; lastControl = c2

            case "S":
                guard let x2 = sc.number(), let y2 = sc.number(),
                      let x = sc.number(), let y = sc.number() else { return p }
                let c2 = rel ? CGPoint(x: current.x + x2, y: current.y + y2) : CGPoint(x: x2, y: y2)
                let e  = rel ? CGPoint(x: current.x + x,  y: current.y + y)  : CGPoint(x: x, y: y)
                // The first control point mirrors the previous one.
                let c1 = lastControl.map { CGPoint(x: 2 * current.x - $0.x, y: 2 * current.y - $0.y) } ?? current
                p.addCurve(to: pt(e.x, e.y), control1: pt(c1.x, c1.y), control2: pt(c2.x, c2.y))
                current = e; lastControl = c2

            case "Q":
                guard let x1 = sc.number(), let y1 = sc.number(),
                      let x = sc.number(), let y = sc.number() else { return p }
                let c1 = rel ? CGPoint(x: current.x + x1, y: current.y + y1) : CGPoint(x: x1, y: y1)
                let e  = rel ? CGPoint(x: current.x + x,  y: current.y + y)  : CGPoint(x: x, y: y)
                p.addQuadCurve(to: pt(e.x, e.y), control: pt(c1.x, c1.y))
                current = e; lastControl = c1

            case "T":
                guard let x = sc.number(), let y = sc.number() else { return p }
                let e = rel ? CGPoint(x: current.x + x, y: current.y + y) : CGPoint(x: x, y: y)
                let c1 = lastControl.map { CGPoint(x: 2 * current.x - $0.x, y: 2 * current.y - $0.y) } ?? current
                p.addQuadCurve(to: pt(e.x, e.y), control: pt(c1.x, c1.y))
                current = e; lastControl = c1

            case "A":
                guard let rx = sc.number(), let ry = sc.number(), let rot = sc.number(),
                      let large = sc.flag(), let sweep = sc.flag(),
                      let x = sc.number(), let y = sc.number() else { return p }
                let e = rel ? CGPoint(x: current.x + x, y: current.y + y) : CGPoint(x: x, y: y)
                addArc(&p, from: current, to: e, rx: rx, ry: ry,
                       rotation: rot, largeArc: large, sweep: sweep, scale: k)
                current = e; lastControl = nil

            default:
                return p
            }
        }
        return p
    }

    /// Endpoint-to-centre conversion, per the SVG implementation notes, then
    /// approximated with cubic segments of at most 90 degrees each.
    private static func addArc(_ p: inout Path, from: CGPoint, to: CGPoint,
                               rx: CGFloat, ry: CGFloat, rotation: CGFloat,
                               largeArc: Bool, sweep: Bool, scale k: CGFloat) {
        if rx == 0 || ry == 0 || (from.x == to.x && from.y == to.y) {
            p.addLine(to: CGPoint(x: to.x * k, y: to.y * k))
            return
        }
        var rx = abs(rx), ry = abs(ry)
        let phi = rotation * .pi / 180
        let cosPhi = cos(phi), sinPhi = sin(phi)

        let dx2 = (from.x - to.x) / 2, dy2 = (from.y - to.y) / 2
        let x1 =  cosPhi * dx2 + sinPhi * dy2
        let y1 = -sinPhi * dx2 + cosPhi * dy2

        // Grow the radii if they are too small to span the two points.
        let lambda = (x1 * x1) / (rx * rx) + (y1 * y1) / (ry * ry)
        if lambda > 1 {
            let s = sqrt(lambda)
            rx *= s; ry *= s
        }

        let sign: CGFloat = (largeArc != sweep) ? 1 : -1
        let num = max(0, rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1)
        let den = rx * rx * y1 * y1 + ry * ry * x1 * x1
        let co = den == 0 ? 0 : sign * sqrt(num / den)
        let cx1 =  co * rx * y1 / ry
        let cy1 = -co * ry * x1 / rx

        let cx = cosPhi * cx1 - sinPhi * cy1 + (from.x + to.x) / 2
        let cy = sinPhi * cx1 + cosPhi * cy1 + (from.y + to.y) / 2

        func angle(_ ux: CGFloat, _ uy: CGFloat, _ vx: CGFloat, _ vy: CGFloat) -> CGFloat {
            let dot = ux * vx + uy * vy
            let len = sqrt(ux * ux + uy * uy) * sqrt(vx * vx + vy * vy)
            var a = acos(max(-1, min(1, len == 0 ? 1 : dot / len)))
            if ux * vy - uy * vx < 0 { a = -a }
            return a
        }

        let theta = angle(1, 0, (x1 - cx1) / rx, (y1 - cy1) / ry)
        var delta = angle((x1 - cx1) / rx, (y1 - cy1) / ry,
                          (-x1 - cx1) / rx, (-y1 - cy1) / ry)
        if !sweep, delta > 0 { delta -= 2 * .pi }
        if sweep, delta < 0 { delta += 2 * .pi }

        let segments = max(1, Int(ceil(abs(delta) / (.pi / 2))))
        let step = delta / CGFloat(segments)
        var start = theta

        for _ in 0..<segments {
            let end = start + step
            let t = 4.0 / 3.0 * tan(step / 4)

            let cosS = cos(start), sinS = sin(start)
            let cosE = cos(end),   sinE = sin(end)

            func point(_ c: CGFloat, _ s: CGFloat) -> CGPoint {
                CGPoint(x: cx + rx * c * cosPhi - ry * s * sinPhi,
                        y: cy + rx * c * sinPhi + ry * s * cosPhi)
            }
            func derivative(_ c: CGFloat, _ s: CGFloat) -> CGPoint {
                CGPoint(x: -rx * s * cosPhi - ry * c * sinPhi,
                        y: -rx * s * sinPhi + ry * c * cosPhi)
            }

            let p1 = point(cosS, sinS), p2 = point(cosE, sinE)
            let d1 = derivative(cosS, sinS), d2 = derivative(cosE, sinE)
            let c1 = CGPoint(x: p1.x + t * d1.x, y: p1.y + t * d1.y)
            let c2 = CGPoint(x: p2.x - t * d2.x, y: p2.y - t * d2.y)

            p.addCurve(to: CGPoint(x: p2.x * k, y: p2.y * k),
                       control1: CGPoint(x: c1.x * k, y: c1.y * k),
                       control2: CGPoint(x: c2.x * k, y: c2.y * k))
            start = end
        }
    }
}

/// A Shape wrapper, so path data can be used anywhere a Shape is expected.
struct SVGShape: Shape {
    let d: String
    var viewBox: CGFloat = 24

    func path(in rect: CGRect) -> Path {
        SVGPath.path(d, viewBox: viewBox, target: min(rect.width, rect.height))
    }
}
