//  MapClustering.swift
//  Markers merge on the distance they end up at ON SCREEN, not on which grid
//  cell they happen to fall in. That is the whole point: it guarantees two
//  markers are never closer than CLUSTER_R points at any zoom, which grid
//  bucketing cannot promise — under bucketing two players five points apart
//  on opposite sides of a cell boundary draw on top of each other.

import CoreGraphics
import Foundation

enum MapConfig {
    static let worldWidth: CGFloat = 760
    static let worldHeight: CGFloat = 960
    /// Points between marker centres, measured on screen.
    static let clusterRadius: CGFloat = 66
    static let maxZoom: CGFloat = 2.6
    static let minZoom: CGFloat = 0.55
    /// Where you are, in world coordinates.
    static let mePoint = CGPoint(x: 380, y: 480)

    /// Each venue is a tight knot, so its players merge into one bubble at
    /// the default zoom and come apart again once you zoom past it. The
    /// loners are spaced between the venues, and every position is kept
    /// clear of your own dot even at the widest zoom.
    static let pinPositions: [CGPoint] = [
        CGPoint(x: 156, y: 200), CGPoint(x: 192, y: 196), CGPoint(x: 168, y: 236), CGPoint(x: 204, y: 232),
        CGPoint(x: 546, y: 284), CGPoint(x: 582, y: 280), CGPoint(x: 558, y: 320), CGPoint(x: 594, y: 316),
        CGPoint(x: 92,  y: 470),
        CGPoint(x: 276, y: 614), CGPoint(x: 312, y: 610), CGPoint(x: 288, y: 650), CGPoint(x: 324, y: 646),
        CGPoint(x: 470, y: 392),
        CGPoint(x: 626, y: 764), CGPoint(x: 662, y: 760), CGPoint(x: 638, y: 800),
        CGPoint(x: 702, y: 520), CGPoint(x: 128, y: 764)
    ]
}

struct MapPoint {
    let player: Player
    let position: CGPoint
}

struct MapCluster: Identifiable {
    let id: Int
    var centre: CGPoint
    var items: [MapPoint]
    var isSingle: Bool { items.count == 1 }
}

enum MapClustering {

    /// The players the map is currently showing, after the filter chips.
    static func players(state: AppState) -> [Player] {
        var list = Catalog.allPlayers
            .filter { $0.sports.contains(state.activeSport) }
            .prefix(19)
            .map { $0 }
        let f = state.mapFilters
        if f.gender != "Any" { list = list.filter { $0.gender == f.gender } }
        if f.rating != "Any" {
            let bounds: (Int, Int)
            switch f.rating {
            case "Under 80":  bounds = (0, 79)
            case "80 to 110": bounds = (80, 110)
            default:          bounds = (111, 999)
            }
            list = list.filter {
                let r = $0.rating(for: state.activeSport)
                return r >= bounds.0 && r <= bounds.1
            }
        }
        return list
    }

    static func points(state: AppState) -> [MapPoint] {
        players(state: state).enumerated().map { i, p in
            MapPoint(player: p, position: MapConfig.pinPositions[i % MapConfig.pinPositions.count])
        }
    }

    /// Greedy clustering with a moving centroid, then one merge pass so the
    /// minimum spacing holds even after centres drift towards each other.
    static func clusters(state: AppState, zoom: CGFloat) -> [MapCluster] {
        let rw = MapConfig.clusterRadius / max(zoom, 0.01)   // the radius in world units

        // Sorting first keeps the grouping identical between renders.
        let pts = points(state: state).sorted {
            if $0.position.y != $1.position.y { return $0.position.y < $1.position.y }
            if $0.position.x != $1.position.x { return $0.position.x < $1.position.x }
            return $0.player.id < $1.player.id
        }

        var taken = [Bool](repeating: false, count: pts.count)
        var out: [(CGPoint, [MapPoint])] = []

        for (si, seed) in pts.enumerated() where !taken[si] {
            taken[si] = true
            var items = [seed]
            var centre = seed.position
            var grew = true
            // Absorb anything inside the radius, then re-check from the new
            // centre, so a row of players collapses into one bubble.
            while grew {
                grew = false
                for (oi, o) in pts.enumerated() where !taken[oi] {
                    if hypot(o.position.x - centre.x, o.position.y - centre.y) <= rw {
                        taken[oi] = true
                        items.append(o)
                        grew = true
                        centre = centroid(items)
                    }
                }
            }
            out.append((centre, items))
        }

        var i = 0
        while i < out.count {
            var j = i + 1
            while j < out.count {
                if hypot(out[i].0.x - out[j].0.x, out[i].0.y - out[j].0.y) <= rw {
                    out[i].1.append(contentsOf: out[j].1)
                    out[i].0 = centroid(out[i].1)
                    out.remove(at: j)
                    j = i + 1
                } else {
                    j += 1
                }
            }
            i += 1
        }

        return out.enumerated().map { MapCluster(id: $0.offset, centre: $0.element.0, items: $0.element.1) }
    }

    private static func centroid(_ items: [MapPoint]) -> CGPoint {
        let n = CGFloat(items.count)
        return CGPoint(x: items.reduce(0) { $0 + $1.position.x } / n,
                       y: items.reduce(0) { $0 + $1.position.y } / n)
    }

    /// Tapping a cluster zooms far enough in that its members come apart.
    static func zoomToSplit(_ items: [MapPoint], from current: CGFloat) -> CGFloat {
        var minD = CGFloat.greatestFiniteMagnitude
        for i in 0..<items.count {
            for j in (i + 1)..<items.count {
                minD = min(minD, hypot(items[i].position.x - items[j].position.x,
                                       items[i].position.y - items[j].position.y))
            }
        }
        let needed = (minD.isFinite && minD > 0)
            ? (MapConfig.clusterRadius + 8) / minD
            : current * 1.8
        return min(MapConfig.maxZoom, max(current * 1.35, needed))
    }
}
