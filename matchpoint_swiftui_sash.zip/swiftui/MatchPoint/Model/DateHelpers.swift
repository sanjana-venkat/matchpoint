//  DateHelpers.swift
//  Dates are held as ISO strings and 24-hour "HH:mm" times, exactly as in
//  the web build, so seed data and calendar maths port across unchanged.

import Foundation

enum MPDate {
    /// The prototype runs on a fixed day so the seeded week always lines up.
    /// Tuesday, 11 August 2026.
    static let today: Date = {
        var c = DateComponents()
        c.year = 2026; c.month = 8; c.day = 11
        return Calendar(identifier: .gregorian).date(from: c) ?? Date()
    }()

    static let dow = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
    static let months = ["January","February","March","April","May","June",
                         "July","August","September","October","November","December"]
    static let monShort = ["Jan","Feb","Mar","Apr","May","Jun",
                           "Jul","Aug","Sep","Oct","Nov","Dec"]

    private static var cal: Calendar {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = TimeZone(secondsFromGMT: 0) ?? .current
        return c
    }

    static func date(fromISO s: String) -> Date {
        let parts = s.split(separator: "-").compactMap { Int($0) }
        guard parts.count == 3 else { return today }
        var c = DateComponents()
        c.year = parts[0]; c.month = parts[1]; c.day = parts[2]
        return Calendar(identifier: .gregorian).date(from: c) ?? today
    }

    static func iso(_ d: Date) -> String {
        let c = Calendar(identifier: .gregorian).dateComponents([.year, .month, .day], from: d)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    /// Monday-first week containing today, shifted by `offset` weeks.
    static func startOfWeek(_ offset: Int) -> Date {
        let c = Calendar(identifier: .gregorian)
        let weekday = c.component(.weekday, from: today)          // 1 = Sunday
        let mondayIndex = (weekday + 5) % 7                        // 0 = Monday
        let base = c.date(byAdding: .day, value: -mondayIndex, to: today) ?? today
        return c.date(byAdding: .day, value: offset * 7, to: base) ?? base
    }

    static func weekDays(_ offset: Int) -> [Date] {
        let start = startOfWeek(offset)
        let c = Calendar(identifier: .gregorian)
        return (0..<7).compactMap { c.date(byAdding: .day, value: $0, to: start) }
    }

    static func dayIndex(_ d: Date) -> Int {
        let weekday = Calendar(identifier: .gregorian).component(.weekday, from: d)
        return (weekday + 5) % 7
    }

    static func dayNumber(_ d: Date) -> Int {
        Calendar(identifier: .gregorian).component(.day, from: d)
    }

    static func monthIndex(_ d: Date) -> Int {
        Calendar(identifier: .gregorian).component(.month, from: d) - 1
    }

    static func year(_ d: Date) -> Int {
        Calendar(identifier: .gregorian).component(.year, from: d)
    }

    /// Minutes past midnight for an "HH:mm" string.
    static func minutes(_ t: String) -> Int {
        let p = t.split(separator: ":").compactMap { Int($0) }
        guard p.count == 2 else { return 0 }
        return p[0] * 60 + p[1]
    }

    static func time(fromMinutes m: Int) -> String {
        String(format: "%02d:%02d", m / 60, m % 60)
    }

    /// "18:30" -> "6:30 PM"
    static func fmtTime(_ t: String) -> String {
        let p = t.split(separator: ":").compactMap { Int($0) }
        guard p.count == 2 else { return t }
        let h = p[0], m = p[1]
        let hh = h % 12 == 0 ? 12 : h % 12
        return "\(hh):" + String(format: "%02d", m) + (h < 12 ? " AM" : " PM")
    }

    /// "2026-08-12" -> "Wed, Aug 12"
    static func fmtDate(_ isoString: String) -> String {
        let d = date(fromISO: isoString)
        return "\(dow[dayIndex(d)]), \(monShort[monthIndex(d)]) \(dayNumber(d))"
    }

    static func slotLabel(_ s: Slot) -> String {
        "\(fmtDate(s.date)) · \(fmtTime(s.start))"
    }

    /// A challenge slot runs an hour and a half by default.
    static func endOf(_ start: String) -> String {
        time(fromMinutes: minutes(start) + 90)
    }

    /// "Just now" / "7h ago" / "3d ago"
    static func agoLabel(_ h: Int) -> String {
        h < 1 ? "Just now" : (h < 24 ? "\(h)h ago" : "\(h / 24)d ago")
    }

    /// The next fourteen days, for the challenge composer.
    static func challengeDates() -> [String] {
        let c = Calendar(identifier: .gregorian)
        return (0..<14).compactMap { i in
            c.date(byAdding: .day, value: i + 1, to: today).map(iso)
        }
    }

    static func clockLabel() -> String {
        let d = Date()
        let c = Calendar.current.dateComponents([.hour, .minute], from: d)
        let h = c.hour ?? 0, m = c.minute ?? 0
        return "\(h % 12 == 0 ? 12 : h % 12):" + String(format: "%02d", m)
    }

    static func nowLabel() -> String {
        let c = Calendar.current.dateComponents([.hour, .minute], from: Date())
        let h = c.hour ?? 0, m = c.minute ?? 0
        let hh = h % 12 == 0 ? 12 : h % 12
        return "\(hh):" + String(format: "%02d", m) + (h < 12 ? " AM" : " PM")
    }
}

/// How the MP Rating moves. Ported verbatim: the size of every change
/// depends on the gap between the two ratings, so one result never swings
/// a level dramatically.
func ratingDelta(mine: Int, theirs: Int, won: Bool) -> Int {
    let d = theirs - mine
    if won {
        if d > 40 { return 5 }
        if d > 22 { return 4 }
        if d > 8  { return 3 }
        if d >= -8 { return abs(d) <= 3 ? 2 : 1 }
        return 1
    }
    if d < -40 { return -5 }
    if d < -22 { return -4 }
    if d < -8  { return -3 }
    if d <= 8  { return abs(d) <= 3 ? -2 : -1 }
    return -1
}
