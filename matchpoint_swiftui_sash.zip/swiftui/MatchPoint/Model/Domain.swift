//  Domain.swift
//  Every value type in the product, and the seed data behind the two
//  simulated accounts. Ported one-for-one from the JavaScript build.

import Foundation

// MARK: - People

struct Player: Identifiable, Hashable {
    let id: String
    let name: String
    let av: Int
    let rating: Int
    let username: String
    let age: Int
    let gender: String
    let dist: String
    let bio: String
    let sports: [Sport]
    let ratings: [Sport: Int]
    let mutual: Int

    /// The rating shown for a sport, falling back to the general one.
    func rating(for sport: Sport) -> Int { ratings[sport] ?? rating }
}

// MARK: - Conversation

struct Message: Identifiable, Hashable {
    let id = UUID()
    var me: Bool
    var text: String
    var time: String
    /// A challenge lives inside the conversation rather than in a separate
    /// inbox, which is what lets the recipient answer it in one tap.
    var challenge: ChallengeProposal?
}

struct ChallengeProposal: Hashable {
    var cid: String
    var sport: Sport
    var venue: String
    var slots: [Slot]
    /// Index of the slot the recipient picked, if any.
    var chosen: Int?
    var declined: Bool
}

struct ChatThread: Identifiable, Hashable {
    let id: String
    var with: String
    var unread: Int
    /// True when you sent the opener and they have not written back. No
    /// challenges until they do.
    var pending: Bool
    var msgs: [Message]
}

struct MsgRequest: Identifiable, Hashable {
    let id: String
    var with: String
    var hrs: Int
    var text: String
}

// MARK: - Matches

struct Slot: Hashable {
    var date: String        // ISO yyyy-MM-dd
    var start: String       // 24h HH:mm
    var end: String
}

enum ChallengeStatus: String, Hashable {
    case confirmed = "Confirmed"
    case tentative = "Tentative"
}

struct Challenge: Identifiable, Hashable {
    let id: String
    var sport: Sport
    var opp: String
    var venue: String
    var status: ChallengeStatus
    /// Who proposed it. Only meaningful while tentative.
    var from: String?
    /// Every time on the table. A confirmed challenge holds exactly one.
    var slots: [Slot]

    var firstSlot: Slot { slots.first ?? Slot(date: "", start: "00:00", end: "00:00") }
}

struct PastMatch: Identifiable, Hashable {
    let id: String
    var sport: Sport
    var opp: String
    var partner: String?
    var mode: String
    var games: [Int]
    var won: Bool
    var score: String
    var date: String
    var venue: String
    var delta: Int
    var before: Int
    var after: Int
    var source: String
    var duration: String
}

struct Verification: Identifiable, Hashable {
    let id: String
    var sport: Sport
    var from: String
    var mode: String
    var score: String
    var games: [Int]
    var date: String
    var venue: String
    var delta: Int
    var partner: String?
}

// MARK: - Group-sport calendar

struct SquadResult: Hashable {
    var outcome: String     // Won / Lost / Drawn
    var score: String
}

struct SquadEvent: Identifiable, Hashable {
    let id: String
    var sport: Sport
    var title: String
    var team: String
    var opponent: String
    var date: String
    var start: String
    var end: String
    var venue: String
    var result: SquadResult?
}

// MARK: - Notifications

enum NotifKind: String, Hashable {
    case connect, challenge, verify, rating, peer
}

struct Notif: Identifiable, Hashable {
    let id: String
    var who: String
    var kind: NotifKind
    var text: String
    var time: String
    var unread: Bool
}

// MARK: - Communities

struct Community: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let sport: Sport
    let kind: String
    let members: Int
    let dist: Double
    let courts: Int?
}

// MARK: - Me

struct Me: Hashable {
    var name: String = ""
    var username: String = ""
    var age: String = ""
    var gender: String = ""
    var av: Int = 0
}

// MARK: - One row on the shared weekly calendar

struct CalendarItem: Identifiable, Hashable {
    /// Unique per drawn block: a tentative challenge draws one per slot.
    let id: String
    /// The id of the underlying challenge or event, for opening details.
    let sourceID: String
    let isEvent: Bool
    let sport: Sport
    let date: String
    let start: String
    let end: String
    let label: String
    let tentative: Bool
}

// MARK: - Static content

enum Catalog {
    static let names = [
        "Tyler Brooks","Priya Raghavan","Marcus Idowu","Elena Vasquez","Dev Sharma","Hannah Kim",
        "Omar Haddad","Grace Nolan","Ravi Menon","Sofia Bianchi","Jamal Carter","Aisha Rahman",
        "Leo Fischer","Nina Petrova","Chris Okafor","Maya Lindqvist","Arjun Patel","Zoe Bennett",
        "Kenji Watanabe","Laura Mendes","Tomas Novak","Ivy Chen","Daniel Osei","Farah Aziz",
        "Ethan Wallace","Anika Desai","Pablo Herrera","Rachel Stone","Yusuf Demir","Clara Ferreira",
        "Nathan Wu","Simran Kaur","Andre Dubois","Bella Rossi","Kwame Boateng","Hana Suzuki",
        "Victor Almeida","Tara Sullivan","Rohit Verma","Julia Novakova","Sam Whitfield","Noor Al-Sayed"
    ]

    static let venues = [
        "Riverside Courts","Meadow Park Center","Lakeview Athletic Club","Cedar Street Gym",
        "Northgate Recreation","Harbour Point Courts","Willow Creek Complex","Fairmont Community Hall"
    ]

    static let bios = [
        "Weekend competitor who plays for the rallies and stays for the coffee afterwards.",
        "Former college athlete easing back into competitive play. Always up for a friendly set.",
        "Plays three evenings a week and enjoys coaching newer players.",
        "Casual player chasing consistency more than trophies.",
        "Doubles specialist looking for a steady partner across the season."
    ]

    static let snippets = [
        "Are we still on for Thursday?","Good game earlier, that last rally was brutal.",
        "I booked court three for 7 PM.","Bring the spare paddle if you can.",
        "My rating finally moved. Thanks for the practice.","Rain check on Saturday? The forecast looks rough.",
        "Let me know when you want a rematch.","Nice win. You have improved a lot this month."
    ]

    /// Start times a challenge slot can take, on the 24-hour clock the
    /// calendar works in.
    static let slotTimes = ["07:00","08:00","09:00","10:00","11:00","12:00","13:00","15:00",
                            "16:00","17:00","18:00","18:30","19:00","19:30","20:00","20:30","21:00"]

    static let communities: [Community] = [
        Community(name: "Riverside Pickleball Club", sport: .pickleball, kind: "Club",     members: 64,  dist: 1.2, courts: nil),
        Community(name: "Meadow Park Open League",   sport: .pickleball, kind: "League",   members: 128, dist: 2.6, courts: nil),
        Community(name: "Northgate Courts",          sport: .pickleball, kind: "Facility", members: 0,   dist: 0.9, courts: 8),
        Community(name: "Sunrise Doubles Ladder",    sport: .pickleball, kind: "Ladder",   members: 46,  dist: 3.4, courts: nil),
        Community(name: "Thursday Badminton Social", sport: .badminton,  kind: "Club",     members: 38,  dist: 2.4, courts: nil),
        Community(name: "City Shuttle League",       sport: .badminton,  kind: "League",   members: 92,  dist: 4.1, courts: nil),
        Community(name: "Cedar Street Sports Hall",  sport: .badminton,  kind: "Facility", members: 0,   dist: 1.6, courts: 6),
        Community(name: "Winter Doubles Series",     sport: .badminton,  kind: "Ladder",   members: 31,  dist: 2.9, courts: nil),
        Community(name: "Cedar Street Ping Pong",    sport: .pingpong,   kind: "Club",     members: 27,  dist: 0.8, courts: nil),
        Community(name: "Lunchtime Table League",    sport: .pingpong,   kind: "League",   members: 54,  dist: 1.4, courts: nil),
        Community(name: "Harbour Point Rec Centre",  sport: .pingpong,   kind: "Facility", members: 0,   dist: 2.2, courts: 10),
        Community(name: "Sunday Cricket League",     sport: .cricket,    kind: "League",   members: 96,  dist: 3.1, courts: nil),
        Community(name: "Riverside XI",              sport: .cricket,    kind: "Club",     members: 22,  dist: 1.1, courts: nil),
        Community(name: "Fairmont Cricket Ground",   sport: .cricket,    kind: "Facility", members: 0,   dist: 4.4, courts: 2),
        Community(name: "Midweek T20 Cup",           sport: .cricket,    kind: "Cup",      members: 64,  dist: 5.2, courts: nil),
        Community(name: "Northgate Five-a-side",     sport: .soccer,     kind: "League",   members: 71,  dist: 1.9, courts: nil),
        Community(name: "Willow Creek FC",           sport: .soccer,     kind: "Club",     members: 34,  dist: 2.7, courts: nil),
        Community(name: "Lakeview 3G Pitches",       sport: .soccer,     kind: "Facility", members: 0,   dist: 1.3, courts: 4),
        Community(name: "Harbour Point Volleyball",  sport: .volleyball, kind: "Club",     members: 52,  dist: 2.8, courts: nil),
        Community(name: "Beach Doubles Series",      sport: .volleyball, kind: "League",   members: 40,  dist: 5.6, courts: nil),
        Community(name: "Meadow Park Sand Courts",   sport: .volleyball, kind: "Facility", members: 0,   dist: 3.3, courts: 5)
    ]

    /// The 42 simulated players. Generated exactly as the web build does, so
    /// the same person has the same rating, sports and avatar in both.
    static let allPlayers: [Player] = (0..<42).map { i in
        let name = names[i % names.count]
        let rating = 62 + ((i * 13) % 78)
        let all = Sport.allCases
        var sports = [all[i % 6], all[(i + 2) % 6]]
        if sports[0] == sports[1] { sports = [sports[0]] }
        return Player(
            id: "p\(i)",
            name: name,
            av: i % 50,
            rating: rating,
            username: "@" + (name.split(separator: " ").first.map(String.init) ?? "").lowercased() + "\(10 + i % 80)",
            age: 19 + (i % 26),
            gender: ["Male", "Female", "Non-binary"][i % 3],
            dist: String(format: "%.1f", 0.4 + Double((i * 7) % 110) / 10),
            bio: bios[i % bios.count],
            sports: sports,
            ratings: [.pickleball: rating,
                      .badminton: max(60, rating - 9),
                      .pingpong: max(60, rating - 6)],
            mutual: 1 + (i % 9)
        )
    }

    static func player(_ id: String) -> Player {
        allPlayers.first { $0.id == id } ?? allPlayers[0]
    }
}
