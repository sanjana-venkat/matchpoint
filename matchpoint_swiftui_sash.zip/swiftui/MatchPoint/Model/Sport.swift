//  Sport.swift
//  The six sports and their permanent palettes.
//
//  Colour is information in this product, not decoration: a green block is
//  pickleball everywhere, always. The web build achieves that by rewriting
//  four CSS custom properties when the active sport changes; here the same
//  job is done by reading `Palette` off the active sport.

import SwiftUI

enum Sport: String, CaseIterable, Identifiable, Codable, Hashable {
    case pickleball, badminton, pingpong, cricket, soccer, volleyball

    var id: String { rawValue }

    var name: String {
        switch self {
        case .pickleball: return "Pickleball"
        case .badminton:  return "Badminton"
        case .pingpong:   return "Ping Pong"
        case .cricket:    return "Cricket"
        case .soccer:     return "Soccer"
        case .volleyball: return "Volleyball"
        }
    }

    /// Individual sports run on challenges, uploaded scores and the MP
    /// Rating. Group sports run on a shared squad calendar and peer reviews,
    /// because a squad of eleven cannot agree a ladder.
    var isIndividual: Bool {
        switch self {
        case .pickleball, .badminton, .pingpong: return true
        case .cricket, .soccer, .volleyball:     return false
        }
    }

    var colourName: String {
        switch self {
        case .pickleball: return "Light green"
        case .badminton:  return "Light blue"
        case .pingpong:   return "Light orange"
        case .cricket:    return "Light red"
        case .soccer:     return "Green"
        case .volleyball: return "Purple"
        }
    }

    var palette: Palette {
        switch self {
        case .pickleball: return Palette(accent: "#4CA85F", mid: "#8FD3A0", soft: "#EFF8F1", line: "#CFEBD6")
        case .badminton:  return Palette(accent: "#3D82C4", mid: "#9AC4EC", soft: "#ECF3FB", line: "#C9DFF5")
        case .pingpong:   return Palette(accent: "#D0762F", mid: "#F2BE93", soft: "#FDF3E9", line: "#F7DCC2")
        case .cricket:    return Palette(accent: "#CE5555", mid: "#EFA0A0", soft: "#FCEEEE", line: "#F5D0D0")
        case .soccer:     return Palette(accent: "#2F7A50", mid: "#85C2A0", soft: "#EAF5EF", line: "#C2E0CF")
        case .volleyball: return Palette(accent: "#7857BE", mid: "#B7A0E6", soft: "#F3EEFC", line: "#DED0F6")
        }
    }

    /// The categories teammates rate you on. Empty for individual sports.
    var peerSkills: [String] {
        switch self {
        case .cricket:    return ["Batting", "Bowling", "Fielding"]
        case .soccer:     return ["Attacking", "Passing", "Defending"]
        case .volleyball: return ["Serving", "Setting", "Blocking"]
        default:          return []
        }
    }

    static let individual: [Sport] = [.pickleball, .badminton, .pingpong]
    static let group: [Sport] = [.cricket, .soccer, .volleyball]
}

struct Palette {
    let accentHex: String, midHex: String, softHex: String, lineHex: String

    init(accent: String, mid: String, soft: String, line: String) {
        self.accentHex = accent; self.midHex = mid
        self.softHex = soft; self.lineHex = line
    }

    var accent: Color { Color(hex: accentHex) }
    var mid: Color    { Color(hex: midHex) }
    var soft: Color   { Color(hex: softHex) }
    var line: Color   { Color(hex: lineHex) }
}

// MARK: - Long-form copy

enum Copy {
    static let rating: [String] = [
        "The MP Rating is a single number that describes your current level in this sport. Everyone starts at 80. After each verified match the number moves in small, proportional steps, so one result never swings your level dramatically.",
        "Beating an evenly matched opponent earns one or two points. Beating someone rated above you earns three. A win against a significantly stronger opponent earns four or five. Losses move the same amounts in the opposite direction, and the size of every change depends on the gap between the two ratings.",
        "Your rating decides which players are recommended to you on the map and on your home screen, so keeping it accurate is what makes matchmaking feel fair."
    ]

    static let optOut: [String] = [
        "You can opt out of the MP Rating for any individual sport from Manage your sports. Your matches still appear in your history and on your calendar, and you can still challenge people and log scores.",
        "What changes is that no number is calculated or shown, and you stop appearing in rating-filtered searches. You can opt back in at any time, and your rating resumes from where it left off."
    ]

    static func peer(_ sport: Sport) -> String {
        switch sport {
        case .cricket:
            return "Cricket does not use a numerical MP Rating. After every match, the players you shared a pitch with rate you out of five stars on Batting, Bowling, and Fielding. Your profile shows the rolling average of those three categories, so an all-rounder and a specialist bowler both get a fair picture. Ratings only count once at least three teammates have submitted them, which keeps a single bad afternoon from defining you."
        case .soccer:
            return "Soccer uses peer evaluation instead of a numerical MP Rating. Teammates and opponents rate you out of five stars on Attacking, Passing, and Defending after the final whistle. The rolling average is shown on your profile so a Sunday league captain can see where you actually contribute."
        case .volleyball:
            return "Volleyball relies on post-match peer skill evaluations. Everyone on court rates you out of five stars on Serving, Setting, and Blocking. Because rotations move players through every position, the three-category split gives a much fairer read than one combined number."
        default:
            return ""
        }
    }
}
