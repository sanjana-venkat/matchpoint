//  AppState.swift
//  The whole product in one observable object: the data, the selectors that
//  scope it to the active sport, and every action the interface can take.
//
//  This is a direct port of the JavaScript state layer. The rules it encodes
//  are the product:
//    · one sport is active at a time and almost everything scopes to it
//    · there is exactly one social action, Connect, and it opens a chat
//    · nobody can be challenged until they have replied at least once
//    · a challenge offers up to three times and is answered from the chat
//    · one weekly calendar holds every booking, whatever the sport

import SwiftUI
import Observation

enum Tab: String, Hashable, CaseIterable { case home, map, matches, chats, profile }
enum Screen: Hashable { case onboarding, main, chat, victory }
enum MatchTab: String, Hashable { case past, upcoming }
enum CalTab: String, Hashable { case week, past }
enum ChatTab: String, Hashable { case chats, requests }

/// Every overlay the app can present. The web build kept one `V.layer`
/// object; an enum gives the same single-overlay-at-a-time behaviour with
/// the cases spelled out.
enum Layer: Identifiable, Hashable {
    case sportSwitcher, exitIntent
    case readMore(Sport)
    case challenge(opponent: String?)
    case challengeDetail(String)
    case verifyDetail(String)
    case connectReqDetail(String)
    case score
    case matchDetail(String)
    case drawer(String)
    case addEvent
    case eventDetail(String)
    case addResult(String)
    case review
    case filter(String)
    case notifications
    case editProfile, manageSports, privacy, notifPrefs

    var id: String {
        switch self {
        case .sportSwitcher:            return "sportSwitcher"
        case .exitIntent:               return "exitIntent"
        case .readMore(let s):          return "readMore-\(s.rawValue)"
        case .challenge(let o):         return "challenge-\(o ?? "")"
        case .challengeDetail(let i):   return "challengeDetail-\(i)"
        case .verifyDetail(let i):      return "verifyDetail-\(i)"
        case .connectReqDetail(let i):  return "connectReq-\(i)"
        case .score:                    return "score"
        case .matchDetail(let i):       return "matchDetail-\(i)"
        case .drawer(let i):            return "drawer-\(i)"
        case .addEvent:                 return "addEvent"
        case .eventDetail(let i):       return "eventDetail-\(i)"
        case .addResult(let i):         return "addResult-\(i)"
        case .review:                   return "review"
        case .filter(let w):            return "filter-\(w)"
        case .notifications:            return "notifications"
        case .editProfile:              return "editProfile"
        case .manageSports:             return "manageSports"
        case .privacy:                  return "privacy"
        case .notifPrefs:               return "notifPrefs"
        }
    }

    /// Sheets that hold an unsaved draft, and so trigger the exit guard.
    var holdsDraft: Bool {
        switch self {
        case .challenge, .score, .editProfile, .addEvent, .addResult, .review: return true
        default: return false
        }
    }
}

// MARK: - Drafts

struct ChallengeDraft {
    var opp: String
    var sport: Sport
    var venue: String
    var slots: [Slot]
}

struct ScoreDraft {
    var mode = "Singles"
    var sport: Sport = .pickleball
    var partner = ""
    var opp1 = ""
    var opp2 = ""
    var count = 3
    var results = [1, 1, 0]
    var venue = Catalog.venues[0]
}

struct EventDraft {
    var title = "League fixture"
    var team = "Riverside XI"
    var opponent = ""
    var date = MPDate.iso(MPDate.today)
    var start = "18:00"
    var end = "20:00"
    var venue = Catalog.venues[0]

    var isComplete: Bool {
        !title.trimmingCharacters(in: .whitespaces).isEmpty &&
        !team.trimmingCharacters(in: .whitespaces).isEmpty &&
        !opponent.trimmingCharacters(in: .whitespaces).isEmpty
    }
}

struct ResultDraft { var outcome = "Won"; var score = "" }
struct ReviewDraft { var who = ""; var scores: [String: Int] = [:] }
struct OnboardDraft {
    var name = "", username = "", age = "", gender = ""
    var av = 0
    var sports: [Sport] = []
    var optOut: [Sport: Bool] = [:]
    var isComplete: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        !username.trimmingCharacters(in: .whitespaces).isEmpty &&
        !age.trimmingCharacters(in: .whitespaces).isEmpty &&
        !gender.isEmpty
    }
}

struct VictorySummary { var won = false; var score = ""; var before = 0; var delta = 0; var after = 0 }

struct MapFilters: Equatable { var gender = "Any"; var rating = "Any" }

// MARK: - The state

@Observable
final class AppState {

    // ---- data ----
    var me = Me()
    var onboarded = true
    var sports: [Sport] = []
    var optOut: [Sport: Bool] = [:]
    var connections: [String] = []
    var threads: [ChatThread] = []
    var msgRequests: [MsgRequest] = []
    var verifications: [Verification] = []
    var upcoming: [Challenge] = []
    var past: [PastMatch] = []
    var calendar: [SquadEvent] = []
    var ratings: [Sport: Int] = [:]
    var peer: [Sport: [String: Double]] = [:]
    var notifications: [Notif] = []

    // ---- view state ----
    var tab: Tab = .home
    var screen: Screen = .main
    var ob = 0
    var activeSport: Sport = .pickleball
    var fabOpen = false
    var layer: Layer?
    var dirty = false
    var dirtyLabel = ""
    var pendingSport: Sport?
    var chatWith: String?
    var matchTab: MatchTab = .upcoming
    var calTab: CalTab = .week
    var weekOffset = 0
    var chatTab: ChatTab = .chats
    var searchQuery = ""
    var mapFilters = MapFilters()
    var lastVictory: VictorySummary?
    var toast: String?
    var msgBox = ""

    // ---- drafts ----
    var chDraft: ChallengeDraft?
    var scDraft: ScoreDraft?
    var evDraft: EventDraft?
    var resDraft: ResultDraft?
    var revDraft: ReviewDraft?
    var obDraft = OnboardDraft()

    init() { loadVeteran() }

    // MARK: - Seeds

    /// A brand new account, which starts in onboarding.
    func loadNewUser() {
        me = Me(); onboarded = false; sports = []; optOut = [:]
        connections = []; threads = []; msgRequests = []; verifications = []
        upcoming = []; past = []; calendar = []
        ratings = [:]; peer = [:]; notifications = []
        obDraft = OnboardDraft()
        screen = .onboarding; ob = 0; tab = .home
        activeSport = .pickleball; layer = nil; fabOpen = false
        clearDirty()
    }

    /// The veteran account the app boots into.
    func loadVeteran() {
        me = Me(name: "Sasshh", username: "@sashpash", age: "25", gender: "Male", av: 0)
        onboarded = true
        sports = [.pickleball, .badminton, .cricket]
        optOut = [:]

        // Everything social starts from a message, so this is the only
        // social list there is.
        connections = Catalog.allPlayers.prefix(10).map(\.id)

        verifications = [
            Verification(id: "v1", sport: .pickleball, from: "p3",  mode: "Singles", score: "2-1 games", games: [1,1,0],   date: "Aug 10, 2026", venue: Catalog.venues[0], delta: 2,  partner: nil),
            Verification(id: "v2", sport: .pickleball, from: "p11", mode: "Doubles", score: "1-2 games", games: [0,1,0],   date: "Aug 9, 2026",  venue: Catalog.venues[1], delta: -2, partner: "p6"),
            Verification(id: "v3", sport: .pickleball, from: "p14", mode: "Singles", score: "2-0 games", games: [1,1],     date: "Aug 8, 2026",  venue: Catalog.venues[5], delta: 2,  partner: nil),
            Verification(id: "v4", sport: .badminton,  from: "p7",  mode: "Doubles", score: "3-1 games", games: [1,0,1,1], date: "Aug 9, 2026",  venue: Catalog.venues[2], delta: 3,  partner: "p2"),
            Verification(id: "v5", sport: .badminton,  from: "p9",  mode: "Singles", score: "0-2 games", games: [0,0],     date: "Aug 7, 2026",  venue: Catalog.venues[3], delta: -2, partner: nil)
        ]

        let c2Slots = [Slot(date: "2026-08-13", start: "19:00", end: "20:30"),
                       Slot(date: "2026-08-15", start: "09:00", end: "10:30"),
                       Slot(date: "2026-08-16", start: "11:00", end: "12:30")]
        let c7Slots = [Slot(date: "2026-08-11", start: "20:30", end: "22:00"),
                       Slot(date: "2026-08-14", start: "20:00", end: "21:30")]

        threads = Catalog.allPlayers.prefix(9).enumerated().map { i, p in
            var msgs: [Message]
            if i == 8 {
                msgs = [Message(me: true, text: "Hi, I play at Riverside most evenings. Fancy a hit some time?", time: "4:02 PM")]
            } else {
                msgs = [
                    Message(me: false, text: Catalog.snippets[(i * 3) % Catalog.snippets.count], time: "6:12 PM"),
                    Message(me: true,  text: "Works for me. I will bring an extra set of balls.", time: "6:20 PM"),
                    Message(me: false, text: Catalog.snippets[(i * 3 + 1) % Catalog.snippets.count], time: "6:41 PM")
                ]
                // A challenge sits inside the conversation it came from.
                if i == 6 {
                    msgs.append(Message(me: true, text: "", time: "8:22 PM",
                        challenge: ChallengeProposal(cid: "c2", sport: .pickleball, venue: Catalog.venues[6],
                                                     slots: c2Slots, chosen: nil, declined: false)))
                }
                if i == 5 {
                    msgs.append(Message(me: false, text: "", time: "7:04 PM",
                        challenge: ChallengeProposal(cid: "c7", sport: .badminton, venue: Catalog.venues[2],
                                                     slots: c7Slots, chosen: nil, declined: false)))
                }
            }
            return ChatThread(id: "t\(i)", with: p.id, unread: i < 3 ? i + 1 : 0, pending: i == 8, msgs: msgs)
        }

        msgRequests = [
            MsgRequest(id: "r1", with: "p12", hrs: 3,  text: "Hey, I saw your profile on the map. Fancy a game this weekend?"),
            MsgRequest(id: "r2", with: "p18", hrs: 9,  text: "We played in the Riverside ladder last year. Up for a rematch?"),
            MsgRequest(id: "r3", with: "p24", hrs: 16, text: "Saw your rating on the map. Would love a hit if you are free midweek."),
            MsgRequest(id: "r4", with: "p22", hrs: 30, text: "Do you ever play doubles? I have a partner but we need a second pair."),
            MsgRequest(id: "r5", with: "p31", hrs: 5,  text: "I am new to the area and looking for regular hitting partners."),
            MsgRequest(id: "r6", with: "p35", hrs: 12, text: "Your club runs a Thursday ladder, is that right? I would like to join."),
            MsgRequest(id: "r7", with: "p29", hrs: 40, text: "Happy to travel if you have a court booked. I am free most evenings."),
            MsgRequest(id: "r8", with: "p27", hrs: 7,  text: "We are a player short for Saturday. Any chance you are free?")
        ]

        upcoming = [
            Challenge(id: "c1", sport: .pickleball, opp: "p0", venue: Catalog.venues[0], status: .confirmed, from: nil,
                      slots: [Slot(date: "2026-08-12", start: "18:30", end: "20:00")]),
            Challenge(id: "c6", sport: .pickleball, opp: "p4", venue: Catalog.venues[4], status: .confirmed, from: nil,
                      slots: [Slot(date: "2026-08-14", start: "17:00", end: "18:30")]),
            Challenge(id: "c2", sport: .pickleball, opp: "p6", venue: Catalog.venues[6], status: .tentative, from: "me", slots: c2Slots),
            Challenge(id: "c3", sport: .badminton,  opp: "p1", venue: Catalog.venues[2], status: .confirmed, from: nil,
                      slots: [Slot(date: "2026-08-13", start: "19:45", end: "21:00")]),
            Challenge(id: "c8", sport: .badminton,  opp: "p7", venue: Catalog.venues[2], status: .confirmed, from: nil,
                      slots: [Slot(date: "2026-08-16", start: "10:00", end: "11:30")]),
            Challenge(id: "c7", sport: .badminton,  opp: "p5", venue: Catalog.venues[2], status: .tentative, from: "them", slots: c7Slots)
        ]

        past = [
            PastMatch(id: "m1", sport: .pickleball, opp: "p3",  partner: nil,  mode: "Singles", games: [1,1,0],   won: true,  score: "2-1 games", date: "Aug 6, 2026",  venue: Catalog.venues[0], delta: 2,  before: 123, after: 125, source: "Scheduled match", duration: "52 min"),
            PastMatch(id: "m2", sport: .badminton,  opp: "p7",  partner: "p2", mode: "Doubles", games: [1,0,1,1], won: true,  score: "3-1 games", date: "Aug 3, 2026",  venue: Catalog.venues[2], delta: 3,  before: 118, after: 121, source: "Manually uploaded score", duration: "1 hr 08 min"),
            PastMatch(id: "m3", sport: .pickleball, opp: "p11", partner: nil,  mode: "Singles", games: [0,1,0],   won: false, score: "1-2 games", date: "Jul 29, 2026", venue: Catalog.venues[1], delta: -2, before: 125, after: 123, source: "Scheduled match", duration: "47 min"),
            PastMatch(id: "m5", sport: .badminton,  opp: "p9",  partner: nil,  mode: "Singles", games: [1,1],     won: true,  score: "2-0 games", date: "Jul 21, 2026", venue: Catalog.venues[3], delta: 2,  before: 116, after: 118, source: "Manually uploaded score", duration: "38 min"),
            PastMatch(id: "m6", sport: .pickleball, opp: "p14", partner: "p6", mode: "Doubles", games: [1,0,1],   won: true,  score: "2-1 games", date: "Jul 18, 2026", venue: Catalog.venues[5], delta: 1,  before: 122, after: 123, source: "Scheduled match", duration: "1 hr 02 min")
        ]

        calendar = [
            SquadEvent(id: "e1", sport: .cricket, title: "League fixture",   team: "Riverside XI", opponent: "Cedar Street CC",   date: "2026-08-01", start: "10:00", end: "13:00", venue: Catalog.venues[4], result: SquadResult(outcome: "Won",  score: "Won by 24 runs")),
            SquadEvent(id: "e2", sport: .cricket, title: "Friendly",         team: "Riverside XI", opponent: "Meadow Park CC",    date: "2026-08-05", start: "17:30", end: "20:00", venue: Catalog.venues[1], result: SquadResult(outcome: "Lost", score: "Lost by 3 wickets")),
            SquadEvent(id: "e3", sport: .cricket, title: "Cup quarter-final", team: "Riverside XI", opponent: "Northgate Nomads", date: "2026-08-09", start: "11:00", end: "14:30", venue: Catalog.venues[7], result: nil),
            SquadEvent(id: "e4", sport: .cricket, title: "League fixture",   team: "Riverside XI", opponent: "Harbour Point CC",  date: "2026-08-13", start: "18:00", end: "20:30", venue: Catalog.venues[4], result: nil),
            SquadEvent(id: "e5", sport: .cricket, title: "Net practice",     team: "Riverside XI", opponent: "Squad session",     date: "2026-08-11", start: "19:00", end: "20:30", venue: Catalog.venues[3], result: nil),
            SquadEvent(id: "e6", sport: .cricket, title: "League fixture",   team: "Riverside XI", opponent: "Willow Creek CC",   date: "2026-08-16", start: "09:30", end: "13:00", venue: Catalog.venues[6], result: nil),
            SquadEvent(id: "e7", sport: .cricket, title: "Away fixture",     team: "Riverside XI", opponent: "Fairmont CC",       date: "2026-08-22", start: "14:00", end: "17:00", venue: Catalog.venues[7], result: nil)
        ]

        ratings = [.pickleball: 125, .badminton: 121]
        peer = [.cricket: ["Batting": 4.5, "Bowling": 4.0, "Fielding": 4.5]]

        notifications = [
            Notif(id: "n1", who: "p12", kind: .connect,   text: "wants to connect and sent you a message.",                    time: "3h", unread: true),
            Notif(id: "n2", who: "p1",  kind: .challenge, text: "accepted your challenge for Wednesday at 6:30 PM.",           time: "5h", unread: true),
            Notif(id: "n3", who: "p3",  kind: .verify,    text: "uploaded a score from Riverside Courts and needs your verification.", time: "1d", unread: true),
            Notif(id: "n4", who: "p13", kind: .challenge, text: "proposed two times for a Badminton match.",                   time: "1d", unread: true),
            Notif(id: "n5", who: "p7",  kind: .rating,    text: "lost to you, and your rating moved to 125.",                  time: "3d", unread: false),
            Notif(id: "n6", who: "p24", kind: .connect,   text: "is waiting on a reply in your requests.",                     time: "5d", unread: false),
            Notif(id: "n7", who: "p5",  kind: .peer,      text: "rated your Cricket performance after the last match.",        time: "1w", unread: false)
        ]

        screen = .main; tab = .home; activeSport = .pickleball
        layer = nil; fabOpen = false; chatWith = nil
        matchTab = .upcoming; calTab = .week; weekOffset = 0
        chatTab = .chats; searchQuery = ""; mapFilters = MapFilters()
        clearDirty()
    }

    // MARK: - Derived

    var activeSports: [Sport] { sports.isEmpty ? [.pickleball] : sports }
    var pal: Palette { activeSport.palette }
    var groupMode: Bool { !activeSport.isIndividual }
    var unreadNotifs: Int { notifications.filter(\.unread).count }

    func myRating(_ sport: Sport) -> Int? {
        if optOut[sport] == true { return nil }
        if let r = ratings[sport] { return r }
        return sport.isIndividual ? 80 : nil
    }

    // ---- sport-scoped selectors ----
    var sportUpcoming: [Challenge] { upcoming.filter { $0.sport == activeSport } }
    var sportPast: [PastMatch] { past.filter { $0.sport == activeSport } }
    var sportVerifications: [Verification] { verifications.filter { $0.sport == activeSport } }
    var sportEvents: [SquadEvent] { calendar.filter { $0.sport == activeSport } }

    func isConnected(_ id: String) -> Bool { connections.contains(id) }
    var sportConnections: [String] { connections.filter { Catalog.player($0).sports.contains(activeSport) } }
    var sportThreads: [ChatThread] { threads.filter { Catalog.player($0.with).sports.contains(activeSport) } }
    var sportMsgRequests: [MsgRequest] { msgRequests.filter { Catalog.player($0.with).sports.contains(activeSport) } }
    var recentMsgRequests: [MsgRequest] { sportMsgRequests.filter { $0.hrs < 24 } }

    func thread(with id: String) -> ChatThread? { threads.first { $0.with == id } }
    /// No challenges until the other player has written back.
    func canChallenge(_ id: String) -> Bool {
        guard let t = thread(with: id) else { return false }
        return !t.pending
    }

    var pendingResults: [SquadEvent] {
        sportEvents.filter { $0.result == nil && MPDate.date(fromISO: $0.date) < MPDate.today }
    }

    var communities: [Community] { Catalog.communities.filter { $0.sport == activeSport } }

    /// Everyone's bookings on one grid, whatever the sport. A tentative
    /// challenge draws every slot it proposed until one is picked.
    var calendarItems: [CalendarItem] {
        var out: [CalendarItem] = []
        for e in calendar {
            out.append(CalendarItem(id: e.id, sourceID: e.id, isEvent: true, sport: e.sport,
                                    date: e.date, start: e.start, end: e.end,
                                    label: e.opponent, tentative: false))
        }
        for c in upcoming {
            let nm = Catalog.player(c.opp).name
            if c.status == .tentative {
                for (i, s) in c.slots.enumerated() {
                    out.append(CalendarItem(id: "\(c.id)-\(i)", sourceID: c.id, isEvent: false, sport: c.sport,
                                            date: s.date, start: s.start, end: s.end,
                                            label: nm, tentative: true))
                }
            } else if let s = c.slots.first {
                out.append(CalendarItem(id: c.id, sourceID: c.id, isEvent: false, sport: c.sport,
                                        date: s.date, start: s.start, end: s.end,
                                        label: nm, tentative: false))
            }
        }
        return out
    }

    // MARK: - Navigation

    func goTab(_ t: Tab) { tab = t; fabOpen = false; screen = .main }

    func openLayer(_ l: Layer) { layer = l; fabOpen = false }

    func closeLayer() {
        if let l = layer, l.holdsDraft {
            clearDirty(); chDraft = nil; scDraft = nil; evDraft = nil; resDraft = nil; revDraft = nil
        }
        layer = nil; pendingSport = nil
    }

    func openSportSwitcher() {
        if dirty { layer = .exitIntent; return }
        layer = .sportSwitcher; fabOpen = false
    }

    func switchSport(_ s: Sport) {
        if dirty { pendingSport = s; layer = .exitIntent; return }
        activeSport = s; layer = nil
        calTab = .week; weekOffset = 0; matchTab = .upcoming
        show("The active sport is now \(s.name).")
    }

    func discardAndSwitch() {
        chDraft = nil; scDraft = nil; evDraft = nil
        clearDirty()
        if let s = pendingSport {
            pendingSport = nil; layer = nil; activeSport = s
            show("The active sport is now \(s.name).")
        } else {
            layer = .sportSwitcher
        }
    }

    func markDirty(_ label: String) { dirty = true; dirtyLabel = label }
    func clearDirty() { dirty = false; dirtyLabel = "" }
    func show(_ msg: String) { toast = msg }

    // MARK: - Connections

    /// The one social action. It opens a conversation and drops you into it;
    /// they have to answer before either of you can send a challenge.
    func connect(with id: String) {
        var t = thread(with: id)
        if t == nil {
            let fresh = ChatThread(id: "t\(UUID().uuidString.prefix(8))", with: id,
                                   unread: 0, pending: true, msgs: [])
            threads.insert(fresh, at: 0)
            t = fresh
        }
        layer = nil
        openChat(t!.id)
    }

    func acceptMsgRequest(_ rid: String) {
        guard let r = msgRequests.first(where: { $0.id == rid }) else { return }
        msgRequests.removeAll { $0.id == rid }
        if !isConnected(r.with) { connections.append(r.with) }
        for i in notifications.indices where notifications[i].who == r.with && notifications[i].kind == .connect {
            notifications[i].unread = false
        }
        threads.insert(ChatThread(id: "t\(UUID().uuidString.prefix(8))", with: r.with, unread: 0,
                                  pending: false,
                                  msgs: [Message(me: false, text: r.text, time: "Now")]), at: 0)
        chatTab = .chats
        show("You are now connected with \(Catalog.player(r.with).name).")
    }

    func deleteMsgRequest(_ rid: String) {
        let r = msgRequests.first { $0.id == rid }
        msgRequests.removeAll { $0.id == rid }
        if let r {
            for i in notifications.indices where notifications[i].who == r.with && notifications[i].kind == .connect {
                notifications[i].unread = false
            }
        }
        show("The request has been deleted.")
    }

    // MARK: - Chat

    func openChat(_ tid: String) {
        if let i = threads.firstIndex(where: { $0.id == tid }) { threads[i].unread = 0 }
        chatWith = tid; screen = .chat; fabOpen = false; layer = nil
    }

    func sendMessage() {
        let text = msgBox.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, let tid = chatWith,
              let i = threads.firstIndex(where: { $0.id == tid }) else { return }
        let t = MPDate.nowLabel()
        let first = threads[i].pending && threads[i].msgs.isEmpty
        threads[i].msgs.append(Message(me: true, text: text, time: t))
        msgBox = ""
        if first { show("Your message is waiting in \(Catalog.player(threads[i].with).name)'s requests.") }

        // Their reply is what opens the connection and unlocks challenges.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self, let j = self.threads.firstIndex(where: { $0.id == tid }) else { return }
            self.threads[j].msgs.append(Message(me: false, text: "Sounds good. See you on court.", time: t))
            if self.threads[j].pending {
                self.threads[j].pending = false
                let who = self.threads[j].with
                if !self.isConnected(who) { self.connections.append(who) }
            }
        }
    }

    /// Picking a slot turns the proposal into a confirmed match.
    func pickSlot(threadID: String, cid: String, index: Int) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].msgs.firstIndex(where: { $0.challenge?.cid == cid }),
              let proposal = threads[ti].msgs[mi].challenge,
              index < proposal.slots.count else { return }
        threads[ti].msgs[mi].challenge?.chosen = index
        let slot = proposal.slots[index]
        if let ci = upcoming.firstIndex(where: { $0.id == cid }) {
            upcoming[ci].status = .confirmed
            upcoming[ci].slots = [slot]
            upcoming[ci].from = nil
        } else {
            upcoming.append(Challenge(id: cid, sport: proposal.sport, opp: threads[ti].with,
                                      venue: proposal.venue, status: .confirmed, from: nil, slots: [slot]))
        }
        show("Confirmed for \(MPDate.slotLabel(slot)).")
    }

    func declineSlots(threadID: String, cid: String) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].msgs.firstIndex(where: { $0.challenge?.cid == cid }) else { return }
        threads[ti].msgs[mi].challenge?.declined = true
        upcoming.removeAll { $0.id == cid }
        show("The challenge has been declined.")
    }

    // MARK: - Challenges

    static let maxSlots = 3

    func openChallenge(opponent: String? = nil) {
        let pool = sportConnections.filter(canChallenge)
        let dates = MPDate.challengeDates()
        chDraft = ChallengeDraft(
            opp: opponent ?? pool.first ?? "",
            sport: activeSport.isIndividual ? activeSport : Sport.individual[0],
            venue: Catalog.venues[0],
            slots: [Slot(date: dates.count > 1 ? dates[1] : dates[0], start: "18:30", end: "20:00")]
        )
        openLayer(.challenge(opponent: opponent))
    }

    func addSlot() {
        guard var d = chDraft, d.slots.count < Self.maxSlots else { return }
        let dates = MPDate.challengeDates()
        let used = Set(d.slots.map(\.date))
        let next = dates.first { !used.contains($0) } ?? dates[0]
        d.slots.append(Slot(date: next, start: "18:30", end: MPDate.endOf("18:30")))
        chDraft = d
        markDirty("Creating a challenge")
    }

    func removeSlot(_ i: Int) {
        guard var d = chDraft, d.slots.count > 1, i < d.slots.count else { return }
        d.slots.remove(at: i); chDraft = d
        markDirty("Creating a challenge")
    }

    func setSlot(_ i: Int, date: String? = nil, start: String? = nil) {
        guard var d = chDraft, i < d.slots.count else { return }
        if let date { d.slots[i].date = date }
        if let start { d.slots[i].start = start; d.slots[i].end = MPDate.endOf(start) }
        chDraft = d
        markDirty("Creating a challenge")
    }

    func submitChallenge() {
        guard let d = chDraft, !d.opp.isEmpty else { return }
        let slots = d.slots.map { Slot(date: $0.date, start: $0.start, end: MPDate.endOf($0.start)) }
        let cid = "c\(Int(Date().timeIntervalSince1970 * 1000))"
        let time = MPDate.nowLabel()
        let msg = Message(me: true, text: "", time: time,
                          challenge: ChallengeProposal(cid: cid, sport: d.sport, venue: d.venue,
                                                       slots: slots, chosen: nil, declined: false))
        let tid: String
        if let i = threads.firstIndex(where: { $0.with == d.opp }) {
            threads[i].msgs.append(msg); tid = threads[i].id
        } else {
            tid = "t\(UUID().uuidString.prefix(8))"
            threads.insert(ChatThread(id: tid, with: d.opp, unread: 0, pending: false, msgs: [msg]), at: 0)
        }
        upcoming.append(Challenge(id: cid, sport: d.sport, opp: d.opp, venue: d.venue,
                                  status: .tentative, from: "me", slots: slots))
        show("\(slots.count) time\(slots.count == 1 ? "" : "s") sent to \(Catalog.player(d.opp).name).")
        chDraft = nil; clearDirty(); layer = nil
        activeSport = d.sport
        openChat(tid)
    }

    func removeChallenge(_ id: String) {
        guard let c = upcoming.first(where: { $0.id == id }) else { return }
        upcoming.removeAll { $0.id == id }
        for ti in threads.indices {
            for mi in threads[ti].msgs.indices where threads[ti].msgs[mi].challenge?.cid == id {
                threads[ti].msgs[mi].challenge?.declined = true
            }
        }
        show("The challenge with \(Catalog.player(c.opp).name) has been withdrawn.")
    }

    // MARK: - Scores and verification

    func openScore() {
        let pool = sportConnections.isEmpty
            ? Catalog.allPlayers.filter { $0.sports.contains(activeSport) }.map(\.id)
            : sportConnections
        var d = ScoreDraft()
        d.sport = activeSport.isIndividual ? activeSport : Sport.individual[0]
        d.opp1 = pool.first ?? ""
        d.partner = pool.count > 1 ? pool[1] : (pool.first ?? "")
        d.opp2 = pool.count > 2 ? pool[2] : (pool.first ?? "")
        scDraft = d
        openLayer(.score)
    }

    func submitScore() {
        guard let d = scDraft else { return }
        let games = Array(d.results.prefix(d.count))
        let myWins = games.filter { $0 == 1 }.count
        let theirWins = d.count - myWins
        let won = myWins > theirWins
        let opp = Catalog.player(d.opp1)
        let before = myRating(d.sport)
        var delta = 0
        var after = before ?? 0
        if let b = before {
            delta = ratingDelta(mine: b, theirs: opp.rating(for: d.sport), won: won)
            after = b + delta
        }
        past.insert(PastMatch(id: "m\(Int(Date().timeIntervalSince1970 * 1000))",
                              sport: d.sport, opp: d.opp1,
                              partner: d.mode == "Doubles" ? d.partner : nil,
                              mode: d.mode, games: games, won: won,
                              score: "\(myWins)-\(theirWins) games",
                              date: "Aug 10, 2026", venue: d.venue, delta: delta,
                              before: before ?? 0, after: after,
                              source: "Manually uploaded score",
                              duration: "\(34 + d.count * 9) min"), at: 0)
        if before != nil { ratings[d.sport] = after }
        lastVictory = VictorySummary(won: won, score: "\(myWins)-\(theirWins) games",
                                     before: before ?? 0, delta: delta, after: after)
        activeSport = d.sport
        scDraft = nil; clearDirty(); layer = nil
        show("A verification prompt has been sent to \(opp.name).")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { [weak self] in
            self?.screen = .victory
        }
    }

    func resolveVerification(_ id: String, confirm: Bool) {
        guard let v = verifications.first(where: { $0.id == id }) else { return }
        verifications.removeAll { $0.id == id }
        if confirm {
            let before = myRating(v.sport)
            let won = v.games.filter { $0 == 1 }.count > v.games.filter { $0 == 0 }.count
            if let b = before { ratings[v.sport] = b + v.delta }
            past.insert(PastMatch(id: "m\(Int(Date().timeIntervalSince1970 * 1000))",
                                  sport: v.sport, opp: v.from, partner: v.partner,
                                  mode: v.mode, games: v.games, won: won, score: v.score,
                                  date: v.date, venue: v.venue, delta: v.delta,
                                  before: before ?? 0, after: (before ?? 0) + v.delta,
                                  source: "Verified score", duration: "48 min"), at: 0)
            show("The result against \(Catalog.player(v.from).name) has been confirmed.")
        } else {
            show("Your dispute has been sent to \(Catalog.player(v.from).name).")
        }
        layer = nil
    }

    // MARK: - Squad calendar

    func openAddEvent() { evDraft = EventDraft(); openLayer(.addEvent) }

    func submitEvent() {
        guard let d = evDraft, d.isComplete else {
            show("Please complete every required field."); return
        }
        guard MPDate.minutes(d.end) > MPDate.minutes(d.start) else {
            show("The finish time must be after the start time."); return
        }
        calendar.append(SquadEvent(id: "e\(Int(Date().timeIntervalSince1970 * 1000))",
                                   sport: activeSport, title: d.title.trimmingCharacters(in: .whitespaces),
                                   team: d.team.trimmingCharacters(in: .whitespaces),
                                   opponent: d.opponent.trimmingCharacters(in: .whitespaces),
                                   date: d.date, start: d.start, end: d.end,
                                   venue: d.venue, result: nil))
        evDraft = nil; clearDirty(); layer = nil
        tab = .matches; calTab = .week
        let target = MPDate.startOfWeek(0)
        let chosen = MPDate.date(fromISO: d.date)
        let days = Calendar(identifier: .gregorian)
            .dateComponents([.day], from: target, to: chosen).day ?? 0
        weekOffset = Int(floor(Double(days) / 7.0))
        show("The fixture has been added to your calendar.")
    }

    func removeEvent(_ id: String) {
        calendar.removeAll { $0.id == id }
        layer = nil
        show("The fixture has been removed from your calendar.")
    }

    func submitResult(_ id: String) {
        guard let d = resDraft, let i = calendar.firstIndex(where: { $0.id == id }) else { return }
        let text = d.score.trimmingCharacters(in: .whitespaces)
        calendar[i].result = SquadResult(outcome: d.outcome,
                                         score: text.isEmpty ? "\(d.outcome) against \(calendar[i].opponent)" : text)
        resDraft = nil; clearDirty(); layer = nil
        show("The result has been saved.")
    }

    func submitReview() {
        guard let d = revDraft else { return }
        var bucket = peer[activeSport] ?? [:]
        for (k, v) in d.scores { bucket[k] = Double(v) }
        peer[activeSport] = bucket
        revDraft = nil; clearDirty(); layer = nil
        show("Your review of \(Catalog.player(d.who).name) has been submitted.")
    }

    // MARK: - Notifications and settings

    func clearNotifications() {
        for i in notifications.indices { notifications[i].unread = false }
        layer = nil
        show("All notifications have been marked as read.")
    }

    func setFilter(_ which: String, _ value: String) {
        if which == "gender" { mapFilters.gender = value } else { mapFilters.rating = value }
        layer = nil
    }

    func clearFilters() {
        mapFilters = MapFilters()
        show("All filters have been cleared.")
    }

    func toggleSport(_ s: Sport) {
        if let i = sports.firstIndex(of: s) {
            guard sports.count > 1 else { show("You need at least one sport."); return }
            sports.remove(at: i)
            if activeSport == s { activeSport = sports[0] }
        } else {
            sports.append(s)
        }
    }

    // MARK: - Onboarding

    func obBack() {
        if ob == 0 { show("You are on the first screen of the introduction."); return }
        ob -= 1
    }
    func obNext() { ob += 1 }

    func submitIdentity() {
        guard obDraft.isComplete else { show("Please complete every field to continue."); return }
        let u = obDraft.username.trimmingCharacters(in: .whitespaces)
        me = Me(name: obDraft.name.trimmingCharacters(in: .whitespaces),
                username: u.hasPrefix("@") ? u : "@" + u,
                age: obDraft.age, gender: obDraft.gender, av: obDraft.av)
        clearDirty(); obNext()
    }

    func finishOnboarding() {
        sports = obDraft.sports.isEmpty ? [.pickleball] : obDraft.sports
        optOut = obDraft.optOut
        activeSport = sports[0]
        onboarded = true
        screen = .main; tab = .home
        show("Welcome to Match Point.")
    }
}
