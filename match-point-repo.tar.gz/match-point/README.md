# Match Point

An iOS-style prototype for a sports matchmaking, social and rating app. It ships as two
self-contained builds of the same product:

| File | What it is |
| --- | --- |
| `dist/match-point-prototype.html` | Vanilla JS. Open it in a browser, no build step, no server. |
| `dist/MatchPoint.jsx` | A single-file React component. Default export, no required props. |

Both are generated from the same design and kept in step by a shared set of tests.

## Running it

Open `dist/match-point-prototype.html` in any modern browser. The page draws an iPhone 17 Pro
frame with the app inside it, and a bar along the top switches between two simulated accounts:

- **State A** — a brand new user, which starts in onboarding
- **State B** — a veteran with ratings, matches, conversations and a full calendar

For the React port, drop `dist/MatchPoint.jsx` into a project that has React 19 and render the
default export. It brings its own stylesheet, scoped under `.mp`, and uses Tailwind core
utilities only where they help.

## The product

**Sports.** Six of them, each with a permanent colour: Pickleball (light green), Badminton
(light blue), Ping Pong (light orange), Cricket (light red), Soccer (darker green) and
Volleyball (purple). One is active at a time and the whole app is scoped to it — chats,
matches, the map, the home feed. A player's other sports are only ever named in prose
("They also play Cricket and Soccer"), never as labels.

Individual sports (pickleball, badminton, ping pong) run on challenges, uploaded scores and
the **MP Rating**. Group sports (cricket, soccer, volleyball) run on a shared squad calendar
and peer reviews instead, because a squad of eleven cannot agree a ladder.

**Connecting.** There is one social action. Opening a player's profile gives you a single
**Connect** button, which opens a conversation and drops you into it. They have to write back
before either of you can send a challenge. Openers from people you are not connected with wait
in the Requests tab. There are no friends, no friend requests and no direct challenges.

**Challenging.** A challenge offers up to three times. It arrives inside the conversation,
where the other player taps whichever slot suits them; that confirms the match and clears the
rest. Until then it sits on the calendar as a tentative block for every time proposed.

**The calendar.** One weekly grid holds everything you have booked, whatever the sport. The
sport you are in keeps its full colour; the others fade back so you can still see the time is
taken. Tentative proposals are drawn striped with a dashed border, the way an unanswered
Outlook invitation is.

**The map.** Players cluster by how far apart they end up *on screen*, so two markers are never
closer than 66 pixels at any zoom. A cluster shows a count; tapping it zooms in far enough that
its members come apart. People you are connected with get a black bubble instead of a white one.
Pinch or scroll to zoom — there are no zoom buttons, because it is a phone.

**The MP Rating.** Everyone starts at 80. Points move in small steps: +1 to +2 against an even
opponent, +3 against a stronger one, +4 to +5 for a significant upset. Uploaded scores need the
other player's verification before they count.

## Working on it

Neither deliverable has a module system — each is one file by design. The source lives in
ordered fragments under `src/`, and `build/build.mjs` is the only thing that knows how they go
back together. Edit the fragments, never `dist/`.

```
src/html/    01-styles, 02-markup-icons-art, 03-data-and-state, 04-onboarding,
             05-shell-home-map, 06-matches-calendar-chats-profile, 07-overlays,
             08-layers-drawer-boot        -> concatenated in filename order

src/react/   00-styles.css (scoped under .mp, injected in place of __CSS__)
             01-icons-art-data, 02-state-and-actions, 03-shell-home-map,
             04-matches-calendar-chats-profile, 05-overlays-and-root
```

The numeric prefix is the whole ordering scheme, so renaming a file moves it in the output.

```bash
npm install
npm run build     # regenerates both files in dist/
npm test          # runs every suite against dist/
npm run verify    # both, in order
```

`npm test react` runs only the suites whose name matches.

## Tests

Four suites, run in jsdom. The vanilla build is loaded straight into a document; the React
build is compiled to CommonJS and mounted with `react-dom`.

| Suite | Covers |
| --- | --- |
| `core` | Every tab in every sport, both simulated profiles, rating movement, score verification, the map clustering invariant, the exit-intent guard |
| `features` | Connections and the Connect button, the three-slot challenge flow end to end, the shared calendar and its fading rules, the map markers, the fab's contrast check, the profile face |
| `react-core` | The same ground as `core`, driven through the rendered DOM |
| `react-features` | The same ground as `features`, driven through the rendered DOM |

The suites are written as behaviour rather than snapshots, so they read as a description of
what the app is supposed to do. A few assertions are worth knowing about:

- **No two map markers overlap.** Checked at seven zoom levels by measuring every pair.
- **The two builds stay in step.** The React suites mirror the vanilla ones assertion for
  assertion, so a change made in one build and forgotten in the other fails.
- **The parts of the app that were deliberately removed stay removed.** Friends, friend
  requests and challenge requests are asserted absent, not merely unused.

## Known shape of the prototype

This is a design prototype, not a product. State lives in memory and resets on reload; there is
no network, no persistence and no authentication. Opponents reply on a timer. The player data,
venues and communities are generated. Illustrations — the mascot, the venue scenes, the map —
are drawn as SVG in code rather than loaded as assets, so the whole thing stays in one file.

## Licence

MIT. See `LICENSE`.
