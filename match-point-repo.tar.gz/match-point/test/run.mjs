#!/usr/bin/env node
/**
 * Runs every suite against the current contents of dist/.
 *
 * The vanilla prototype is loaded straight into jsdom. The React port is
 * compiled to CommonJS first (into test/.build, which is gitignored) so
 * it can be required and mounted with react-dom.
 *
 *   node test/run.mjs            all suites
 *   node test/run.mjs react      only the suites whose name matches
 */
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..");
const require = createRequire(import.meta.url);

const SUITES = [
  ["core", "core.test.js", "the vanilla build: every tab, both simulated profiles, ratings, map, calendar"],
  ["features", "features.test.js", "the vanilla build: connections, challenge slots, the shared calendar, the map and the fab"],
  ["react-core", "react-core.test.js", "the React port: the same ground as core"],
  ["react-features", "react-features.test.js", "the React port: the same ground as features"],
];

if (!existsSync(join(root, "dist/match-point-prototype.html"))) {
  console.error("dist/ is empty. Run `npm run build` first.");
  process.exit(1);
}

/* The React suites need a CommonJS build they can require. */
function compileReact() {
  const { transformSync } = require("@babel/core");
  const src = readFileSync(join(root, "dist/MatchPoint.jsx"), "utf8");
  const out = transformSync(src, {
    presets: [["@babel/preset-react"]],
    plugins: ["@babel/plugin-transform-modules-commonjs"],
    filename: "MatchPoint.jsx",
  });
  mkdirSync(join(here, ".build"), { recursive: true });
  writeFileSync(join(here, ".build/MatchPoint.cjs"), out.code);
}

const filter = process.argv[2];
const chosen = SUITES.filter(([name]) => !filter || name.includes(filter));
if (chosen.some(([name]) => name.startsWith("react"))) compileReact();

let failed = 0;
for (const [name, file, what] of chosen) {
  process.stdout.write(`${name.padEnd(16)}`);
  try {
    const out = execFileSync(process.execPath, [join(here, file)], { encoding: "utf8", timeout: 180000 });
    process.stdout.write(out.trim().split("\n")[0] + "\n");
  } catch (err) {
    failed++;
    const text = (err.stdout || "") + (err.stderr || "");
    process.stdout.write("FAILED\n");
    process.stdout.write(text.trim().split("\n").map((l) => "  " + l).join("\n") + "\n");
  }
}
console.log(failed ? `\n${failed} of ${chosen.length} suites failed` : `\nall ${chosen.length} suites passed`);
process.exit(failed ? 1 : 0);
