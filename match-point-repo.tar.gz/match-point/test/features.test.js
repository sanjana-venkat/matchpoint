const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('fs');
const path=require('path');
const DIST=path.join(__dirname,'..','dist','match-point-prototype.html');
const vc=new VirtualConsole(); const errors=[];
vc.on('jsdomError',e=>errors.push('jsdomError: '+e.message));
const dom=new JSDOM(fs.readFileSync(DIST,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc});
const w=dom.window; const E=s=>w.eval(s);
const t=(l,c)=>{ try{E(c);}catch(e){errors.push(l+' -> '+e.message);} };
setTimeout(()=>{
  E(`Object.defineProperty(window.HTMLElement.prototype,'clientWidth',{get(){return 402},configurable:true});
     Object.defineProperty(window.HTMLElement.prototype,'clientHeight',{get(){return 700},configurable:true});`);

  /* ---- 1. Map controls and pins ---- */
  t('no zoom buttons on the map',`
    goTab('map'); initMap();
    if(document.querySelector('.map-zoom')) throw new Error('the zoom buttons are still there');
    if(!document.querySelector('.map-locate')) throw new Error('the recentre button is missing');
  `);
  t('pins carry no names',`
    [0.55,1,1.6,2.6].forEach(z=>{ MAP.z=z; renderPins();
      if(document.querySelector('.pin-nm')) throw new Error('a name is drawn at z='+z); });
    MAP.z=1; renderPins();
  `);
  t('a pin is a plain circle',`
    MAP.z=2.6; renderPins();
    const p=document.querySelector('.pin');
    if(!p) throw new Error('no pin');
    if(document.querySelector('.pin-tail')) throw new Error('the pointed tail is still drawn');
    if(!p.style.transform.includes('translate(-50%,-50%)')) throw new Error('the pin is not centred on its point');
    if(!p.querySelector('.av')) throw new Error('no avatar');
    if(!p.querySelector('.pin-rt')) throw new Error('no rating');
  `);
  t('connections get a black bubble',`
    MAP.z=2.6; renderPins();
    const pins=[...document.querySelectorAll('.pin')];
    const linked=pins.filter(p=>p.classList.contains('linked'));
    if(!linked.length) throw new Error('no connection is marked on the map');
    linked.forEach(p=>{ if(!isConnected(p.dataset.id)) throw new Error(p.dataset.id+' is not a connection'); });
    pins.filter(p=>!p.classList.contains('linked')).forEach(p=>{
      if(isConnected(p.dataset.id)) throw new Error(p.dataset.id+' is a connection but is drawn white'); });
  `);
  t('pinch and wheel still zoom',`
    mapRecentre(); const z0=MAP.z;
    mapZoomAt(1.6, 200, 350);
    if(!(MAP.z>z0)) throw new Error('zooming about a point did nothing');
    mapRecentre();
  `);

  /* ---- 2. Profile picture ---- */
  t('the profile circle draws the hero face',`
    goTab('profile');
    const svg=document.querySelector('.body .av .av-svg');
    if(!svg) throw new Error('no face in the profile circle');
    const outer=svg.querySelector('g[transform]');
    if(!outer || !outer.getAttribute('transform').includes('translate(-90 -30)'))
      throw new Error('the offset is not on an outer group, so the animation will wipe it');
    if(outer.classList.contains('av-body'))
      throw new Error('the animated group still carries the offset');
    if(!outer.querySelector('.av-body')) throw new Error('the breathing group is missing');
  `);
  t('the profile face matches the hero face',`
    const a=myFaceSVG(84);
    goTab('home');
    if(!document.querySelector('.hero-stage')) throw new Error('no hero');
    if(!a.includes('av-eyes')) throw new Error('the profile face is not the mascot');
  `);

  /* ---- 3. The fab over a black button ---- */
  t('the fab inverts over a solid black button',`
    goTab('matches');
    const fab=document.querySelector('.fab'), dark=document.querySelector('.btn-dark');
    if(!fab||!dark) throw new Error('nothing to compare');
    /* jsdom has no layout, so drive the check with known rectangles. */
    const rect=(l,t,r,b)=>()=>({left:l,top:t,right:r,bottom:b,width:r-l,height:b-t});
    fab.getBoundingClientRect=rect(330,600,382,652);
    dark.getBoundingClientRect=rect(20,590,382,640);
    syncFab();
    if(!fab.classList.contains('invert')) throw new Error('the fab did not flip to white');
    dark.getBoundingClientRect=rect(20,100,382,150);
    syncFab();
    if(fab.classList.contains('invert')) throw new Error('the fab stayed white with nothing behind it');
  `);

  /* ---- 4. Three challenge slots ---- */
  t('a challenge offers up to three slots',`
    goTab('matches'); openLayer({type:'challenge'});
    if(!document.querySelector('.slot-row')) throw new Error('no slot row');
    if(document.querySelectorAll('.slot-row').length!==1) throw new Error('it should start with one');
    chAddSlot(); chAddSlot();
    if(document.querySelectorAll('.slot-row').length!==3) throw new Error('could not reach three');
    chAddSlot();
    if(document.querySelectorAll('.slot-row').length!==3) throw new Error('it went past three');
    if(!document.body.textContent.includes('Three is the maximum')) throw new Error('no ceiling explained');
  `);
  t('a sent challenge lands in the conversation',`
    const opp=V.draft.ch.opp;
    const before=S.upcoming.length;
    submitChallenge();
    if(S.upcoming.length!==before+1) throw new Error('nothing was added to the calendar');
    const c=S.upcoming[S.upcoming.length-1];
    if(c.status!=='Tentative') throw new Error('a fresh challenge should be tentative');
    if(c.slots.length!==3) throw new Error('the three slots were lost');
    if(V.screen!=='chat') throw new Error('it did not open the conversation');
    const th=S.threads.find(x=>x.id===V.chatWith);
    const m=th.msgs[th.msgs.length-1];
    if(m.kind!=='challenge'||m.slots.length!==3) throw new Error('no challenge message in the thread');
    if(!document.querySelector('.ch-card')) throw new Error('the challenge is not drawn in the chat');
    V.screen='main'; render();
  `);
  t('the recipient picks one of the proposed times',`
    const th=S.threads.find(t=>t.msgs.some(m=>m.kind==='challenge' && !m.me && m.chosen==null));
    if(!th) throw new Error('no incoming proposal to answer');
    const m=th.msgs.find(m=>m.kind==='challenge' && !m.me);
    switchSport(m.sport); openChat(th.id);
    const picks=[...document.querySelectorAll('.slot.pick')];
    if(picks.length!==m.slots.length) throw new Error('the slots are not offered as choices');
    pickSlot(th.id, m.cid, 1);
    const c=S.upcoming.find(x=>x.id===m.cid);
    if(!c || c.status!=='Confirmed') throw new Error('picking a slot did not confirm the match');
    if(c.date!==m.slots[1].date || c.start!==m.slots[1].start) throw new Error('the wrong slot was taken');
    if(c.slots) throw new Error('the other slots were not cleared');
    if(document.querySelectorAll('.slot.pick').length) throw new Error('the choices are still tappable');
    V.screen='main'; switchSport('pickleball'); render();
  `);

  /* ---- 5 and 7. Connect replaces friends ---- */
  t('the concept of friends is gone',`
    if('friends' in S) throw new Error('S.friends still exists');
    if('requestsIn' in S) throw new Error('friend requests still exist');
    if('challengeRequests' in S) throw new Error('challenge requests still exist');
    if(typeof sendFriendRequest!=='undefined') throw new Error('sendFriendRequest still exists');
  `);
  t('a profile shows one Connect button above Block',`
    goTab('map');
    const stranger=ALL_PLAYERS.find(p=>!isConnected(p.id) && p.sports.includes('pickleball'));
    openLayer({type:'drawer', id:stranger.id});
    const body=document.querySelector('.sheet-body');
    const btns=[...body.querySelectorAll('button')].map(b=>b.textContent.trim());
    if(btns.some(b=>/Add friend|Friends|Requested/.test(b))) throw new Error('a friend button survived');
    if(btns.filter(b=>/^Message$|^Challenge$/.test(b)).length) throw new Error('the old three buttons are still there');
    const connect=[...body.querySelectorAll('button')].find(b=>b.textContent.includes('Connect'));
    const block=[...body.querySelectorAll('button')].find(b=>b.textContent.includes('Block'));
    if(!connect) throw new Error('no Connect button');
    if(!block) throw new Error('no Block button');
    if(!connect.classList.contains('btn-dark')) throw new Error('Connect is not the primary black button');
    const order=[...body.querySelectorAll('button')];
    if(order.indexOf(connect)>order.indexOf(block)) throw new Error('Connect should sit above Block');
    if(!connect.querySelector('svg')) throw new Error('Connect has no icon');
  `);
  t('Connect opens the conversation',`
    const stranger=ALL_PLAYERS.find(p=>!isConnected(p.id) && !threadWith(p.id) && p.sports.includes('pickleball'));
    connectWith(stranger.id);
    if(V.screen!=='chat') throw new Error('it did not open the message screen');
    const th=threadWith(stranger.id);
    if(!th || !th.pending) throw new Error('the thread should be waiting on their reply');
    if(!document.querySelector('.chat-note')) throw new Error('the first-message note is missing');
    const note=document.querySelector('.chat-note').textContent;
    if(!note.includes('start a conversation and wait for their response'))
      throw new Error('the note does not say what it should: '+note.trim());
    if(document.querySelector('.appbar .icon-btn svg')) throw new Error('a challenge button is offered before they replied');
    if(canChallenge(stranger.id)) throw new Error('challenges are allowed too early');
    V.screen='main'; render();
  `);
  t('the Chats tab has Chats and Requests',`
    goTab('chats');
    const segs=[...document.querySelectorAll('.seg button')].map(b=>b.textContent.trim());
    if(segs.length!==2) throw new Error('expected two tabs, got '+JSON.stringify(segs));
    if(!/^Chats$/.test(segs[0])) throw new Error('the first tab is '+segs[0]);
    if(!/^Requests/.test(segs[1])) throw new Error('the second tab is '+segs[1]);
    const screen=document.getElementById('screen')||document.getElementById('app');
    if(screen.textContent.includes('Friend requests')) throw new Error('friend requests survived');
    if([...document.querySelectorAll('.navbar button')].some(b=>b.textContent.includes('Friends')))
      throw new Error('the nav still says Friends');
    if(!document.querySelector('.appbar-title') || document.querySelector('.appbar-title').textContent!=='Chats')
      throw new Error('the title is not Chats');
  `);
  t('accepting a request makes a connection',`
    V.chatTab='requests'; render();
    const r=sportMsgRequests()[0];
    if(!r) throw new Error('no request to accept');
    const before=S.connections.length;
    acceptMsgRequest(r.id);
    if(!isConnected(r.with)) throw new Error('they were not connected');
    if(S.connections.length!==before+1) throw new Error('the connection count did not move');
    if(!threadWith(r.with)) throw new Error('no conversation was opened');
    if(S.msgRequests.some(x=>x.id===r.id)) throw new Error('the request is still pending');
    if(V.chatTab!=='chats') throw new Error('it did not move to the chats tab');
  `);
  t('challenges are limited to connections',`
    goTab('matches'); openLayer({type:'challenge'});
    const opts=[...document.querySelectorAll('.sheet-body select')][0];
    const ids=[...opts.options].map(o=>o.value);
    if(!ids.length) throw new Error('no opponents offered');
    ids.forEach(id=>{ if(!canChallenge(id)) throw new Error(id+' is offered but is not an open connection'); });
    closeLayer();
  `);
  t('notifications talk about connections',`
    openLayer({type:'notifications'});
    const tx=document.querySelector('.sheet-body').textContent;
    if(/friend request/i.test(tx)) throw new Error('a friend request notification survived');
    if(!/connect/i.test(tx)) throw new Error('nothing about connecting');
    closeLayer();
  `);
  t('the home feed has no friend or challenge requests',`
    goTab('home');
    const heads=[...document.querySelectorAll('.sec-head h4')].map(h=>h.textContent);
    if(heads.includes('Friend requests')) throw new Error('friend requests are still on the home page');
    if(!heads.includes('Connection requests')) throw new Error('connection requests are missing');
    if(!heads.includes('Challenges')) throw new Error('challenges are missing');
  `);
  t('mutual friends became connections in common',`
    openLayer({type:'drawer', id:'p20'});
    const tx=document.querySelector('.sheet-body').textContent;
    if(/mutual friends/i.test(tx)) throw new Error('mutual friends survived on the profile');
    if(!/connections in common/i.test(tx)) throw new Error('nothing replaced it');
    closeLayer();
  `);

  /* ---- 8. The calendar for every sport ---- */
  t('individual sports get the weekly calendar',`
    switchSport('pickleball'); goTab('matches'); V.matchTab='upcoming'; V.weekOffset=0; render();
    if(!document.querySelector('.cal-grid')) throw new Error('no calendar on the upcoming tab');
    if(document.querySelector('.card .edit-btn')) throw new Error('the old challenge cards are still there');
  `);
  t('every sport is drawn, only the active one in full colour',`
    const evs=[...document.querySelectorAll('.cal-ev')];
    if(!evs.length) throw new Error('nothing on the calendar');
    const mine=evs.filter(e=>!e.classList.contains('dim'));
    const others=evs.filter(e=>e.classList.contains('dim'));
    if(!mine.length) throw new Error('no pickleball blocks');
    if(!others.length) throw new Error('other sports are not shown at all');
    const pal=paletteOf('pickleball');
    mine.filter(e=>!e.classList.contains('tent')).forEach(e=>{
      if(!e.getAttribute('style').includes(pal.accent)) throw new Error('a pickleball block is not in its colour');
    });
  `);
  t('switching sport swaps which blocks are lit',`
    const before=[...document.querySelectorAll('.cal-ev')].filter(e=>!e.classList.contains('dim')).map(e=>e.textContent);
    switchSport('badminton'); goTab('matches'); V.matchTab='upcoming'; V.weekOffset=0; render();
    const after=[...document.querySelectorAll('.cal-ev')].filter(e=>!e.classList.contains('dim')).map(e=>e.textContent);
    if(JSON.stringify(before)===JSON.stringify(after)) throw new Error('the highlight did not follow the sport');
    if(!after.length) throw new Error('no badminton blocks are lit');
    const cricket=[...document.querySelectorAll('.cal-ev')].filter(e=>e.getAttribute('style').includes(paletteOf('cricket').accent));
    cricket.forEach(e=>{ if(!e.classList.contains('dim')) throw new Error('cricket should be faded in badminton mode'); });
  `);
  t('tentative blocks are styled apart from confirmed ones',`
    const tent=[...document.querySelectorAll('.cal-ev.tent')];
    if(!tent.length) throw new Error('no tentative blocks drawn');
    tent.forEach(e=>{ if(!/dashed/.test(e.getAttribute('style'))) throw new Error('a tentative block looks confirmed'); });
    const conf=[...document.querySelectorAll('.cal-ev:not(.tent)')];
    conf.forEach(e=>{ if(/dashed/.test(e.getAttribute('style'))) throw new Error('a confirmed block looks tentative'); });
  `);
  t('every proposed slot is drawn until one is picked',`
    switchSport('pickleball'); goTab('matches'); V.weekOffset=0; render();
    const c=S.upcoming.find(x=>x.status==='Tentative' && x.sport==='pickleball');
    if(!c) throw new Error('no tentative pickleball challenge');
    const drawn=calendarItems().filter(i=>i.id===c.id);
    if(drawn.length!==c.slots.length) throw new Error('drew '+drawn.length+' of '+c.slots.length+' slots');
  `);
  t('withdrawn challenges leave the calendar',`
    const c=S.upcoming.find(x=>x.status==='Tentative' && x.sport==='pickleball');
    removeChallenge(c.id);
    if(calendarItems().some(i=>i.id===c.id)) throw new Error('a withdrawn challenge is still drawn');
  `);
  t('the group-sport calendar shows other sports too',`
    switchSport('cricket'); goTab('matches'); V.calTab='week'; V.weekOffset=0; render();
    const evs=[...document.querySelectorAll('.cal-ev')];
    if(!evs.some(e=>e.classList.contains('dim'))) throw new Error('only cricket is drawn');
    if(!evs.some(e=>!e.classList.contains('dim'))) throw new Error('cricket is not lit in cricket mode');
    switchSport('pickleball');
  `);
  t('the legend explains both rules',`
    goTab('matches'); render();
    const key=document.querySelector('.cal-key');
    if(!key) throw new Error('no legend');
    if(!/confirmed/i.test(key.textContent)) throw new Error('nothing about confirmed');
    if(!/awaiting a reply/i.test(key.textContent)) throw new Error('nothing about tentative');
  `);
  t('nothing else broke',`
    ['home','map','matches','chats','profile'].forEach(t=>goTab(t));
    switchSport('badminton'); ['home','matches','chats','profile'].forEach(t=>goTab(t));
    switchSport('pickleball'); goTab('home');
  `);
  console.log(errors.length?'FAILURES:\n'+errors.join('\n'):'ALL OK — every check passed');
  dom.window.close(); process.exit(errors.length?1:0);
},800);
