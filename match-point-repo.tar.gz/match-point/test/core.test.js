const {JSDOM,VirtualConsole}=require('jsdom');
const fs=require('fs');
const path=require('path');
const DIST=path.join(__dirname,'..','dist','match-point-prototype.html');
const vc=new VirtualConsole(); const errors=[];
vc.on('jsdomError',e=>errors.push('jsdomError: '+e.message));
const dom=new JSDOM(fs.readFileSync(DIST,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc});
const w=dom.window; const E=s=>w.eval(s);
const t=(l,c)=>{ try{E(c);}catch(e){errors.push(l+' -> '+e.message);} };
setTimeout(()=>{
  E(`Object.defineProperty(window.HTMLElement.prototype,'clientWidth',{get(){return 402},configurable:true});
     Object.defineProperty(window.HTMLElement.prototype,'clientHeight',{get(){return 700},configurable:true});`);

  t('state B walks every tab and sport',`
    activeSports().forEach(s=>{ switchSport(s);
      ['home','map','matches','chats','profile'].forEach(t=>goTab(t)); });
    switchSport('pickleball'); goTab('home');
  `);
  t('state A onboards from nothing',`
    loadProfile('A');
    if(V.screen!=='onboarding') throw new Error('state A should start in onboarding');
    loadProfile('B');
  `);
  t('home sections appear in priority order',`
    goTab('home');
    const heads=[...document.querySelectorAll('.sec-head h4')].map(h=>h.textContent);
    const want=['Verifications','Connection requests','Challenges','Recommended opponents','Pickleball near you'];
    if(JSON.stringify(heads)!==JSON.stringify(want)) throw new Error('order is '+JSON.stringify(heads));
  `);
  t('empty sections disappear rather than showing a placeholder',`
    const keep=S.verifications;
    S.verifications=[]; goTab('home');
    const heads=[...document.querySelectorAll('.sec-head h4')].map(h=>h.textContent);
    if(heads.includes('Verifications')) throw new Error('an empty section was still drawn');
    if(document.querySelector('.rail .empty')) throw new Error('an empty state crept in');
    S.verifications=keep; render();
  `);
  t('every card opens a detail sheet',`
    goTab('home');
    const arrows=[...document.querySelectorAll('.open-btn')];
    if(arrows.length<4) throw new Error('only '+arrows.length+' cards can be opened');
    openLayer({type:'verifyDetail', id:sportVerifications()[0].id});
    if(!document.querySelector('.sheet')) throw new Error('the verification sheet did not open');
    closeLayer();
  `);
  t('confirming a verification moves the rating and logs the match',`
    goTab('home');
    const v=sportVerifications()[0], before=myRating(v.sport), past=S.past.length;
    resolveVerification(v.id, true);
    if(S.verifications.some(x=>x.id===v.id)) throw new Error('it is still waiting');
    if(myRating(v.sport)!==before+v.delta) throw new Error('the rating did not move by the stated amount');
    if(S.past.length!==past+1) throw new Error('it was not filed in your history');
  `);
  t('the sport switcher scopes chats and matches',`
    switchSport('pickleball');
    const pChats=sportThreads().map(t=>t.with);
    switchSport('badminton');
    const bChats=sportThreads().map(t=>t.with);
    if(!pChats.length||!bChats.length) throw new Error('one of the sports has no chats at all');
    if(JSON.stringify(pChats)===JSON.stringify(bChats)) throw new Error('the chat list ignores the sport');
    if(sportUpcoming().some(c=>c.sport!=='badminton')) throw new Error('another sport leaked into matches');
    switchSport('pickleball');
  `);
  t('other sports are named in prose, never as labels',`
    openLayer({type:'drawer', id:'p1'});
    const tx=document.querySelector('.sheet-body').textContent;
    if(!/They also play/.test(tx)) throw new Error('no readable line about their other sports');
    closeLayer();
  `);
  t('the hero mascot is intact',`
    goTab('home');
    const art=document.querySelector('.hero-stage').innerHTML;
    if(!/#1E222A|#23262F/.test(art)) throw new Error('the bold outline is gone');
    /* The only lettering is the rating on the shirt and its label. */
    const texts=[...document.querySelectorAll('.hero-stage text')].map(x=>x.textContent.trim());
    if(texts.length!==2) throw new Error('expected the rating and its label, got '+JSON.stringify(texts));
    if(!/^[0-9]+$|^Unrated$/.test(texts[0])) throw new Error('the shirt does not show the rating: '+texts[0]);
    if(!/circle|ellipse/.test(art)) throw new Error('the face is missing');
    if(!/#1E222A/.test(art)) throw new Error('the black tee is gone');
  `);
  t('the map clusters without ever overlapping',`
    goTab('map'); initMap();
    [0.55,0.8,1,1.4,1.8,2.2,2.6].forEach(z=>{
      MAP.z=z; const c=mapClusters();
      const n=c.reduce((s,x)=>s+x.items.length,0);
      if(n!==mapPlayers().length) throw new Error('players went missing at z='+z);
      for(let i=0;i<c.length;i++) for(let j=i+1;j<c.length;j++){
        const d=Math.hypot(c[i].x-c[j].x,c[i].y-c[j].y)*z;
        if(d<CLUSTER_R-0.5) throw new Error('two markers are '+d.toFixed(1)+'px apart at z='+z);
      }
    });
    MAP.z=1; renderPins();
  `);
  t('tapping a cluster breaks it open',`
    MAP.z=1; renderPins();
    const i=MAP.clusters.findIndex(c=>c.items.length>1);
    if(i<0) throw new Error('nothing clusters at the default zoom');
    const c=MAP.clusters[i], ids=c.items.map(x=>x.p.id), z0=MAP.z;
    mapFocus(c);
    if(!(MAP.z>z0)) throw new Error('it did not zoom');
    if(MAP.clusters.some(x=>x.items.length===ids.length && x.items.every(y=>ids.includes(y.p.id))))
      throw new Error('the group did not come apart');
    mapRecentre();
  `);
  t('map filters still work',`
    V.mapFilters={gender:'Women',rating:'Any'}; render(); initMap();
    if(mapClusters().reduce((s,c)=>s+c.items.length,0)!==mapPlayers().length) throw new Error('filtered players are misplaced');
    clearFilters();
  `);
  t('scores can be uploaded end to end',`
    switchSport('pickleball'); goTab('matches');
    openLayer({type:'score'});
    if(!document.querySelector('.sheet-body')) throw new Error('the score sheet did not open');
    const body=document.querySelector('.sheet-body').textContent;
    if(/Sport/.test(body)) throw new Error('a sport picker crept back in');
    closeLayer();
  `);
  t('group sports keep their calendar and reviews',`
    switchSport('cricket');
    if(!isGroupMode()) throw new Error('cricket is not a group sport');
    goTab('matches');
    if(!document.querySelector('.cal-grid')) throw new Error('no calendar');
    openLayer({type:'review'});
    if(!document.querySelector('.sheet')) throw new Error('the review sheet did not open');
    closeLayer();
    V.calTab='past'; render();
    if(!document.querySelector('.seg')) throw new Error('the past tab broke');
    V.calTab='week'; switchSport('pickleball'); render();
  `);
  t('the exit guard still catches unsaved work',`
    goTab('matches'); openLayer({type:'challenge'});
    markDirty('Creating a challenge');
    switchSport('badminton');
    if(!V.layer || V.layer.type!=='exitIntent') throw new Error('switching sport did not warn');
    discardAndSwitch();
    if(V.activeSport!=='badminton') throw new Error('discarding did not switch');
    switchSport('pickleball');
  `);
  t('notifications can be cleared',`
    openLayer({type:'notifications'});
    clearNotifs();
    if(unreadNotifs()!==0) throw new Error('some stayed unread');
  `);
  console.log(errors.length?'FAILURES:\n'+errors.join('\n'):'CORE OK — every check passed');
  dom.window.close(); process.exit(errors.length?1:0);
},800);
