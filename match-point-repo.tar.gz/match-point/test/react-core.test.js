const {JSDOM}=require('jsdom');
const dom=new JSDOM('<!DOCTYPE html><div id="root"></div>',{pretendToBeVisual:true});
global.window=dom.window; global.document=dom.window.document; global.navigator=dom.window.navigator;
global.IS_REACT_ACT_ENVIRONMENT=true;
Object.defineProperty(dom.window.HTMLElement.prototype,'clientWidth',{get(){return 402},configurable:true});
Object.defineProperty(dom.window.HTMLElement.prototype,'clientHeight',{get(){return 700},configurable:true});
const React=require('react'); const {createRoot}=require('react-dom/client'); const {act}=require('react');
const Mod=require(require('path').join(__dirname,'.build','MatchPoint.cjs'));
const errors=[]; const orig=console.error;
console.error=(...a)=>{const s=String(a[0]||''); if(!s.includes('not wrapped in act')) errors.push('console.error: '+s.slice(0,240));};
const root=createRoot(document.getElementById('root'));
act(()=>{ root.render(React.createElement(Mod.default)); });
const q=(s)=>document.querySelector(s), qa=(s)=>[...document.querySelectorAll(s)];
const by=(t)=>qa('button').find(b=>b.textContent.trim()===t)||qa('button').find(b=>b.textContent.includes(t));
const click=(el,l)=>{ if(!el){errors.push('not found: '+l);return;} act(()=>{el.dispatchEvent(new dom.window.MouseEvent('click',{bubbles:true}));}); };
const ck=(l,c)=>{ if(!c) errors.push('assert failed: '+l); };
const screen=()=>q('.mp').textContent;
const sport=(n)=>{ click(q('.appbar .bar-btn'),'switcher'); click(by(n),'pick '+n); };

['Map','Matches','Chats','Profile','Home'].forEach(t=>click(by(t),t));
sport('Badminton'); ['Matches','Chats','Profile','Home'].forEach(t=>click(by(t),t));
sport('Cricket');   ['Calendar','Chats','Profile','Home'].forEach(t=>click(by(t),t));
sport('Pickleball');
ck('the app survived every tab in every sport', errors.length===0);

click(by('Home'),'home');
ck('the hero is drawn', !!q('.hero-stage,.hero-wrap svg'));
const texts=qa('.hero-wrap text').map(t=>t.textContent.trim());
ck('the shirt shows the rating and its label: '+JSON.stringify(texts), texts.length===2 && /^[0-9]+$|^Unrated$/.test(texts[0]));
ck('no empty-state placeholder on a populated home', !q('.body > .empty'));
ck('every card has an expand arrow', qa('.open-btn').length>=4);

click(qa('.open-btn')[0],'first arrow');
ck('a detail sheet opens', !!q('.sheet'));
const confirm=by('Confirm'); ck('the verification can be confirmed', !!confirm);
click(confirm,'confirm');

click(by('Profile'),'profile');
ck('the username survived', screen().includes('@sashpash'));
ck('the profile face is drawn', !!q('.body .av .av-svg'));

click(by('Map'),'map');
ck('the filter chips are there', qa('.gchip').length>=2);
click(qa('.gchip')[0],'gender filter');
ck('the filter sheet opens', !!q('.sheet'));
click(by('Close'),'close filter');

click(by('Matches'),'matches');
click(by('Past'),'past tab');
ck('past matches are listed', qa('.card').length>0);
click(by('Upcoming'),'upcoming tab');
ck('back on the calendar', !!q('.cal-grid'));

sport('Cricket');
click(by('Calendar'),'calendar tab');
click(by('Add to calendar'),'add fixture');
ck('the fixture sheet opens', !!q('.sheet') && /Add to calendar/.test(screen()));
click(by('Cancel'),'cancel');
sport('Pickleball');

const fab=q('.fab');
click(fab,'open fab');
ck('the fab reveals its actions', qa('.fab-opt').length===2);
click(by('Upload scores'),'score sheet');
ck('the score sheet opens', !!q('.sheet-body'));
ck('no sport picker in the score sheet', !/Sport/.test(q('.sheet-body').textContent));
click(by('Cancel'),'cancel score');

console.error=orig;
console.log(errors.length?'FAILURES:\n'+errors.join('\n'):'REACT CORE OK — every check passed');
process.exit(errors.length?1:0);
