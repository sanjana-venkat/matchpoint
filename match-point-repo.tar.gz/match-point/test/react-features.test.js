const {JSDOM}=require('jsdom');
const dom=new JSDOM('<!DOCTYPE html><div id="root"></div>',{pretendToBeVisual:true});
global.window=dom.window; global.document=dom.window.document; global.navigator=dom.window.navigator;
global.IS_REACT_ACT_ENVIRONMENT=true;
Object.defineProperty(dom.window.HTMLElement.prototype,'clientWidth',{get(){return 402},configurable:true});
Object.defineProperty(dom.window.HTMLElement.prototype,'clientHeight',{get(){return 700},configurable:true});
const React=require('react'); const {createRoot}=require('react-dom/client'); const {act}=require('react');
const Mod=require(require('path').join(__dirname,'.build','MatchPoint.cjs'));
const errors=[]; const orig=console.error;
console.error=(...a)=>{const s=String(a[0]||''); if(!s.includes('not wrapped in act')) errors.push('console.error: '+s.slice(0,240));};
const root=createRoot(document.getElementById('root'));
act(()=>{ root.render(React.createElement(Mod.default)); });

const q=(s)=>document.querySelector(s), qa=(s)=>[...document.querySelectorAll(s)];
const btns=()=>qa('button');
const by=(t)=>btns().find(b=>b.textContent.trim()===t)||btns().find(b=>b.textContent.includes(t));
const click=(el,l)=>{ if(!el){errors.push('not found: '+l);return;} act(()=>{el.dispatchEvent(new dom.window.MouseEvent('click',{bubbles:true}));}); };
const tap=(el,l)=>{ if(!el){errors.push('not found: '+l);return;}
  act(()=>{el.dispatchEvent(new dom.window.MouseEvent('mousedown',{bubbles:true,clientX:9,clientY:9}));});
  act(()=>{el.dispatchEvent(new dom.window.MouseEvent('mouseup',{bubbles:true,clientX:9,clientY:9}));}); };
const ck=(l,c)=>{ if(!c) errors.push('assert failed: '+l); };
const screen=()=>q('.mp').textContent;
const sport=(name)=>{ click(q('.appbar .bar-btn'),'sport switcher'); click(by(name),'pick '+name); };
const CLUSTER_R=66;

/* ---- map ---- */
click(by('Map'),'map');
ck('the zoom buttons are gone', !q('.map-zoom'));
ck('the recentre button stayed', !!q('.map-locate'));
ck('no names on the map', !q('.pin-nm'));
ck('no pointed tails', !q('.pin-tail'));
const pinsOK=qa('.pin').every(p=>p.style.transform.includes('translate(-50%,-50%)') && p.querySelector('.av') && p.querySelector('.pin-rt'));
ck('a pin is a circle with an avatar and a rating', qa('.pin').length>0 && pinsOK);
const zoomIn=()=>{ const w=q('.map-world'); const m=/scale\(([\d.]+)\)/.exec(w.style.transform); return m?parseFloat(m[1]):1; };
const cl=q('.map-cluster');
ck('players cluster on the map', !!cl && /^\d+$/.test(cl.querySelector('.mc-n').textContent.trim()));
const z0=zoomIn(); tap(cl,'cluster'); ck('tapping a cluster zooms in', zoomIn()>z0);
const linked=qa('.pin.linked');
ck('connections get a black bubble', linked.length>0);
ck('the spacing rule holds', (()=>{ const z=zoomIn();
  const m=qa('.pin,.map-cluster').map(e=>({x:parseFloat(e.style.left),y:parseFloat(e.style.top)}));
  for(let i=0;i<m.length;i++) for(let j=i+1;j<m.length;j++)
    if(Math.hypot(m[i].x-m[j].x,m[i].y-m[j].y)*z < CLUSTER_R-0.5) return false;
  return true; })());

/* ---- profile picture ---- */
click(by('Profile'),'profile');
const face=q('.body .av .av-svg');
ck('the profile circle draws a face', !!face);
const outer=face && face.querySelector('g[transform]');
ck('the offset sits on an outer group', !!outer && outer.getAttribute('transform').includes('translate(-90 -30)'));
ck('the breathing group is separate', !!outer && !outer.classList.contains('av-body') && !!outer.querySelector('.av-body'));

/* ---- fab contrast ---- */
click(by('Matches'),'matches');
const fab=q('.fab'), dark=q('.btn-dark');
if(fab&&dark){
  const rect=(l,t,r,b)=>()=>({left:l,top:t,right:r,bottom:b,width:r-l,height:b-t});
  fab.getBoundingClientRect=rect(330,600,382,652);
  dark.getBoundingClientRect=rect(20,590,382,640);
  act(()=>{ q('.mp .body').dispatchEvent(new dom.window.Event('scroll')); });
  ck('the fab flips to white over a black button', fab.classList.contains('invert'));
  dark.getBoundingClientRect=rect(20,100,382,150);
  act(()=>{ q('.mp .body').dispatchEvent(new dom.window.Event('scroll')); });
  ck('the fab goes dark again when clear', !fab.classList.contains('invert'));
} else errors.push('no fab or dark button to compare');

/* ---- calendar ---- */
ck('the upcoming tab is a calendar', !!q('.cal-grid'));
ck('the old challenge cards are gone', !q('.card .edit-btn'));
const evs=()=>qa('.cal-ev');
ck('something is on the calendar', evs().length>0);
ck('the active sport is lit', evs().some(e=>!e.classList.contains('dim')));
ck('other sports are faded, not hidden', evs().some(e=>e.classList.contains('dim')));
ck('tentative blocks are dashed', evs().filter(e=>e.classList.contains('tent')).every(e=>/dashed/.test(e.getAttribute('style')||'')));
ck('confirmed blocks are solid', evs().filter(e=>!e.classList.contains('tent')).every(e=>!/dashed/.test(e.getAttribute('style')||'')));
ck('there is a legend', !!q('.cal-key') && /Awaiting a reply/.test(q('.cal-key').textContent));
const litBefore=evs().filter(e=>!e.classList.contains('dim')).map(e=>e.textContent).join('|');
sport('Badminton');
click(by('Matches'),'matches again');
const litAfter=evs().filter(e=>!e.classList.contains('dim')).map(e=>e.textContent).join('|');
ck('the highlight follows the sport', litBefore!==litAfter && litAfter.length>0);
sport('Cricket');
ck('group sports show other sports too', evs().some(e=>e.classList.contains('dim')) && evs().some(e=>!e.classList.contains('dim')));
sport('Pickleball');

/* ---- three slots ---- */
click(by('Matches'),'matches');
click(by('Add a Challenge'),'add challenge');
ck('the sheet starts with one slot', qa('.slot-row').length===1);
click(by('Offer another time'),'add slot 2');
click(by('Offer another time'),'add slot 3');
ck('three slots can be offered', qa('.slot-row').length===3);
ck('the ceiling is explained', /Three is the maximum/.test(screen()));
ck('there is no fourth slot button', !by('Offer another time'));
click(by('Send 3 times'),'send');
ck('sending opens the conversation', !!q('.chat-wrap'));
ck('the challenge is drawn in the chat', !!q('.ch-card'));
ck('it says it is waiting on them', /Waiting for .* to pick a time/.test(screen()));
click(q('.appbar .back'),'back');

/* ---- picking a slot ---- */
sport('Badminton');
click(by('Chats'),'chats');
const row=qa('.row').find(r=>/Challenge · \d time/.test(r.textContent));
ck('an incoming proposal is listed', !!row);
click(row,'open that chat');
const picks=qa('.slot.pick');
ck('the slots are offered as choices', picks.length>=2);
click(picks[1],'pick the second slot');
ck('picking confirms the match', /Confirmed and added to your calendar/.test(screen()));
ck('the choices are no longer tappable', qa('.slot.pick').length===0);
click(q('.appbar .back'),'back 2');
sport('Pickleball');

/* ---- connect replaces friends ---- */
click(by('Map'),'map');
const white=qa('.pin').find(p=>!p.classList.contains('linked'));
tap(white,'a stranger on the map');
const sheet=q('.sheet-body');
ck('the drawer opened', !!sheet);
if(sheet){
  const names=[...sheet.querySelectorAll('button')].map(b=>b.textContent.trim());
  ck('no friend button', !names.some(n=>/Add friend|^Friends$|Requested/.test(n)));
  ck('no separate Message and Challenge buttons', !names.some(n=>/^Message$|^Challenge$/.test(n)));
  const connect=[...sheet.querySelectorAll('button')].find(b=>b.textContent.includes('Connect'));
  const block=[...sheet.querySelectorAll('button')].find(b=>b.textContent.includes('Block'));
  const order=[...sheet.querySelectorAll('button')];
  ck('there is a Connect button', !!connect);
  ck('Connect is the primary black button', connect && connect.classList.contains('btn-dark'));
  ck('Connect has an icon', connect && !!connect.querySelector('svg'));
  ck('Connect sits above Block', connect && block && order.indexOf(connect)<order.indexOf(block));
  ck('mutual friends became connections in common', /connections in common/.test(sheet.textContent) && !/mutual friends/.test(sheet.textContent));
  click(connect,'connect');
}
ck('Connect opens the message screen', !!q('.chat-wrap'));
ck('the first-message note appears', !!q('.chat-note') && /start a conversation and wait for their response/.test(q('.chat-note').textContent));
ck('no challenge button before they reply', !q('.appbar .icon-btn'));
click(q('.appbar .back'),'back 3');

click(by('Chats'),'chats');
const segs=qa('.seg button').map(b=>b.textContent.trim());
ck('the tabs are Chats and Requests: '+JSON.stringify(segs), segs.length===2 && /^Chats$/.test(segs[0]) && /^Requests/.test(segs[1]));
ck('the nav says Chats, not Friends', !qa('.navbar button').some(b=>b.textContent.includes('Friends')));
ck('the title says Chats', q('.appbar-title').textContent==='Chats');
click(by('Requests'),'requests tab');
const accept=by('Accept');
ck('there are requests to answer', !!accept);
click(accept,'accept');
ck('accepting moves you back to chats', qa('.seg button')[0].classList.contains('on'));

click(q('.appbar .bar-btn:last-child'),'notifications');
const nt=q('.sheet-body');
ck('notifications talk about connecting', nt && /connect/i.test(nt.textContent) && !/friend request/i.test(nt.textContent));
click(q('.sheet-head .icon-btn'),'close notifications');

click(by('Home'),'home');
const heads=qa('.sec-head h4').map(h=>h.textContent);
ck('home order: '+JSON.stringify(heads), JSON.stringify(heads)===JSON.stringify(['Verifications','Connection requests','Challenges','Recommended opponents','Pickleball near you']));

console.error=orig;
console.log(errors.length?'FAILURES:\n'+errors.join('\n'):'REACT OK — every check passed');
process.exit(errors.length?1:0);
